"""Turn body/feet.obj (both feet, Roblox/Genesis export) into the Studio's foot model in avatar studs:
   body/out/feet.json (base64 Float32 pos/nrm/uv/tan + Uint16 idx), nails.png (the nail mask: the diffuse's alpha) and
   feet-normal.png (the normal map), cropped to the part of the texture the feet use.
   python3 tool/make_feet.py [scale] [leg x]"""
import sys, json, base64, pathlib
import numpy as np
from PIL import Image
HERE = pathlib.Path(__file__).resolve().parent.parent / 'body'
S = float(sys.argv[1]) if len(sys.argv) > 1 else 0.75     # foot size
LEGX = float(sys.argv[2]) if len(sys.argv) > 2 else 0.47  # leg centres at x = +-LEGX
V, VT, VN, F = [], [], [], []
for l in open(HERE / 'feet.obj'):
    if l.startswith('v '): V.append([float(x) for x in l.split()[1:4]])
    elif l.startswith('vt '): VT.append([float(x) for x in l.split()[1:3]])
    elif l.startswith('vn '): VN.append([float(x) for x in l.split()[1:4]])
    elif l.startswith('f '): F.append([[int(i) - 1 for i in q.split('/')] for q in l.split()[1:]])
V, VT, VN = np.array(V), np.array(VT), np.array(VN)
xmin, xmax = V[:, 0].min(), V[:, 0].max(); zmid = (V[:, 2].min() + V[:, 2].max()) / 2
# the two feet: z below / above the middle. Ankle = the top ring (x near xmax) of each foot.
out = {}
P, N, T, I = [], [], [], []
key = {}
for f in F:
    for (vi, ti, ni) in f:
        k = (vi, ti, ni)
        if k not in key:
            key[k] = len(P); p = V[vi]; side = 1 if p[2] > zmid else -1   # +z foot -> avatar left (+X)
            P.append((p, side)); T.append(VT[ti]); N.append(VN[ni])
        I.append(key[k])
P0 = np.array([p for p, s in P]); SIDE = np.array([s for p, s in P]); N0 = np.array(N); T0 = np.array(T)
pos = np.zeros_like(P0); nrm = np.zeros_like(N0)
for s in (-1, 1):
    m = SIDE == s; top = m & (P0[:, 0] > xmax - 0.1)
    ay, az = P0[top, 1].mean(), P0[top, 2].mean()
    pos[m, 0] = (P0[m, 2] - az) * S + s * LEGX; pos[m, 1] = (P0[m, 0] - xmin) * S; pos[m, 2] = (P0[m, 1] - ay) * S
nrm[:, 0], nrm[:, 1], nrm[:, 2] = N0[:, 2], N0[:, 0], N0[:, 1]   # same axis swap (a rotation: no flip)
nrm /= np.linalg.norm(nrm, axis=1, keepdims=True) + 1e-9
# texture: u in tile 2; keep rows 600..1024 of the 1024 maps
R0, RH = 600, 424
u = T0[:, 0] - 2; yimg = (1 - T0[:, 1]) * 1024; uv = np.stack([u, (yimg - R0) / RH], 1)
I = np.array(I, np.int64).reshape(-1, 3)
# winding: make triangles face along their normals
e1 = pos[I[:, 1]] - pos[I[:, 0]]; e2 = pos[I[:, 2]] - pos[I[:, 0]]; fn = np.cross(e1, e2)
bad = (fn * (nrm[I[:, 0]] + nrm[I[:, 1]] + nrm[I[:, 2]])).sum(1) < 0
I[bad] = I[bad][:, [0, 2, 1]]
# tangents (direction of +u) and bitangents (+v, image down), per vertex
tan = np.zeros_like(pos); bit = np.zeros_like(pos)
for a, b, c in I:
    d1 = pos[b] - pos[a]; d2 = pos[c] - pos[a]; w1 = uv[b] - uv[a]; w2 = uv[c] - uv[a]; r = w1[0] * w2[1] - w2[0] * w1[1]
    if abs(r) < 1e-12: continue
    t = (d1 * w2[1] - d2 * w1[1]) / r; bb = (d2 * w1[0] - d1 * w2[0]) / r
    tan[[a, b, c]] += t; bit[[a, b, c]] += bb
tan -= nrm * (tan * nrm).sum(1, keepdims=True); tan /= np.linalg.norm(tan, axis=1, keepdims=True) + 1e-9
bit -= nrm * (bit * nrm).sum(1, keepdims=True); bit /= np.linalg.norm(bit, axis=1, keepdims=True) + 1e-9
# the outline uses only the two main foot shapes (the toenails are separate little pieces that would show as specks)
par = list(range(len(pos)))
def find(a):
    while par[a] != a: par[a] = par[par[a]]; a = par[a]
    return a
for a, b, c in I:
    ra, rb, rc = find(a), find(b), find(c); par[rb] = ra; par[find(rc)] = ra
roots = np.array([find(i) for i in range(len(pos))]); u, cnt = np.unique(roots, return_counts=True); big = set(u[np.argsort(-cnt)[:2]])
HI = I[np.array([roots[t[0]] in big for t in I])]
b64 = lambda a, t: base64.b64encode(np.ascontiguousarray(a, t).tobytes()).decode()
od = HERE / 'out'; od.mkdir(exist_ok=True)
json.dump({'count': int(len(I) * 3), 'verts': int(len(pos)), 'scale': S, 'legX': LEGX, 'height': float(pos[:, 1].max()),
           'pos': b64(pos, np.float32), 'nrm': b64(nrm, np.float32), 'uv': b64(uv, np.float32), 'tu': b64(tan, np.float32), 'tv': b64(-bit, np.float32),
           'idx': b64(I.reshape(-1), np.uint16), 'hullIdx': b64(HI.reshape(-1), np.uint16)}, open(od / 'feet.json', 'w'), separators=(',', ':'))
d = np.asarray(Image.open(HERE / 'Genesis8femaleshape1_diff.png').convert('RGBA'))[R0:R0 + RH]
Image.fromarray(d[..., 3]).save(od / 'nails.png')
Image.open(HERE / 'Genesis8femaleshape1_nmap.png').convert('RGB').crop((0, R0, 1024, R0 + RH)).save(od / 'feet-normal.png')
print('feet:', len(pos), 'verts', len(I), 'tris; box', pos.min(0).round(3), pos.max(0).round(3))
