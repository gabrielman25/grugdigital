/* Image2LoPol model builder in the browser: the same block models as tool/lopol.py, made from a model.json object, with
   everything the Accessory Studio needs to paint and bake it (reference picture, painting map, light and normal maps).
   LoPolCore.build(model) -> a template object, the same shape LoPolBake.load() returns, so LoPolBake.bake() works on it.
   LoPolCore.clay(model, yaws) -> canvas: the grey model from several sides (for checking proportions).
   See MODEL_FORMAT.md (or AccessoryStudio.modelFormat()) for model.json. */
(function () {
'use strict';
const REF_W = 1536, REF_H = 1024, AMB = .5, DIF = .5, GREY = .8, SHADE_REF = AMB + DIF * .75, ATLAS = 1024, SIZE = 1024, LIVE = 128, LRES = 128, HAT_BRIM_Y = 4.88;
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const LIGHT = norm([-.45, .8, .4]);
function rotM(deg){ const [x, y, z] = [0, 1, 2].map(i => ((deg || [])[i] || 0) * Math.PI / 180), cx = Math.cos(x), sx = Math.sin(x), cy = Math.cos(y), sy = Math.sin(y), cz = Math.cos(z), sz = Math.sin(z);
  const X = [[1, 0, 0], [0, cx, -sx], [0, sx, cx]], Y = [[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]], Z = [[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]];
  const m = (A, B) => A.map(r => [0, 1, 2].map(j => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j])); return m(Z, m(Y, X)); }
const app = (M, p) => [0, 1, 2].map(i => M[i][0] * p[0] + M[i][1] * p[1] + M[i][2] * p[2]);
function rng(seed){ let s = seed >>> 0 || 1; return () => (s = Math.imul(s ^ (s >>> 15), 2246822507) + 0x9e3779b9 >>> 0) / 4294967296; }

/* ---------- parts -> charts (grid of quads or flat polygon) ---------- */
const BOX = { front: [[-1, 1, 1], [1, 1, 1], [-1, -1, 1], [1, -1, 1]], back: [[1, 1, -1], [-1, 1, -1], [1, -1, -1], [-1, -1, -1]], right: [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1]],
  left: [[-1, 1, -1], [-1, 1, 1], [-1, -1, -1], [-1, -1, 1]], top: [[-1, 1, -1], [1, 1, -1], [-1, 1, 1], [1, 1, 1]], bottom: [[-1, -1, 1], [1, -1, 1], [-1, -1, -1], [1, -1, -1]] };
const OPP = { front: 'back', back: 'front', left: 'right', right: 'left', top: 'bottom', bottom: 'top' };
const chart = (part, side, kind, data, opposite = null, flip = 'h') => ({ part, side, kind, P: kind === 'grid' ? data : null, V: kind === 'poly' ? data : null, opposite, flip, name: part + '.' + side });
function partBox(p){
  const [w, h, d] = p.size, [tx, tz] = p.taper || [1, 1], [ox, oz] = p.shift || [0, 0], [bx, bz] = p.taperBottom || [1, 1], skip = new Set(p.omit || []);
  const c = ([sx, sy, sz]) => sy > 0 ? [sx * w / 2 * tx + ox, h / 2, sz * d / 2 * tz + oz] : [sx * w / 2 * bx, -h / 2, sz * d / 2 * bz];
  return Object.entries(BOX).filter(([s]) => !skip.has(s)).map(([s, cs]) => chart(p.name, s, 'grid', [[c(cs[0]), c(cs[1])], [c(cs[2]), c(cs[3])]], OPP[s], s === 'top' || s === 'bottom' ? 'v' : 'h'));
}
function partLathe(p){
  const prof = p.profile, n = p.sides || 8, a0 = (p.startAngle || 0) * Math.PI / 180, [sx, sz] = p.scale || [1, 1], cu = p.curl || {}, rmax = Math.max(...prof.map(q => q[0])), r0 = cu.from || 0, amt = cu.amount || 0;
  const ang = Array.from({ length: n + 1 }, (_, c) => -Math.PI + a0 + 2 * Math.PI * c / n);
  const lift = (r, a) => !amt || r <= r0 ? 0 : amt * ((r - r0) / Math.max(1e-6, rmax - r0)) ** 2 * Math.sin(a) ** 2;
  const out = [chart(p.name, 'side', 'grid', prof.map(([r, y]) => ang.map(a => [r * Math.sin(a) * sx, y + lift(r, a), r * Math.cos(a) * sz])))];
  const caps = p.caps || 'both', [rt, yt] = prof[0], [rb, yb] = prof[prof.length - 1];
  if (rt > 1e-6 && (caps === 'both' || caps === 'top')) out.push(chart(p.name, 'top', 'poly', ang.slice(0, -1).map(a => [rt * Math.sin(a) * sx, yt, rt * Math.cos(a) * sz]).reverse(), 'bottom', 'v'));
  if (rb > 1e-6 && (caps === 'both' || caps === 'bottom')) out.push(chart(p.name, 'bottom', 'poly', ang.slice(0, -1).map(a => [rb * Math.sin(a) * sx, yb, rb * Math.cos(a) * sz]), 'top', 'v'));
  return out;
}
const partCyl = p => partLathe(Object.assign({}, p, { profile: [[p.radiusTop ?? p.radius, p.height / 2], [p.radius, -p.height / 2]] }));
function partStrap(p){
  const pts = p.points, w = p.width, t = p.thickness ?? .05, n = pts.length, hint = norm(p.normal || [0, 0, 1]);
  const T = pts.map((_, i) => norm(sub(pts[Math.min(i + 1, n - 1)], pts[Math.max(i - 1, 0)])));
  const N = T.map((Ti, i) => { const H = p.normals ? norm(p.normals[i]) : hint; return norm(sub(H, mul(Ti, dot(Ti, H)))); }), R = N.map((Ni, i) => norm(cross(Ni, T[i])));
  const out = [];
  for (const [side, D, hd, Rt, hr, opp] of [['front', N, t / 2, R, w / 2, 'back'], ['back', N.map(v => mul(v, -1)), t / 2, R.map(v => mul(v, -1)), w / 2, 'front'],
    ['edge1', R, w / 2, N.map(v => mul(v, -1)), t / 2, 'edge2'], ['edge2', R.map(v => mul(v, -1)), w / 2, N, t / 2, 'edge1']])
    out.push(chart(p.name, side, 'grid', pts.map((q, i) => [sub(add(q, mul(D[i], hd)), mul(Rt[i], hr)), add(add(q, mul(D[i], hd)), mul(Rt[i], hr))]), opp));
  if (p.caps !== false) { const cap = (i, s) => { const c = [add(sub(add(pts[i], mul(N[i], t / 2)), mul(R[i], w / 2)), [0, 0, 0]), add(add(pts[i], mul(N[i], t / 2)), mul(R[i], w / 2)), add(sub(pts[i], mul(N[i], t / 2)), mul(R[i], w / 2)), sub(sub(pts[i], mul(N[i], t / 2)), mul(R[i], w / 2))]; return s > 0 ? c : c.reverse(); };
    out.push(chart(p.name, 'end1', 'poly', cap(0, 1), 'end2'), chart(p.name, 'end2', 'poly', cap(n - 1, -1), 'end1')); }
  return out;
}
const BUILD = { box: partBox, cylinder: partCyl, lathe: partLathe, strap: partStrap };
const pts = c => c.kind === 'grid' ? c.P.flat() : c.V;
function polyN(V){ const c = V.reduce((a, v) => add(a, v), [0, 0, 0]).map(x => x / V.length); let s = [0, 0, 0]; for (let i = 0; i < V.length; i++) s = add(s, cross(sub(V[i], c), sub(V[(i + 1) % V.length], c))); return norm(s); }
function fixCaps(cs){ const mid = cs.flatMap(pts).reduce((a, v) => add(a, v), [0, 0, 0]).map((x, _, a) => x / cs.flatMap(pts).length);
  cs.forEach(c => { if (c.kind !== 'poly') return; const m = c.V.reduce((a, v) => add(a, v), [0, 0, 0]).map(x => x / c.V.length); if (dot(sub(m, mid), polyN(c.V)) < 0) c.V = c.V.slice().reverse(); }); }
function buildCharts(model){
  let charts = [];
  for (const p of model.parts) { if (p.hidden) continue; const B = BUILD[p.type]; if (!B) throw new Error(`Part "${p.name}": unknown type "${p.type}" (box, cylinder, lathe, strap)`);
    const cs = B(p); fixCaps(cs); const R = rotM(p.rot), c = p.center || [0, 0, 0], ex = p.explode || [0, 0, 0], grp = p.group || p.name.replace(/_/g, ' ').replace(/^./, m => m.toUpperCase());
    cs.forEach(ch => { if (ch.kind === 'grid') ch.P = ch.P.map(r => r.map(q => add(app(R, q), c))); else ch.V = ch.V.map(q => add(app(R, q), c)); ch.explode = ex; ch.group = grp; });
    let group = cs; const mir = p.mirror ? (typeof p.mirror === 'string' ? [p.mirror] : p.mirror) : [];
    for (const ax of mir) { const f = [0, 1, 2].map(i => 'xyz'[i] === ax ? -1 : 1), fl = q => [q[0] * f[0], q[1] * f[1], q[2] * f[2]];
      group = group.concat(group.map(ch => { const m = chart(ch.part + '_m' + ax, ch.side, ch.kind, ch.kind === 'grid' ? ch.P.map(r => r.map(fl).reverse()) : ch.V.map(fl).reverse(), ch.opposite, ch.flip); m.explode = fl(ch.explode); m.group = ch.group; return m; })); }
    charts = charts.concat(group); }
  charts.forEach(ch => { if (ch.kind !== 'grid') return; const P = ch.P, len = (a, b) => Math.hypot(...sub(a, b));
    let hl = 0, wl = 0; for (let r = 1; r < P.length; r++) { let s = 0; for (let c = 0; c < P[0].length; c++) s += len(P[r][c], P[r - 1][c]); hl += s / P[0].length; }
    for (let c = 1; c < P[0].length; c++) { let s = 0; for (let r = 0; r < P.length; r++) s += len(P[r][c], P[r][c - 1]); wl += s / P.length; }
    if (hl > 2.5 * wl) ch.P = transposeStrip(P); });
  const dens = layout(charts, ATLAS, 8), groups = [];
  charts.forEach(c => { if (!groups.includes(c.group)) groups.push(c.group); }); charts.forEach(c => c.gi = groups.indexOf(c.group));
  return { charts, dens, groups };
}
function transposeStrip(P){ const R = P.slice().reverse(); return R[0].map((_, c) => R.map(row => row[c])); }   // P[::-1].transpose(1, 0, 2)

/* ---------- atlas layout: one texel density, shelf packing, even sizes (so a half-size map lines up) ---------- */
function dims(ch, dens){
  if (ch.kind === 'grid') { const P = ch.P, R = P.length, C = P[0].length, len = (a, b) => Math.hypot(...sub(a, b));
    const cols = [], rows = []; for (let c = 1; c < C; c++) { let s = 0; for (let r = 0; r < R; r++) s += len(P[r][c], P[r][c - 1]); cols.push(Math.max(1, Math.round(s / R * dens))); }
    for (let r = 1; r < R; r++) { let s = 0; for (let c = 0; c < C; c++) s += len(P[r][c], P[r - 1][c]); rows.push(Math.max(1, Math.round(s / C * dens))); }
    cols[cols.length - 1] += cols.reduce((a, b) => a + b, 0) % 2; rows[rows.length - 1] += rows.reduce((a, b) => a + b, 0) % 2;
    ch.cx = [0]; cols.forEach(v => ch.cx.push(ch.cx[ch.cx.length - 1] + v)); ch.cy = [0]; rows.forEach(v => ch.cy.push(ch.cy[ch.cy.length - 1] + v)); ch.w = ch.cx[ch.cx.length - 1]; ch.h = ch.cy[ch.cy.length - 1];
  } else { const V = ch.V, n = polyN(V); let e1 = sub([1, 0, 0], mul(n, n[0])); if (Math.hypot(...e1) < .3) e1 = sub([0, 0, 1], mul(n, n[2])); e1 = norm(e1); const e2 = cross(e1, n);
    const a = V.map(v => dot(sub(v, V[0]), e1)), b = V.map(v => dot(sub(v, V[0]), e2)); ch.basis = { V0: V[0], e1, e2, amin: Math.min(...a), bmin: Math.min(...b), dens };
    ch.w = Math.max(2, Math.ceil((Math.max(...a) - Math.min(...a)) * dens)); ch.h = Math.max(2, Math.ceil((Math.max(...b) - Math.min(...b)) * dens)); ch.w += ch.w % 2; ch.h += ch.h % 2; }
}
function pack(charts, S, dens, pad){ charts.forEach(c => dims(c, dens)); let x = pad, y = pad, shelf = 0;
  for (const c of charts.slice().sort((a, b) => b.h - a.h)) { if (c.w + 2 * pad > S) return false; if (x + c.w + pad > S) { x = pad; y += shelf + pad; shelf = 0; } c.x0 = x; c.y0 = y; x += c.w + pad; shelf = Math.max(shelf, c.h); }
  return y + shelf + pad <= S; }
function layout(charts, S, pad){ let lo = 1, hi = 4096; for (let i = 0; i < 30; i++) { const m = (lo + hi) / 2; if (pack(charts, S, m, pad)) lo = m; else hi = m; } pack(charts, S, lo, pad); return lo; }

/* ---------- mesh (flat triangles, atlas uv in pixels) and the 3D point of every texel ---------- */
function mesh(charts){
  const pos = [], uv = [], cid = [];
  charts.forEach((ch, k) => {
    if (ch.kind === 'grid') { const P = ch.P, U = (r, c) => [ch.x0 + ch.cx[c], ch.y0 + ch.cy[r]];
      for (let r = 0; r < P.length - 1; r++) for (let c = 0; c < P[0].length - 1; c++) for (const tri of [[[r, c], [r + 1, c], [r + 1, c + 1]], [[r, c], [r + 1, c + 1], [r, c + 1]]]) { pos.push(tri.map(([a, b]) => P[a][b])); uv.push(tri.map(([a, b]) => U(a, b))); cid.push(k); } }
    else { const { V0, e1, e2, amin, bmin, dens } = ch.basis, U = v => [ch.x0 + (dot(sub(v, V0), e1) - amin) * dens, ch.y0 + (dot(sub(v, V0), e2) - bmin) * dens];
      for (let i = 1; i < ch.V.length - 1; i++) { const tri = [ch.V[0], ch.V[i], ch.V[i + 1]]; pos.push(tri); uv.push(tri.map(U)); cid.push(k); } } });
  return { pos, uv, cid, nrm: pos.map(t => norm(cross(sub(t[1], t[0]), sub(t[2], t[0])))) };
}
function texels(ch, step = 1){   // [h][w] of {X, N} at texel centres (every `step` texels)
  const out = [];
  if (ch.kind === 'grid') { const P = ch.P;
    for (let y = 0; y < ch.h; y += step) { const row = []; let r = 0; while (r < ch.cy.length - 2 && y + step / 2 >= ch.cy[r + 1]) r++;
      const t = (y + step / 2 - ch.cy[r]) / (ch.cy[r + 1] - ch.cy[r]);
      for (let x = 0; x < ch.w; x += step) { let c = 0; while (c < ch.cx.length - 2 && x + step / 2 >= ch.cx[c + 1]) c++; const s = (x + step / 2 - ch.cx[c]) / (ch.cx[c + 1] - ch.cx[c]);
        const a = P[r][c], b = P[r + 1][c], d = P[r + 1][c + 1], e = P[r][c + 1];
        if (t >= s) row.push({ X: add(add(mul(a, 1 - t), mul(b, t - s)), mul(d, s)), N: norm(cross(sub(b, a), sub(d, a))) });
        else row.push({ X: add(add(mul(a, 1 - s), mul(d, t)), mul(e, s - t)), N: norm(cross(sub(d, a), sub(e, a))) }); }
      out.push(row); } }
  else { const { V0, e1, e2, amin, bmin, dens } = ch.basis, N = polyN(ch.V);
    for (let y = 0; y < ch.h; y += step) { const row = []; for (let x = 0; x < ch.w; x += step) row.push({ X: add(add(V0, mul(e1, amin + (x + step / 2) / dens)), mul(e2, bmin + (y + step / 2) / dens)), N }); out.push(row); } }
  return out;
}

/* ---------- cameras and a z-buffer rasteriser ---------- */
function basis(yaw, pitch){ const y = yaw * Math.PI / 180, p = pitch * Math.PI / 180, v = [Math.cos(p) * Math.sin(y), Math.sin(p), Math.cos(p) * Math.cos(y)], f = mul(v, -1), r = norm(cross(f, [0, 1, 0])); return { r, u: cross(r, f), f, v }; }
function fitViews(views, charts, W, H, margin = .84){
  const vs = views.map(v => Object.assign({}, v, basis(v.yaw, v.pitch))), n = vs.length;
  const P = vs.map((v, i) => charts.flatMap(ch => pts(ch).map(q => { const Q = i === 1 ? add(q, ch.explode) : q; return [dot(Q, v.r), -dot(Q, v.u)]; })));
  const span = Math.max(Math.max(...P.map(L => Math.max(...L.map(p => p[0])) - Math.min(...L.map(p => p[0])))) / (W / n), Math.max(...P.map(L => Math.max(...L.map(p => p[1])) - Math.min(...L.map(p => p[1])))) / H), s = margin / span;
  vs.forEach((v, i) => { const L = P[i], mx = (Math.max(...L.map(p => p[0])) + Math.min(...L.map(p => p[0]))) / 2, my = (Math.max(...L.map(p => p[1])) + Math.min(...L.map(p => p[1]))) / 2;
    v.scale = s; v.ox = W / n * (i + .5) - mx * s; v.oy = H * .5 - my * s; });
  return vs;
}
const viewLight = v => norm(add(add(mul(v.r, -.45), mul(v.u, .75)), mul(v.f, -.5)));
const proj = (v, X) => [dot(X, v.r) * v.scale + v.ox, -dot(X, v.u) * v.scale + v.oy, dot(X, v.f)];
function raster(tris, W, H){   // tris: [[[x,y,z] x3], id]
  const depth = new Float32Array(W * H).fill(Infinity), id = new Int32Array(W * H).fill(-1), tri = new Int32Array(W * H).fill(-1);
  tris.forEach(([[a, b, c], k], ti) => { const area = (b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1]); if (Math.abs(area) < 1e-9) return;
    const x0 = Math.max(0, Math.floor(Math.min(a[0], b[0], c[0]))), x1 = Math.min(W, Math.ceil(Math.max(a[0], b[0], c[0])) + 1), y0 = Math.max(0, Math.floor(Math.min(a[1], b[1], c[1]))), y1 = Math.min(H, Math.ceil(Math.max(a[1], b[1], c[1])) + 1);
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const X = x + .5, Y = y + .5;
      const w0 = ((b[0] - X) * (c[1] - Y) - (c[0] - X) * (b[1] - Y)) / area, w1 = ((c[0] - X) * (a[1] - Y) - (a[0] - X) * (c[1] - Y)) / area, w2 = 1 - w0 - w1;
      if (w0 < -1e-4 || w1 < -1e-4 || w2 < -1e-4) continue; const z = w0 * a[2] + w1 * b[2] + w2 * c[2], i = y * W + x; if (z < depth[i]) { depth[i] = z; id[i] = k; tri[i] = ti; } } });
  return { depth, id, tri };
}
/* the grey reference: every view side by side, darker lines where faces meet; ss = supersampling */
function clayCanvas(M, charts, vs, W, H, ss = 2){
  const c = document.createElement('canvas'); c.width = W * ss; c.height = H * ss; const x = c.getContext('2d'), img = x.createImageData(W * ss, H * ss), d = img.data; d.fill(255);
  vs.forEach((v, i) => { const lt = viewLight(v), tris = M.pos.map((t, k) => [t.map(q => { const p = proj(v, i === 1 ? add(q, charts[M.cid[k]].explode) : q); return [p[0] * ss, p[1] * ss, p[2]]; }), M.cid[k]]);
    const R = raster(tris, W * ss, H * ss);
    for (let p = 0; p < W * H * ss * ss; p++) { if (R.tri[p] < 0) continue; const sh = AMB + DIF * Math.max(0, dot(M.nrm[R.tri[p]], lt)); let g = GREY * 255 * sh;
      const px = p % (W * ss), k = R.id[p]; if ((px > 0 && R.id[p - 1] !== k && R.id[p - 1] >= 0) || (p >= W * ss && R.id[p - W * ss] !== k && R.id[p - W * ss] >= 0)) g *= .8;
      d[p * 4] = d[p * 4 + 1] = d[p * 4 + 2] = g; } });
  x.putImageData(img, 0, 0); if (ss === 1) return c;
  const o = document.createElement('canvas'); o.width = W; o.height = H; const ox = o.getContext('2d'); ox.imageSmoothingQuality = 'high'; ox.drawImage(c, 0, 0, W, H); return o;
}

/* ---------- materials: tangent-space normal maps (same recipes as tool/lopol.py MATERIALS) ---------- */
function noiseFn(seed){ const r = rng(seed), g = Float32Array.from({ length: 4096 }, r);
  return (u, v, sc) => { const x = u / sc, y = v / sc, x0 = Math.floor(x), y0 = Math.floor(y); let fx = x - x0, fy = y - y0; fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    const G = (a, b) => g[((b % 64 + 64) % 64) * 64 + ((a % 64 + 64) % 64)]; return (G(x0, y0) * (1 - fx) + G(x0 + 1, y0) * fx) * (1 - fy) + (G(x0, y0 + 1) * (1 - fx) + G(x0 + 1, y0 + 1) * fx) * fy; }; }
function cellsFn(seed){ const r = rng(seed), j = Float32Array.from({ length: 2048 }, r);
  return (u, v, sc) => { const x = u / sc, y = v / sc, xi = Math.floor(x), yi = Math.floor(y); let best = 9;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const cx = xi + dx, cy = yi + dy, k = (((cy % 32) + 32) % 32 * 32 + (((cx % 32) + 32) % 32)) * 2, dd = (x - cx - j[k]) ** 2 + (y - cy - j[k + 1]) ** 2; if (dd < best) best = dd; }
    return 1 - Math.min(1, Math.sqrt(best)); }; }
const nz = [1, 3, 4, 5, 6, 7, 9, 10].reduce((o, s) => (o[s] = noiseFn(s), o), {}), cl = [2, 8].reduce((o, s) => (o[s] = cellsFn(s), o), {});
const S_ = Math.sin, A_ = Math.abs, PI = Math.PI, md = (a, b) => ((a % b) + b) % b;
const MATERIALS = {   // [height(u, v) in face units, seams by default, amplitude]
  none: [() => 0, false, 0], glass: [() => 0, false, 0], plastic: [(u, v) => nz[1](u, v, .6) * .15, false, .4],
  leather: [(u, v) => cl[2](u, v, .045) ** 2 + .3 * nz[3](u, v, .02), true, 1], suede: [(u, v) => nz[4](u, v, .012) * .6 + nz[5](u, v, .05) * .4, true, .7],
  canvas: [(u, v) => S_(u / .012 * PI) * S_(v / .012 * PI) * .5 + .5, true, .8], denim: [(u, v) => (S_((u + v) / .016 * PI) * .5 + .5) * .8 + nz[6](u, v, .03) * .2, true, .9],
  wool: [(u, v) => A_(S_(v / .05 * PI)) ** .5 * (.6 + .4 * A_(S_((u * 2 + A_(md(v, .1) - .05) * 6) / .05 * PI))), true, 1.2],
  knit: [(u, v) => A_(S_(u / .045 * PI)) * (.5 + .5 * A_(S_((v + A_(md(u, .09) - .045)) / .045 * PI))), true, 1.2],
  quilted: [(u, v) => 1 - (Math.min(A_(md(u + v, .3) - .15), A_(md(u - v, .3) - .15)) < .012 ? 1 : 0), true, 1],
  metal: [(u, v) => nz[7](u * .05, v * 8, .05) * .4 + cl[8](u, v, .3) ** 6 * -.6, false, .6], wood: [(u, v) => S_((v + nz[9](u, v, .25) * .15) / .03 * PI) * .5 + .5, false, .7],
  fur: [(u, v) => nz[10](u * 4, v * .6, .02), false, 1] };
function normalAtlas(model, charts, dens, res){
  const k = res / ATLAS, d = dens * k, Hh = new Float32Array(res * res), has = new Uint8Array(res * res), ew = .035, base = n => n.split('_m')[0];
  charts.forEach(ch => { const p = model.parts.find(q => q.name === base(ch.part)) || {}, m = MATERIALS[p.material || model.material || 'none'] || MATERIALS.none, seams = p.seams ?? m[1];
    const x0 = Math.floor(ch.x0 * k), y0 = Math.floor(ch.y0 * k), x1 = Math.min(res, Math.ceil((ch.x0 + ch.w) * k)), y1 = Math.min(res, Math.ceil((ch.y0 + ch.h) * k)), W = ch.w / dens, HH = ch.h / dens;
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const u = (x + .5 - ch.x0 * k) / d, v = (y + .5 - ch.y0 * k) / d; let h = m[0](u, v) * m[2] * .012;
      if (seams && ch.kind === 'grid') { const dd = Math.min(u, W - u, v, HH - v), groove = Math.max(0, 1 - A_(dd - ew) / .012), along = Math.min(u, W - u) < Math.min(v, HH - v) ? v : u;
        h += -groove * .01 + (S_(along / .04 * PI) > .2 ? 1 : 0) * Math.max(0, 1 - A_(dd - ew) / .006) * .006 + Math.max(0, 1 - dd / ew) * -.004; }
      Hh[y * res + x] = h; has[y * res + x] = 1; } });
  const N = new Float32Array(res * res * 3), at = (x, y) => Hh[((y + res) % res) * res + ((x + res) % res)];
  for (let y = 0; y < res; y++) for (let x = 0; x < res; x++) { const i = y * res + x; if (!has[i]) { N[i * 3 + 2] = 1; continue; }
    const gx = (at(x + 1, y) - at(x - 1, y)) * d / 2, gy = (at(x, y + 1) - at(x, y - 1)) * d / 2, l = Math.hypot(gx, gy, 1); N[i * 3] = -gx / l; N[i * 3 + 1] = -gy / l; N[i * 3 + 2] = 1 / l; }
  return N;
}

/* ---------- light: AO, a soft room light, glow; on a grid over the atlas, upsampled ---------- */
function anyHit(o, d, tmax, T, eps){ for (let i = 0; i < T.length; i += 9) { const ax = T[i], ay = T[i + 1], az = T[i + 2], e1x = T[i + 3] - ax, e1y = T[i + 4] - ay, e1z = T[i + 5] - az, e2x = T[i + 6] - ax, e2y = T[i + 7] - ay, e2z = T[i + 8] - az;
    const px = d[1] * e2z - d[2] * e2y, py = d[2] * e2x - d[0] * e2z, pz = d[0] * e2y - d[1] * e2x, det = e1x * px + e1y * py + e1z * pz; if (det > -1e-12 && det < 1e-12) continue;
    const inv = 1 / det, sx = o[0] - ax, sy = o[1] - ay, sz = o[2] - az, u = (sx * px + sy * py + sz * pz) * inv; if (u < 0 || u > 1) continue;
    const qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x, v = (d[0] * qx + d[1] * qy + d[2] * qz) * inv; if (v < 0 || u + v > 1) continue;
    const t = (e2x * qx + e2y * qy + e2z * qz) * inv; if (t > eps && t < tmax) return true; } return false; }
function lightGrid(charts, res){
  const k = res / ATLAS, owner = new Int32Array(res * res).fill(-1), P = new Float32Array(res * res * 3), N = new Float32Array(res * res * 3);
  charts.forEach((ch, ci) => { const tx = texels(ch);
    const gx0 = Math.floor(ch.x0 * k), gx1 = Math.min(res, Math.ceil((ch.x0 + ch.w) * k)), gy0 = Math.floor(ch.y0 * k), gy1 = Math.min(res, Math.ceil((ch.y0 + ch.h) * k));
    for (let gy = gy0; gy < gy1; gy++) for (let gx = gx0; gx < gx1; gx++) { const ix = Math.min(ch.w - 1, Math.max(0, Math.floor((gx + .5) / k - ch.x0))), iy = Math.min(ch.h - 1, Math.max(0, Math.floor((gy + .5) / k - ch.y0)));
      const t = tx[iy][ix], i = gy * res + gx; owner[i] = ci; P.set(t.X, i * 3); N.set(t.N, i * 3); } });
  return { owner, P, N };
}
function spread(m, maps, r, steps = 4){ const f = m.slice(); for (let it = 0; it < steps; it++) { const nf = f.slice();
  for (let y = 0; y < r; y++) for (let x = 0; x < r; x++) { const i = y * r + x; if (f[i]) continue; const nb = []; for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const j = ((y + dy + r) % r) * r + ((x + dx + r) % r); if (f[j]) nb.push(j); }
    if (!nb.length) continue; nf[i] = 1; for (const [mp, ch] of maps) for (let c = 0; c < ch; c++) mp[i * ch + c] = nb.reduce((s, j) => s + mp[j * ch + c], 0) / nb.length; } f.set(nf); } }
function upTo(src, r, ch, n){ const out = new Float32Array(n * n * ch), k = r / n;
  for (let y = 0; y < n; y++) { const sy = Math.max(0, Math.min(r - 1, (y + .5) * k - .5)), y0 = Math.floor(sy), y1 = Math.min(r - 1, y0 + 1), fy = sy - y0;
    for (let x = 0; x < n; x++) { const sx = Math.max(0, Math.min(r - 1, (x + .5) * k - .5)), x0 = Math.floor(sx), x1 = Math.min(r - 1, x0 + 1), fx = sx - x0;
      for (let c = 0; c < ch; c++) out[(y * n + x) * ch + c] = (src[(y0 * r + x0) * ch + c] * (1 - fx) + src[(y0 * r + x1) * ch + c] * fx) * (1 - fy) + (src[(y1 * r + x0) * ch + c] * (1 - fx) + src[(y1 * r + x1) * ch + c] * fx) * fy; } }
  return out; }

/* ---------- the whole template ---------- */
const b64 = a => { const u = new Uint8Array(a.buffer, a.byteOffset, a.byteLength); let s = ''; for (let i = 0; i < u.length; i += 32768) s += String.fromCharCode.apply(null, u.subarray(i, i + 32768)); return btoa(s); };
const canvasRGBA = (n, fill) => { const c = document.createElement('canvas'); c.width = c.height = n; const x = c.getContext('2d'), im = x.createImageData(n, n); fill(im.data); x.putImageData(im, 0, 0); return c; };
function wearOf(model, M){
  const w = model.wear; if (!w) return null;
  const o = Object.assign({ on: 'back', scale: 1, rot: [0, 0, 0], offset: [0, 0, 0] }, w);
  if (o.fit === 'hat') { const R = rotM(o.rot), s = Array.isArray(o.scale) ? o.scale : [o.scale, o.scale, o.scale], Q = M.pos.flat().map(p => app(R, [p[0] * s[0], p[1] * s[1], p[2] * s[2]]));
    const mm = i => [Math.min(...Q.map(q => q[i])), Math.max(...Q.map(q => q[i]))]; o.offset = [-(mm(0)[0] + mm(0)[1]) / 2, HAT_BRIM_Y - mm(1)[0], -(mm(2)[0] + mm(2)[1]) / 2]; }
  return o;
}
function problems(model){
  const out = []; if (!model || !Array.isArray(model.parts) || !model.parts.length) return ['model.parts must be a list of parts'];
  model.parts.forEach((p, i) => { const nm = p.name || `#${i}`; if (!p.name) out.push(`part ${i}: needs a name`); if (!BUILD[p.type]) out.push(`${nm}: type must be box, cylinder, lathe or strap`);
    if (p.type === 'box' && !(Array.isArray(p.size) && p.size.length === 3)) out.push(`${nm}: box needs size [w, h, d]`);
    if (p.type === 'cylinder' && !(p.radius > 0 && p.height > 0)) out.push(`${nm}: cylinder needs radius and height`);
    if (p.type === 'lathe' && !(Array.isArray(p.profile) && p.profile.length >= 2)) out.push(`${nm}: lathe needs a profile [[radius, y], ...] from top to bottom`);
    if (p.type === 'strap' && !(Array.isArray(p.points) && p.points.length >= 2 && p.width > 0)) out.push(`${nm}: strap needs points (2 or more) and width`); });
  const names = model.parts.map(p => p.name); names.forEach((n, i) => { if (names.indexOf(n) !== i) out.push(`two parts are called "${n}"`); });
  return out;
}
async function build(model, onStep = () => {}){
  const bad = problems(model); if (bad.length) throw new Error('model.json: ' + bad.join('; '));
  const step = async m => { onStep(m); await new Promise(r => setTimeout(r, 0)); };
  await step('Building the blocks');
  const { charts, dens, groups } = buildCharts(model), M = mesh(charts), views = model.views || [{ yaw: 35, pitch: 22 }, { yaw: 215, pitch: 22 }];
  const vs = fitViews(views, charts, REF_W, REF_H);
  await step('Rendering the reference');
  const ref = clayCanvas(M, charts, vs, REF_W, REF_H, 2);
  // the painting map at half the atlas: which face, where it lands in each view, how squarely it is seen, its shading
  await step('Mapping the texture');
  const h2 = ATLAS / 2, cid = new Int16Array(h2 * h2).fill(-1), xy = vs.map(() => [new Uint16Array(h2 * h2), new Uint16Array(h2 * h2)]), wt = vs.map(() => new Uint8Array(h2 * h2)), sh = vs.map(() => new Uint8Array(h2 * h2));
  const bufs = vs.map((v, i) => raster(M.pos.map((t, k) => [t.map(q => proj(v, i === 1 ? add(q, charts[M.cid[k]].explode) : q)), M.cid[k]]), REF_W, REF_H));
  charts.forEach((ch, k) => { const T = texels(ch, 2), X0 = ch.x0 / 2, Y0 = ch.y0 / 2;
    T.forEach((row, yy) => row.forEach((t, xx) => { const i = (Y0 + yy) * h2 + X0 + xx; cid[i] = k;
      vs.forEach((v, vi) => { const p = proj(v, vi === 1 ? add(t.X, ch.explode) : t.X), px = Math.max(0, Math.min(REF_W - 1, Math.floor(p[0]))), py = Math.max(0, Math.min(REF_H - 1, Math.floor(p[1]))), B = bufs[vi], j = py * REF_W + px;
        let vis = B.id[j] === k && Math.abs(B.depth[j] - p[2]) < 2.5 / v.scale;
        if (vis) for (const [dx, dy] of [[2, 0], [-2, 0], [0, 2], [0, -2]]) { const q = Math.max(0, Math.min(REF_H - 1, py + dy)) * REF_W + Math.max(0, Math.min(REF_W - 1, px + dx)); if (B.id[q] !== k) { vis = 'edge'; break; } }
        const facing = -dot(t.N, v.f); xy[vi][0][i] = Math.max(0, Math.min(65535, p[0] * 16)); xy[vi][1][i] = Math.max(0, Math.min(65535, p[1] * 16));
        wt[vi][i] = vis && facing > .05 ? Math.min(255, facing * 255) * (vis === 'edge' ? .6 : 1) : 0;
        const lt = viewLight(v); sh[vi][i] = Math.min(255, (AMB + DIF * Math.max(0, dot(t.N, lt))) * 255); }); })); });
  // light: AO and a soft room light with shadows, glow from emissive parts
  await step('Baking ambient occlusion');
  const base = n => n.split('_m')[0], em = {}; model.parts.forEach(p => { if (p.emissive) em[p.name] = p.emissive; });
  const flat = new Float32Array(M.pos.length * 9); M.pos.forEach((t, i) => t.forEach((q, j) => flat.set(q, i * 9 + j * 3)));
  const blk = new Float32Array(M.pos.filter((t, i) => !em[base(charts[M.cid[i]].part)]).length * 9); { let o = 0; M.pos.forEach((t, i) => { if (em[base(charts[M.cid[i]].part)]) return; t.forEach(q => { blk.set(q, o); o += 3; }); }); }
  const all = M.pos.flat(), size = Math.max(...[0, 1, 2].map(a => Math.max(...all.map(q => q[a])) - Math.min(...all.map(q => q[a])))), eps = size * 2e-3, lt = model.light || {};
  const G = lightGrid(charts, LRES), r = LRES, ao = new Float32Array(r * r), room = new Float32Array(r * r), emit = new Float32Array(r * r * 3), K = lt.ao_rays || 24, reach = size * (lt.ao_reach || .35), Ld = norm(lt.room_dir || [-.35, 1, .45]), rnd = rng(7);
  for (let i = 0; i < r * r; i++) { const ci = G.owner[i]; if (ci < 0) continue; const n = [G.N[i * 3], G.N[i * 3 + 1], G.N[i * 3 + 2]], o = add([G.P[i * 3], G.P[i * 3 + 1], G.P[i * 3 + 2]], mul(n, eps));
    const T = norm(Math.abs(n[1]) < .9 ? cross([0, 1, 0], n) : cross([1, 0, 0], n)), B = cross(n, T); let vis = 0;
    for (let j = 0; j < K; j++) { const u1 = (j + rnd()) / K, rr = Math.sqrt(u1), ph = 2 * Math.PI * rnd(); if (!anyHit(o, add(add(mul(T, rr * Math.cos(ph)), mul(B, rr * Math.sin(ph))), mul(n, Math.sqrt(1 - u1))), reach, flat, eps)) vis++; }
    ao[i] = vis / K; let li = 0; for (let j = 0; j < 6; j++) if (!anyHit(o, norm(add(Ld, [(rnd() - .5) * .24, (rnd() - .5) * .24, (rnd() - .5) * .24])), size * 4, flat, eps)) li++;
    room[i] = Math.max(0, dot(n, Ld)) * li / 6; const e = em[base(charts[ci].part)]; if (e) { const c = e.color || [255, 220, 140]; for (let q = 0; q < 3; q++) emit[i * 3 + q] = Math.min(2, c[q] / 255 * (e.strength ?? 1)); }
    if (i % 2048 === 0) await step(`Baking ambient occlusion ${Math.round(i / (r * r) * 100)}%`); }
  const mk = Uint8Array.from(G.owner, v => v >= 0 ? 1 : 0); spread(mk, [[ao, 1], [room, 1], [emit, 3]], r);
  const AO = upTo(ao, r, 1, SIZE), RM = upTo(room, r, 1, SIZE), EM = upTo(emit, r, 3, SIZE);
  await step('Making the normal map');
  const NM = normalAtlas(model, charts, dens, SIZE), Lt = norm([-.45, -.55, .7]);
  const maps = { ao: canvasRGBA(SIZE, d => { for (let i = 0; i < SIZE * SIZE; i++) { d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = Math.min(255, AO[i] * 255); d[i * 4 + 3] = 255; } }),
    room: canvasRGBA(SIZE, d => { for (let i = 0; i < SIZE * SIZE; i++) { d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = Math.min(255, RM[i] * 255); d[i * 4 + 3] = 255; } }),
    emit: canvasRGBA(SIZE, d => { for (let i = 0; i < SIZE * SIZE; i++) { for (let q = 0; q < 3; q++) d[i * 4 + q] = Math.min(255, EM[i * 3 + q] / 2 * 255); d[i * 4 + 3] = 255; } }),
    detail: canvasRGBA(SIZE, d => { for (let i = 0; i < SIZE * SIZE; i++) { const v = Math.max(.4, Math.min(1.6, (NM[i * 3] * Lt[0] + NM[i * 3 + 1] * Lt[1] + NM[i * 3 + 2] * Lt[2]) / Lt[2])); d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = v / 2 * 255; d[i * 4 + 3] = 255; } }),
    normal: canvasRGBA(SIZE, d => { for (let i = 0; i < SIZE * SIZE; i++) { d[i * 4] = (NM[i * 3] * .5 + .5) * 255; d[i * 4 + 1] = (-NM[i * 3 + 1] * .5 + .5) * 255; d[i * 4 + 2] = (NM[i * 3 + 2] * .5 + .5) * 255; d[i * 4 + 3] = 255; } }) };
  // the live grid (light nodes, path tracing) and the mesh for the viewer
  await step('Finishing');
  const L2 = lightGrid(charts, LIVE), ctr = [0, 1, 2].map(a => (Math.max(...all.map(q => q[a])) + Math.min(...all.map(q => q[a]))) / 2);
  const gP = new Float32Array(LIVE * LIVE * 3); for (let i = 0; i < LIVE * LIVE; i++) for (let a = 0; a < 3; a++) gP[i * 3 + a] = L2.P[i * 3 + a] - ctr[a];
  const bl = blk.map((v, i) => v - ctr[i % 3]);
  const nv = M.pos.length * 3, P = new Float32Array(nv * 3), N = new Float32Array(nv * 3), UV = new Float32Array(nv * 2), TG = new Float32Array(nv * 4); let rad = 0;
  M.pos.forEach((t, ti) => { const u = M.uv[ti], e1 = sub(t[1], t[0]), e2 = sub(t[2], t[0]), d1 = [u[1][0] - u[0][0], u[1][1] - u[0][1]], d2 = [u[2][0] - u[0][0], u[2][1] - u[0][1]];
    let rr = d1[0] * d2[1] - d2[0] * d1[1]; if (Math.abs(rr) < 1e-12) rr = 1e-12; const n = M.nrm[ti]; let T = mul(sub(mul(e1, d2[1]), mul(e2, d1[1])), 1 / rr); const Bd = mul(sub(mul(e2, d1[0]), mul(e1, d2[0])), 1 / rr);
    T = norm(sub(T, mul(n, dot(n, T)))); const hw = dot(cross(n, T), mul(Bd, -1)) < 0 ? -1 : 1;
    t.forEach((q, j) => { const v = ti * 3 + j, c = sub(q, ctr); P.set(c, v * 3); N.set(n, v * 3); UV[v * 2] = u[j][0] / ATLAS; UV[v * 2 + 1] = u[j][1] / ATLAS; TG.set([...T, hw], v * 4); rad = Math.max(rad, Math.hypot(...c)); }); });
  const bottoms = charts.filter(c => c.side === 'bottom'), lc = model.logo === false ? null : typeof model.logo === 'string' ? charts.find(c => c.name === model.logo) : bottoms.sort((a, b) => b.w * b.h - a.w * a.h)[0];
  const nodes = (model.lights || []).map(n => Object.assign({}, n)); if (!nodes.length) model.parts.forEach(p => { if (p.emissive) nodes.push({ pos: (p.center || [0, 0, 0]).slice(), color: p.emissive.color || [255, 220, 140], strength: p.emissive.strength ?? 1, range: p.emissive.range ?? 3 }); });
  const opp = charts.map(c => c.opposite ? charts.findIndex(o => o.name === c.part + '.' + c.opposite) : -1), slug = (model.slug || model.name || 'model').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const fx = Object.assign({}, window.LoPolTex ? LoPolTex.FX_DEFAULT : {}, (model.texture || {}).fx || {}), light = Object.assign({}, window.LoPolTex ? LoPolTex.LIGHT_DEFAULT : {}, lt);
  const tpl = { slug, name: model.name || slug, object: model.object || slug, description: model.description || '', ref: [REF_W, REF_H], views: vs.length, atlas: h2, layout: ATLAS, size: SIZE, shadeRef: SHADE_REF,
    charts: charts.map((c, i) => ({ x: c.x0 / 2, y: c.y0 / 2, w: c.w / 2, h: c.h / 2, part: c.part, side: c.side, group: c.gi, opp: opp[i], flip: c.flip })), groups, logo: lc ? charts.indexOf(lc) : -1,
    mesh: { pos: b64(P), nrm: b64(N), uv: b64(UV), tan: b64(TG), radius: rad, centre: ctr },
    look: { light, fx, nodes, outline: Object.assign({ width: .027, color: [5, 5, 5] }, typeof model.outline === 'object' ? model.outline : {}, { on: model.outline !== false }),
      grid: { res: LIVE, mask: b64(Uint8Array.from(L2.owner, v => v >= 0 ? 1 : 0)), P: b64(gP), N: b64(L2.N), blockers: b64(bl), eps, centre: ctr },
      groups: groups.map(g => ({ name: g, colour: [128, 128, 128] })), gmap: charts.map(c => [(c.x0 - 3) / ATLAS, (c.y0 - 3) / ATLAS, (c.w + 6) / ATLAS, (c.h + 6) / ATLAS, c.gi]) },
    cid, xy, wt, sh, base: '', model, built: true, triangles: M.pos.length };
  const w = wearOf(model, M); if (w) tpl.look.wear = w;
  tpl.reference = ref; tpl.refUrl = ref.toDataURL('image/png'); tpl.exampleUrl = null;
  tpl.mapUrls = Object.fromEntries(Object.entries(maps).map(([k, c]) => [k, c.toDataURL('image/png')]));
  const rc = ref.getContext('2d').getImageData(0, 0, REF_W, REF_H).data, rm = new Uint8Array(REF_W * REF_H);
  for (let i = 0; i < rm.length; i++) rm[i] = Math.max(255 - rc[i * 4], 255 - rc[i * 4 + 1], 255 - rc[i * 4 + 2]) > 28 ? 1 : 0; tpl.refMask = rm;
  onStep('Ready'); return tpl;
}
/* the grey model from several sides, for checking proportions against a picture (like tool/lopol.py clay) */
function clay(model, yaws = [35, 125, 215, 305], pitch = 22, cell = 420){
  const bad = problems(model); if (bad.length) throw new Error('model.json: ' + bad.join('; '));
  const { charts } = buildCharts(model), M = mesh(charts), c = document.createElement('canvas'); c.width = cell * yaws.length; c.height = cell; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
  yaws.forEach((y, i) => { const vs = fitViews([{ yaw: y, pitch }], charts.map(ch => Object.assign({}, ch, { explode: [0, 0, 0] })), cell, cell, .82); x.drawImage(clayCanvas(M, charts.map(ch => Object.assign({}, ch, { explode: [0, 0, 0] })), vs, cell, cell, 2), i * cell, 0); });
  return c;
}
window.LoPolCore = { build, clay, problems, MATERIALS: Object.keys(MATERIALS), HAT_BRIM_Y };
})();
