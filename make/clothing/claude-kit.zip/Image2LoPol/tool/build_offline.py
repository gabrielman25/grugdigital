"""The Clothing Studio as ONE offline HTML file: every template, look, piece of clothing and the Figure body's feet are
packed inside, so it opens from disk with no server and no internet, and a new Claude session can be handed just this file.

  python3 tool/build_offline.py <studio.html> <assets dir: the site's make/clothing/> <out.html>

The page keeps working the same way; requests for its own files ("accessories/...", "outfits/...", "body/...") are answered
from the packed copies (window.__OFFLINE, through window.ASSET, fetch and <img>.src).
"""
import sys, json, base64, pathlib, mimetypes, re

src, assets, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
html = src.read_text()
MIME = {'.json': 'application/json', '.bin': 'application/octet-stream', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
        '.zip': 'application/zip'}
files = {}
for folder in ('accessories', 'outfits', 'body'):
    for f in sorted((assets / folder).rglob('*')):
        if f.is_file() and f.suffix.lower() in MIME:
            files[f.relative_to(assets).as_posix()] = 'data:%s;base64,%s' % (MIME[f.suffix.lower()], base64.b64encode(f.read_bytes()).decode())
kit = assets / 'claude-kit.zip'
if kit.exists(): files['claude-kit.zip'] = 'data:application/zip;base64,' + base64.b64encode(kit.read_bytes()).decode()

NOTES = """<!--
================================================================================================================
 GRUG CLOTHING STUDIO, OFFLINE (one file). Notes for Claude, if someone hands you this file in a chat.
================================================================================================================
 What it is: Grug Digital's Clothing Studio with everything packed in: Clothing (classic shirt + pants templates from an
 AI-dressed blocky avatar), Accessories (block models painted by an image model and baked into PS1-style 3D accessories:
 GLB / OBJ / textures) and Character (the avatar wearing them: Blocky or Figure body, recolouring, looks).
 Open it in a browser (double-click, or headless Chrome with Playwright). No server, no internet needed.

 MAKING NEW THINGS FOR IT
 1. In a browser (Claude in Chrome, or your own headless Chrome): use the page's APIs, as the "Use Claude" cards explain:
      AccessoryStudio.help(), .modelFormat(), .templates(), .example(slug), .clay(model), .newModel(model), .describe(text),
      .status(), .look({fx, light, colours}), .wear(), .download('glb'|'obj'|'texture'|'normal')
      ClothingStudio.help(), .describe(text), .status(), .build(), .wear()
    The painting itself comes from an image model (Gemini / Nano Banana by default): send the reference picture
    (AccessoryStudio: "Copy reference picture" / the reference image) with the prompt, bring the result back (paste on the
    page, or AccessoryStudio.paint(dataURL)).
 2. To ADD items to this file for good (they then show in the Character tab every time it opens), edit the JSON block
    <script type="application/json" id="studio-items"> below (search for studio-items). Its shape:
      {"accessories": [{"name": "Red backpack", "model": { ...model.json... }, "painted": "data:image/jpeg;base64,...",
                        "colours": [null, {"rgb": [200, 30, 40], "amount": 1}]}],
       "clothing":    [{"name": "Denim jacket", "shirt": "data:image/png;base64,... (585x559 classic shirt template)",
                        "pants": "data:image/png;base64,... (classic pants template)", "thumb": "optional data URL"}],
       "looks":       [{"name": "My look", "body": "classic"|"figure", "skin": "#eab892", "clothing": "file:0",
                        "accessories": [{"slug": "cowboy-hat"}, {"id": "file:0"}]}]}
    "model" is the same model.json as the Image2LoPol tool (AccessoryStudio.modelFormat() explains it; a finished example:
    AccessoryStudio.example('backpack')); "painted" is the image model's painting of its reference picture
    (AccessoryStudio.newModel(model) shows that reference). The page builds and bakes them when it opens.
    Clothing ids are "file:<n>" and accessory ids "file:<n>" in order. Keep the file otherwise unchanged.
 3. The full toolkit (Python, for baking with path tracing and checking fit from the command line) is packed in too:
    the "Claude kit (.zip)" button in Accessories, or the "claude-kit.zip" entry of window.__OFFLINE.
 Rules: realistic, photo-scanned textures by default; no brand or platform names in image prompts; hats use
 "wear": {"on": "head", "fit": "hat"} (brim just above the eyes); the pants are just pants (no shoes painted on them).
================================================================================================================
-->
"""
SHIM = """<script id="offline-shim">
/* Offline build: this page's own files are packed in window.__OFFLINE (see the notes at the top of the file). */
window.__OFFLINE = %s;
window.ASSET = u => { if (typeof u !== 'string') return u; const k = u.replace(/^\\.\\//, '').split('#')[0]; return window.__OFFLINE[k] || u; };
(() => { const f0 = window.fetch.bind(window); window.fetch = (u, o) => f0(typeof u === 'string' ? ASSET(u) : u, o);
  const d = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
  Object.defineProperty(HTMLImageElement.prototype, 'src', { configurable: true, get(){ return d.get.call(this); }, set(v){ d.set.call(this, ASSET(v)); } });
  document.addEventListener('DOMContentLoaded', () => document.querySelectorAll('a[href="claude-kit.zip"]').forEach(a => { a.href = ASSET('claude-kit.zip'); }));
})();
</script>""" % json.dumps(files, separators=(',', ':'))
html = re.sub(r'<title>[^<]*</title>', '<title>Grug Clothing Studio (offline)</title>', html, count=1)
html = html.replace('<!DOCTYPE html>', '<!DOCTYPE html>\n' + NOTES, 1)
i = html.index('<head>') + len('<head>')
html = html[:i] + '\n' + SHIM + html[i:]
out.write_text(html)
print('wrote', out, round(out.stat().st_size / 1e6, 1), 'MB,', len(files), 'files packed')
