#!/usr/bin/env python3
"""Image2LoPol: block models from a picture, painted by an image model, baked to a PS1-style texture.

  python3 tool/lopol.py clay   items/<slug>     grey model from 4 sides next to the source picture (for modelling)
  python3 tool/lopol.py ref    items/<slug>     reference.png to paint (front left, back right) + prompt.txt
  python3 tool/lopol.py bake   items/<slug>     painted.png -> out/ (texture, OBJ, GLB, preview.html, check pictures)
  python3 tool/lopol.py all    items/<slug>     clay + ref (+ bake when painted.png exists)
  python3 tool/lopol.py template items/<slug> <dir>  a template for the Clothing Studio's Accessories section
  python3 tool/lopol.py worn   items/a [items/b ...] [--out f.png]   the blocky avatar wearing them, from four sides

Only needs numpy and Pillow. Every item folder holds model.json (see MODEL_FORMAT.md).
"""
import json, math, sys, struct, base64, pathlib, io
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = pathlib.Path(__file__).resolve().parent
REF_W, REF_H = 1536, 1024
BG = np.array([255, 255, 255], np.float32)
LIGHT = None  # set below
AMB, DIF = 0.50, 0.50
GREY = 0.80

def norm(v):
    v = np.asarray(v, np.float64); n = np.linalg.norm(v, axis=-1, keepdims=True)
    return v / np.maximum(n, 1e-12)

LIGHT = norm([-0.45, 0.80, 0.40])

def view_light(v):
    """A light that rides with the camera: from the upper left, a little in front."""
    if v is None: return LIGHT
    r, u, f = v['basis']
    return norm(-0.45 * r + 0.75 * u - 0.5 * f)

def shade_of(n, v=None):
    return AMB + DIF * np.clip(np.asarray(n) @ view_light(v), 0, 1)

SHADE_REF = AMB + DIF * 0.75

# ----------------------------------------------------------------------------------------------
# Geometry: every surface is a "chart" = a grid of quads (P[rows+1][cols+1]) or a flat polygon.
# Convention, looking at the surface from outside: columns go right, rows go down,
# outward normal = cross(down, right). Triangles (P00,P10,P11) and (P00,P11,P01).
# ----------------------------------------------------------------------------------------------

def rot_matrix(deg):
    rx, ry, rz = [math.radians(a) for a in (list(deg) + [0, 0, 0])[:3]]
    X = np.array([[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]])
    Y = np.array([[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]])
    Z = np.array([[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]])
    return Z @ Y @ X

class Chart:
    def __init__(self, part, side, kind, data, opposite=None, flip='h'):
        self.part, self.side, self.kind, self.opposite, self.flip = part, side, kind, opposite, flip
        if kind == 'grid': self.P = np.asarray(data, np.float64)
        else: self.V = np.asarray(data, np.float64)
        self.name = f'{part}.{side}'

BOX_FACES = {  # TL, TR, BL, BR corner signs
    'front':  [(-1, 1, 1), (1, 1, 1), (-1, -1, 1), (1, -1, 1)],
    'back':   [(1, 1, -1), (-1, 1, -1), (1, -1, -1), (-1, -1, -1)],
    'right':  [(1, 1, 1), (1, 1, -1), (1, -1, 1), (1, -1, -1)],
    'left':   [(-1, 1, -1), (-1, 1, 1), (-1, -1, -1), (-1, -1, 1)],
    'top':    [(-1, 1, -1), (1, 1, -1), (-1, 1, 1), (1, 1, 1)],
    'bottom': [(-1, -1, 1), (1, -1, 1), (-1, -1, -1), (1, -1, -1)],
}
BOX_OPP = {'front': 'back', 'back': 'front', 'left': 'right', 'right': 'left', 'top': 'bottom', 'bottom': 'top'}

def part_box(p):
    w, h, d = p['size']; tx, tz = (p.get('taper') or [1, 1]); ox, oz = (p.get('shift') or [0, 0])
    bx, bz = (p.get('taperBottom') or [1, 1])
    def corner(s):
        sx, sy, sz = s
        if sy > 0: return [sx * w / 2 * tx + ox, h / 2, sz * d / 2 * tz + oz]
        return [sx * w / 2 * bx, -h / 2, sz * d / 2 * bz]
    out = []
    skip = set(p.get('omit', []))
    for side, cs in BOX_FACES.items():
        if side in skip: continue
        P = [[corner(cs[0]), corner(cs[1])], [corner(cs[2]), corner(cs[3])]]
        out.append(Chart(p['name'], side, 'grid', P, BOX_OPP[side], 'v' if side in ('top', 'bottom') else 'h'))
    return out

def part_lathe(p):
    prof = p['profile']  # [[radius, y], ...] top to bottom
    n = int(p.get('sides', 8)); a0 = math.radians(p.get('startAngle', 0))
    sx, sz = (p.get('scale') or [1, 1])
    ang = [-math.pi + a0 + 2 * math.pi * c / n for c in range(n + 1)]
    cu = p.get('curl') or {}
    rmax = max(r for r, y in prof); r0 = cu.get('from', 0); amt = cu.get('amount', 0)
    def lift(r, a):  # raise the outer ring at the sides (x), like a cowboy hat's brim
        if not amt or r <= r0: return 0.0
        return amt * ((r - r0) / max(1e-6, rmax - r0)) ** 2 * math.sin(a) ** 2
    P = [[[r * math.sin(a) * sx, y + lift(r, a), r * math.cos(a) * sz] for a in ang] for r, y in prof]
    out = [Chart(p['name'], 'side', 'grid', P, None)]
    caps = p.get('caps', 'both')
    rt, yt = prof[0]; rb, yb = prof[-1]
    if rt > 1e-6 and caps in ('both', 'top'):
        out.append(Chart(p['name'], 'top', 'poly', [[rt * math.sin(a) * sx, yt, rt * math.cos(a) * sz] for a in ang[:-1]][::-1], 'bottom', 'v'))
    if rb > 1e-6 and caps in ('both', 'bottom'):
        out.append(Chart(p['name'], 'bottom', 'poly', [[rb * math.sin(a) * sx, yb, rb * math.cos(a) * sz] for a in ang[:-1]], 'top', 'v'))
    return out

def part_cylinder(p):
    h = p['height']; r = p['radius']; rt = p.get('radiusTop', r)
    q = dict(p); q['profile'] = [[rt, h / 2], [r, -h / 2]]
    return part_lathe(q)

def part_strap(p):
    pts = np.asarray(p['points'], np.float64); w = p['width']; t = p.get('thickness', 0.05)
    hint = norm(p.get('normal', [0, 0, 1]))
    n = len(pts); T = np.zeros_like(pts)
    for i in range(n):
        a = pts[min(i + 1, n - 1)] - pts[max(i - 1, 0)]
        T[i] = norm(a)
    if p.get('normals'):  # one outward direction per point, so a strap can bend over a shoulder and keep facing out
        Hn = norm(np.asarray(p['normals'], np.float64)); N = norm(Hn - (T * Hn).sum(1, keepdims=True) * T)
    else: N = norm(hint - (T @ hint)[:, None] * T)
    R = norm(np.cross(N, T))
    out = []
    for side, D, hd, Rt, hr, opp in (('front', N, t / 2, R, w / 2, 'back'), ('back', -N, t / 2, -R, w / 2, 'front'),
                                     ('edge1', R, w / 2, -N, t / 2, 'edge2'), ('edge2', -R, w / 2, N, t / 2, 'edge1')):
        P = [[(pts[i] + D[i] * hd - Rt[i] * hr).tolist(), (pts[i] + D[i] * hd + Rt[i] * hr).tolist()] for i in range(n)]
        out.append(Chart(p['name'], side, 'grid', P, opp))
    if p.get('caps', True):
        def cap(i, sgn):
            c = [pts[i] + N[i] * t / 2 - R[i] * w / 2, pts[i] + N[i] * t / 2 + R[i] * w / 2,
                 pts[i] - N[i] * t / 2 + R[i] * w / 2, pts[i] - N[i] * t / 2 - R[i] * w / 2]
            return [x.tolist() for x in (c if sgn > 0 else c[::-1])]
        out.append(Chart(p['name'], 'end1', 'poly', cap(0, 1), 'end2'))
        out.append(Chart(p['name'], 'end2', 'poly', cap(n - 1, -1), 'end1'))
    return out

def poly_normal(V):
    c = V.mean(0); s = np.zeros(3)
    for i in range(len(V)): s += np.cross(V[i] - c, V[(i + 1) % len(V)] - c)
    return norm(s)

def fix_caps(charts):
    """Make every polygon wind counter-clockwise seen from outside (outward = away from the part's middle)."""
    for ch in charts:
        if ch.kind != 'poly': continue
        mid = np.concatenate([c.P.reshape(-1, 3) if c.kind == 'grid' else c.V for c in charts if c.part == ch.part]).mean(0)
        nrm = poly_normal(ch.V)
        if (ch.V.mean(0) - mid) @ nrm < 0: ch.V = ch.V[::-1]

BUILDERS = {'box': part_box, 'cylinder': part_cylinder, 'lathe': part_lathe, 'strap': part_strap}

def build_charts(model):
    charts = []
    for p in model['parts']:
        if p.get('hidden'): continue
        cs = BUILDERS[p['type']](p)
        fix_caps(cs)
        Rm = rot_matrix(p.get('rot', [0, 0, 0])); c = np.asarray(p.get('center', [0, 0, 0]), np.float64)
        for ch in cs:
            if ch.kind == 'grid': ch.P = ch.P @ Rm.T + c
            else: ch.V = ch.V @ Rm.T + c
            ch.explode = np.asarray(p.get('explode', [0, 0, 0]), np.float64)
            ch.group = p.get('group') or p['name'].replace('_', ' ').capitalize()
        group = cs
        mir = p.get('mirror') or []
        for ax in ([mir] if isinstance(mir, str) else mir):  # mirrored copies across x = 0 / y = 0 / z = 0
            f = np.array([-1 if ax == a else 1 for a in 'xyz'], np.float64); add = []
            for ch in group:
                m = Chart(ch.part + '_m' + ax, ch.side, ch.kind, (ch.P if ch.kind == 'grid' else ch.V) * f, ch.opposite, ch.flip)
                if m.kind == 'grid': m.P = m.P[:, ::-1]
                else: m.V = m.V[::-1]
                m.explode = ch.explode * f; m.group = ch.group
                add.append(m)
            group = group + add
        charts += group
    for ch in charts:  # lay long thin strips sideways so they pack
        if ch.kind == 'grid':
            hl = np.linalg.norm(ch.P[1:] - ch.P[:-1], axis=-1).mean(1).sum()
            wl = np.linalg.norm(ch.P[:, 1:] - ch.P[:, :-1], axis=-1).mean(0).sum()
            if hl > 2.5 * wl: ch.P = ch.P[::-1].transpose(1, 0, 2).copy()
    S = int(model.get('texture', {}).get('atlas', 1024))
    model['_density'] = layout(charts, S, pad=8)
    gs = []
    for ch in charts:
        if ch.group not in gs: gs.append(ch.group)
    model['_groups'] = gs
    for ch in charts: ch.gi = gs.index(ch.group)
    return charts

def group_rects(charts, S, grow=3):
    """Where each colour group sits in the atlas: [x, y, w, h, group] in 0..1, a few texels bigger than the chart."""
    return [[round((c.x0 - grow) / S, 5), round((c.y0 - grow) / S, 5), round((c.w + 2 * grow) / S, 5), round((c.h + 2 * grow) / S, 5), c.gi] for c in charts]

def group_info(model, charts, S, albedo):
    """The colour groups with their average colour (from the painted texture)."""
    a = np.asarray(Image.fromarray(albedo.astype(np.uint8)).resize((S, S), Image.BOX), np.float64); out = []
    for gi, g in enumerate(model['_groups']):
        px = np.concatenate([a[c.y0:c.y0 + c.h, c.x0:c.x0 + c.w].reshape(-1, 3) for c in charts if c.gi == gi])
        out.append({'name': g, 'colour': [int(v) for v in px.mean(0)]})
    return out

# ----------------------------------------------------------------------------------------------
# Wearing it: where the accessory sits on the blocky avatar (studs: torso x -1..1, y 2..4, z -0.5..0.5, front +z;
# arms x 1..2 / -2..-1, legs y 0..2, head a cylinder r 0.625 from y 4 to 5.25)
# ----------------------------------------------------------------------------------------------

WEAR_ON = {'head': 'HatAttachment', 'face': 'FaceFrontAttachment', 'hair': 'HairAttachment', 'neck': 'NeckAttachment',
           'back': 'BodyBackAttachment', 'front': 'BodyFrontAttachment', 'waist': 'WaistBackAttachment',
           'lhand': 'LeftGripAttachment', 'rhand': 'RightGripAttachment', 'lshoulder': 'LeftShoulderAttachment',
           'rshoulder': 'RightShoulderAttachment'}

HAT_BRIM_Y = 4.88   # where every hat's lowest edge (the brim) sits: just above the eyes, so no forehead shows

def wear_of(model, charts=None):
    """The wear settings. "fit": "hat" places the hat by itself: centred on the head, its lowest point at HAT_BRIM_Y."""
    w = model.get('wear')
    if not w: return None
    w = dict({'on': 'back', 'scale': 1.0, 'rot': [0, 0, 0], 'offset': [0, 0, 0]}, **w)
    w.setdefault('attachment', WEAR_ON.get(w['on'], 'BodyBackAttachment'))
    if w.get('fit') == 'hat':
        charts = charts or build_charts(json.loads(json.dumps({k: v for k, v in model.items() if not k.startswith('_')})))
        P = mesh(charts)[0].reshape(-1, 3); M = wear_matrix(dict(w, offset=[0, 0, 0])); Q = P @ M[:3, :3].T
        w['offset'] = [round(float(-(Q[:, 0].max() + Q[:, 0].min()) / 2), 4), round(float(HAT_BRIM_Y - Q[:, 1].min()), 4), round(float(-(Q[:, 2].max() + Q[:, 2].min()) / 2), 4)]
    return w

def wear_matrix(w):
    """4x4: model coordinates -> avatar coordinates (scale, then rotate X, Y, Z, then move)."""
    M = np.eye(4); s = w['scale']; s = np.asarray(s if isinstance(s, (list, tuple)) else [s] * 3, np.float64)
    M[:3, :3] = rot_matrix(w['rot']) * s[None, :]; M[:3, 3] = w['offset']; return M

def mannequin():
    """The blocky avatar as charts (for checking that an accessory fits)."""
    parts = [{'name': 'torso', 'type': 'box', 'center': [0, 3, 0], 'size': [2, 2, 1]},
             {'name': 'larm', 'type': 'box', 'center': [1.5, 3, 0], 'size': [1, 2, 1]},
             {'name': 'rarm', 'type': 'box', 'center': [-1.5, 3, 0], 'size': [1, 2, 1]},
             {'name': 'lleg', 'type': 'box', 'center': [0.5, 1, 0], 'size': [1, 2, 1]},
             {'name': 'rleg', 'type': 'box', 'center': [-0.5, 1, 0], 'size': [1, 2, 1]},
             {'name': 'head', 'type': 'cylinder', 'center': [0, 4.625, 0], 'radius': 0.625, 'height': 1.25, 'sides': 16},
             {'name': 'face', 'type': 'box', 'center': [0, 4.7, 0.6], 'size': [0.5, 0.18, 0.06]}]
    out = []
    for p in parts:
        cs = BUILDERS[p['type']](p); fix_caps(cs); c = np.asarray(p['center'], np.float64)
        for ch in cs:
            if ch.kind == 'grid': ch.P = ch.P + c
            else: ch.V = ch.V + c
            ch.explode = np.zeros(3); ch.group = 'avatar'
        out += cs
    return out

def worn_mesh(model, charts):
    """The accessory's triangles moved onto the avatar: pos, uv, cid, nrm."""
    w = wear_of(model, charts)
    if w is None: return None
    M = wear_matrix(w); pos, uv, cid, nrm = mesh(charts)
    P = pos @ M[:3, :3].T + M[:3, 3]
    return P, uv, cid, norm(np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0]))

# ----------------------------------------------------------------------------------------------
# Atlas: lay every chart out at one texel density, packed in a square
# ----------------------------------------------------------------------------------------------

def chart_dims(ch, dens):
    if ch.kind == 'grid':
        P = ch.P
        cw = np.linalg.norm(P[:, 1:] - P[:, :-1], axis=-1).mean(0)
        rh = np.linalg.norm(P[1:] - P[:-1], axis=-1).mean(1)
        cols = np.maximum(1, np.round(cw * dens)).astype(int); rows = np.maximum(1, np.round(rh * dens)).astype(int)
        cols[-1] += cols.sum() % 2; rows[-1] += rows.sum() % 2   # even sizes: a half-size copy of the atlas lines up exactly
        ch.cx = np.concatenate([[0], np.cumsum(cols)]); ch.cy = np.concatenate([[0], np.cumsum(rows)])
        ch.w, ch.h = int(ch.cx[-1]), int(ch.cy[-1])
    else:
        V = ch.V; n = poly_normal(V); e1 = np.array([1.0, 0, 0]) - n * n[0]
        if np.linalg.norm(e1) < 0.3: e1 = np.array([0, 0, 1.0]) - n * n[2]
        e1 = norm(e1); e2 = np.cross(e1, n)
        a = (V - V[0]) @ e1; b = (V - V[0]) @ e2
        ch.basis = (V[0], e1, e2, a.min(), b.min(), dens)
        ch.w = max(2, int(math.ceil((a.max() - a.min()) * dens))); ch.h = max(2, int(math.ceil((b.max() - b.min()) * dens)))
        ch.w += ch.w % 2; ch.h += ch.h % 2
    return ch.w, ch.h

def pack(charts, S, dens, pad):
    for ch in charts: chart_dims(ch, dens)
    order = sorted(charts, key=lambda c: -c.h); x = y = pad; shelf = 0
    for ch in order:
        if ch.w + 2 * pad > S: return False
        if x + ch.w + pad > S: x = pad; y += shelf + pad; shelf = 0
        ch.x0, ch.y0 = x, y; x += ch.w + pad; shelf = max(shelf, ch.h)
    return y + shelf + pad <= S

def layout(charts, S, pad):
    lo, hi = 1.0, 4096.0
    for _ in range(30):
        mid = (lo + hi) / 2
        if pack(charts, S, mid, pad): lo = mid
        else: hi = mid
    assert pack(charts, S, lo, pad)
    return lo

# ----------------------------------------------------------------------------------------------
# Mesh (flat triangles with atlas UVs in pixels, y down)
# ----------------------------------------------------------------------------------------------

def mesh(charts):
    pos, uv, cid = [], [], []
    for k, ch in enumerate(charts):
        if ch.kind == 'grid':
            P = ch.P
            for r in range(P.shape[0] - 1):
                for c in range(P.shape[1] - 1):
                    U = lambda rr, cc: (ch.x0 + ch.cx[cc], ch.y0 + ch.cy[rr])
                    for tri in (((r, c), (r + 1, c), (r + 1, c + 1)), ((r, c), (r + 1, c + 1), (r, c + 1))):
                        pos.append([P[a] for a in tri]); uv.append([U(*a) for a in tri]); cid.append(k)
        else:
            V0, e1, e2, amin, bmin, dens = ch.basis
            def U(v): return (ch.x0 + ((v - V0) @ e1 - amin) * dens, ch.y0 + ((v - V0) @ e2 - bmin) * dens)
            for i in range(1, len(ch.V) - 1):
                tri = (ch.V[0], ch.V[i], ch.V[i + 1]); pos.append(tri); uv.append([U(v) for v in tri]); cid.append(k)
    pos = np.asarray(pos, np.float64); uv = np.asarray(uv, np.float64); cid = np.asarray(cid)
    nrm = norm(np.cross(pos[:, 1] - pos[:, 0], pos[:, 2] - pos[:, 0]))  # CCW from outside -> outward
    return pos, uv, cid, nrm

def chart_texels(ch):
    """3D point and normal for the centre of every texel of the chart (h, w)."""
    h, w = ch.h, ch.w
    X = np.zeros((h, w, 3)); Nn = np.zeros((h, w, 3))
    if ch.kind == 'grid':
        P = ch.P
        for r in range(P.shape[0] - 1):
            for c in range(P.shape[1] - 1):
                x0, x1, y0, y1 = ch.cx[c], ch.cx[c + 1], ch.cy[r], ch.cy[r + 1]
                s = ((np.arange(x0, x1) + 0.5 - x0) / (x1 - x0))[None, :, None]
                t = ((np.arange(y0, y1) + 0.5 - y0) / (y1 - y0))[:, None, None]
                A = t >= s
                XA = (1 - t) * P[r, c] + (t - s) * P[r + 1, c] + s * P[r + 1, c + 1]
                XB = (1 - s) * P[r, c] + t * P[r + 1, c + 1] + (s - t) * P[r, c + 1]
                X[y0:y1, x0:x1] = np.where(A, XA, XB)
                nA = norm(np.cross(P[r + 1, c] - P[r, c], P[r + 1, c + 1] - P[r, c]))
                nB = norm(np.cross(P[r + 1, c + 1] - P[r, c], P[r, c + 1] - P[r, c]))
                Nn[y0:y1, x0:x1] = np.where(A, nA, nB)
    else:
        V0, e1, e2, amin, bmin, dens = ch.basis
        a = amin + (np.arange(w) + 0.5) / dens; b = bmin + (np.arange(h) + 0.5) / dens
        X = V0 + a[None, :, None] * e1 + b[:, None, None] * e2
        Nn[:] = poly_normal(ch.V)
    return X, Nn

# ----------------------------------------------------------------------------------------------
# Cameras (orthographic) and a small z-buffer rasteriser
# ----------------------------------------------------------------------------------------------

def view_basis(yaw, pitch):
    y, p = math.radians(yaw), math.radians(pitch)
    v = np.array([math.cos(p) * math.sin(y), math.sin(p), math.cos(p) * math.cos(y)])  # towards camera
    f = -v; r = norm(np.cross(f, [0, 1, 0])); u = np.cross(r, f)
    return r, u, f

def views_of(model):
    vs = model.get('views') or [{'yaw': 35, 'pitch': 22}, {'yaw': 215, 'pitch': 22}]
    return [dict(v, basis=view_basis(v['yaw'], v['pitch'])) for v in vs]

def fit_views(model, charts, W, H, margin=0.84):
    """Scale and screen centre shared by both views (each view in its own half of the picture)."""
    vs = views_of(model); n = len(vs); pts = []
    for i, v in enumerate(vs):
        r, u, f = v['basis']; P = []
        for ch in charts:
            Q = (ch.P.reshape(-1, 3) if ch.kind == 'grid' else ch.V) + (ch.explode if i == 1 else 0)
            P.append(np.stack([Q @ r, -(Q @ u)], 1))
        P = np.concatenate(P); pts.append(P)
    span = max(max(np.ptp(P[:, 0]) for P in pts) / (W / n), max(np.ptp(P[:, 1]) for P in pts) / H)
    s = margin / span
    for i, v in enumerate(vs):
        P = pts[i]; mid = (P.max(0) + P.min(0)) / 2
        v['scale'] = s; v['ox'] = W / n * (i + 0.5) - mid[0] * s; v['oy'] = H * 0.5 - mid[1] * s
    return vs

def project(v, X, i):
    r, u, f = v['basis']
    return np.stack([X @ r * v['scale'] + v['ox'], -(X @ u) * v['scale'] + v['oy'], X @ f], -1)

def raster(tri, W, H):
    """tri: (T,3,3) screen x, y, depth. Returns depth, triangle id, barycentrics."""
    depth = np.full((H, W), np.inf); tid = np.full((H, W), -1, np.int32); bar = np.zeros((H, W, 3))
    for k in range(len(tri)):
        (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = tri[k]
        area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
        if abs(area) < 1e-9: continue
        mx, Mx = max(int(math.floor(min(x0, x1, x2))), 0), min(int(math.ceil(max(x0, x1, x2))) + 1, W)
        my, My = max(int(math.floor(min(y0, y1, y2))), 0), min(int(math.ceil(max(y0, y1, y2))) + 1, H)
        if mx >= Mx or my >= My: continue
        X, Y = np.meshgrid(np.arange(mx, Mx) + 0.5, np.arange(my, My) + 0.5)
        w0 = ((x1 - X) * (y2 - Y) - (x2 - X) * (y1 - Y)) / area
        w1 = ((x2 - X) * (y0 - Y) - (x0 - X) * (y2 - Y)) / area
        w2 = 1 - w0 - w1
        e = -1e-4
        ins = (w0 >= e) & (w1 >= e) & (w2 >= e)
        z = w0 * z0 + w1 * z1 + w2 * z2
        sub = depth[my:My, mx:Mx]; up = ins & (z < sub)
        sub[up] = z[up]; tid[my:My, mx:Mx][up] = k
        bar[my:My, mx:Mx][up] = np.stack([w0, w1, w2], -1)[up]
    return depth, tid, bar

def render(charts, vs, W, H, tex=None, ss=1, edges=True, lit=True, bg=BG):
    """Grey clay (tex None) or textured picture of all views. Returns RGB uint8 and per-view buffers at 1x."""
    pos, uv, cid, nrm = mesh(charts)
    return render_mesh(pos, uv, cid, nrm, np.array([ch.explode for ch in charts]), vs, W, H, tex, ss, edges, lit, bg)

def render_mesh(pos, uv, cid, nrm, explode, vs, W, H, tex=None, ss=1, edges=True, lit=True, bg=BG, colour=None):
    """colour: optional (T, 3) flat colour per triangle (used where it isn't negative), e.g. the avatar in a worn check."""
    img = np.ones((H * ss, W * ss, 3)) * bg
    for i, v in enumerate(vs):
        off = explode[cid][:, None, :] if i == 1 and explode is not None else 0
        tri = project(v, pos + off, i)
        tri[..., :2] *= ss
        d, t, b = raster(tri, W * ss, H * ss)
        m = t >= 0
        sh = shade_of(nrm, v)[t[m]] if lit else 1.0
        if tex is None:
            col = np.full((m.sum(), 3), GREY * 255.0) * np.asarray(sh).reshape(-1, 1)
        else:
            U = (b[m][:, :, None] * uv[t[m]]).sum(1)
            th, tw = tex.shape[:2]
            ix = np.clip(U[:, 0].astype(int), 0, tw - 1); iy = np.clip(U[:, 1].astype(int), 0, th - 1)
            col = tex[iy, ix].astype(np.float64) * (np.asarray(sh).reshape(-1, 1) / SHADE_REF if lit else 1)
        if colour is not None:
            fc = colour[t[m]]; own = fc[:, 0] >= 0
            col[own] = fc[own] * (np.asarray(sh).reshape(-1, 1)[own] if np.ndim(sh) else 1)
        img[m] = np.clip(col, 0, 255)
        if edges:  # thin darker line where one chart meets another
            c = np.where(m, cid[np.maximum(t, 0)], -1)
            e = np.zeros_like(m)
            e[:, 1:] |= c[:, 1:] != c[:, :-1]; e[1:, :] |= c[1:, :] != c[:-1, :]
            e &= m | np.roll(m, 1, 0) | np.roll(m, 1, 1)
            img[e & m] *= 0.80
    out = Image.fromarray(img.astype(np.uint8))
    if ss > 1: out = out.resize((W, H), Image.LANCZOS)
    return out

def buffers(charts, vs, W, H):
    pos, uv, cid, nrm = mesh(charts); res = []
    for i, v in enumerate(vs):
        off = np.array([ch.explode for ch in charts])[cid][:, None, :] if i == 1 else 0
        d, t, b = raster(project(v, pos + off, i), W, H)
        res.append((d, np.where(t >= 0, cid[np.maximum(t, 0)], -1)))
    return res

# ----------------------------------------------------------------------------------------------
# Alignment of the painted picture to the reference (scale + shift per view, silhouette IoU)
# ----------------------------------------------------------------------------------------------

def fg_mask(img):
    a = img.astype(np.float32); bd = np.concatenate([a[0], a[-1], a[:, 0], a[:, -1]])
    bg = np.median(bd, 0)
    return np.abs(a - bg).max(-1) > 28

def iou(refm, resm, s, tx, ty, box, step=3):
    x0, x1, y0, y1 = box
    qy, qx = np.mgrid[y0:y1:step, x0:x1:step]
    px = ((qx - tx) / s).astype(int); py = ((qy - ty) / s).astype(int)
    ok = (px >= 0) & (py >= 0) & (px < refm.shape[1]) & (py < refm.shape[0])
    A = np.zeros(qx.shape, bool); A[ok] = refm[py[ok], px[ok]]
    B = resm[qy, qx]
    u = (A | B).sum()
    return (A & B).sum() / max(u, 1)

def align(refm, resm, nviews):
    """Per view: result_xy = s * ref_xy + (tx, ty)."""
    H, W = refm.shape; h, w = resm.shape; out = []
    for i in range(nviews):
        ra = refm[:, int(W * i / nviews):int(W * (i + 1) / nviews)]
        rb = resm[:, int(w * i / nviews):int(w * (i + 1) / nviews)]
        ya, xa = np.nonzero(ra); yb, xb = np.nonzero(rb)
        if len(xb) < 50: raise SystemExit('The painted picture has no figure in view %d' % (i + 1))
        xa = xa + W * i / nviews; xb = xb + w * i / nviews
        s = ((yb.max() - yb.min()) / max(1, ya.max() - ya.min()) + (xb.max() - xb.min()) / max(1, xa.max() - xa.min())) / 2
        tx = (xb.max() + xb.min()) / 2 - s * (xa.max() + xa.min()) / 2
        ty = (yb.max() + yb.min()) / 2 - s * (ya.max() + ya.min()) / 2
        box = (int(w * i / nviews), int(w * (i + 1) / nviews), 0, h)
        mref = np.zeros_like(refm); mref[:, int(W * i / nviews):int(W * (i + 1) / nviews)] = ra
        best = iou(mref, resm, s, tx, ty, box)
        for ds, dt in ((0.02, 6), (0.01, 3), (0.004, 1.5), (0.002, 0.75)):
            moved = True
            while moved:
                moved = False
                for c in ((s * (1 + ds), tx, ty), (s * (1 - ds), tx, ty), (s, tx + dt, ty), (s, tx - dt, ty), (s, tx, ty + dt), (s, tx, ty - dt)):
                    # keep the figure's centre in place when scaling
                    sc, cx, cy = c
                    if sc != s:
                        mx = (xa.max() + xa.min()) / 2; my = (ya.max() + ya.min()) / 2
                        cx = tx + (s - sc) * mx; cy = ty + (s - sc) * my
                    v = iou(mref, resm, sc, cx, cy, box, step=2 if ds < 0.01 else 3)
                    if v > best + 1e-5: best, s, tx, ty, moved = v, sc, cx, cy, True
        out.append({'s': s, 'tx': tx, 'ty': ty, 'iou': float(best)})
    return out

# ----------------------------------------------------------------------------------------------
# Baking
# ----------------------------------------------------------------------------------------------

def bilinear(img, x, y):
    h, w = img.shape[:2]
    x = np.clip(x - 0.5, 0, w - 1.001); y = np.clip(y - 0.5, 0, h - 1.001)
    x0 = x.astype(int); y0 = y.astype(int); fx = (x - x0)[..., None]; fy = (y - y0)[..., None]
    a = img[y0, x0]; b = img[y0, x0 + 1]; c = img[y0 + 1, x0]; d = img[y0 + 1, x0 + 1]
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy

def pushpull(img, m):
    if m.all(): return img
    if not m.any(): return np.zeros_like(img) + 128
    h, w = m.shape
    if h <= 1 and w <= 1: return img
    H2, W2 = (h + 1) // 2 * 2, (w + 1) // 2 * 2
    I = np.zeros((H2, W2, 3)); M = np.zeros((H2, W2)); I[:h, :w] = img * m[..., None]; M[:h, :w] = m
    si = I.reshape(H2 // 2, 2, W2 // 2, 2, 3).sum((1, 3)); sm = M.reshape(H2 // 2, 2, W2 // 2, 2).sum((1, 3))
    small = si / np.maximum(sm, 1e-9)[..., None]
    small = pushpull(small, sm > 0)
    up = small.repeat(2, 0).repeat(2, 1)[:h, :w]
    return np.where(m[..., None], img, up)

def shading_followed(stats):
    """How much the image model kept the reference's shading (0 = lit its painting evenly, 1 = followed it exactly).
    Faces of one colour group seen at different angles: does the painted brightness go up and down with the shading?"""
    by = {}
    for g, i, n, ly, lx in stats: by.setdefault(g, []).append((n, ly, lx))
    num = den = 0.0
    for rows in by.values():
        if len(rows) < 2: continue
        n = np.array([r[0] for r in rows], float); y = np.array([r[1] for r in rows]); x = np.array([r[2] for r in rows])
        xm = (n * x).sum() / n.sum(); ym = (n * y).sum() / n.sum()
        num += (n * (x - xm) * (y - ym)).sum(); den += (n * (x - xm) ** 2).sum()
    if den < 1e-6: return 0.5
    return float(np.clip(num / den, 0, 0.9))

def bake(model, charts, vs, painted, S, opts):
    W, H = REF_W, REF_H
    refbuf = buffers(charts, vs, W, H)
    refm = np.zeros((H, W), bool)
    for d, c in refbuf: refm |= c >= 0
    resm = fg_mask(painted)
    al = align(refm, resm, len(vs))
    inner = resm.copy()  # the painted figure, pulled in 2 px so edge pixels (mixed with the background) are not used
    for _ in range(2):
        inner = inner & np.roll(inner, 1, 0) & np.roll(inner, -1, 0) & np.roll(inner, 1, 1) & np.roll(inner, -1, 1)
    pimg = painted.astype(np.float64)
    atlas = np.zeros((S, S, 3)); filled = np.zeros((S, S), bool)
    unshade = opts.get('unshade', 'auto')
    report = []; stats = []
    chart_img = {}
    per = []
    for k, ch in enumerate(charts):
        X, Nn = chart_texels(ch)
        best = np.full(X.shape[:2], -1.0); acc = np.zeros(X.shape); wsum = np.zeros(X.shape[:2])
        for i, v in enumerate(vs):
            Xi = X + (ch.explode if i == 1 else 0)
            p = project(v, Xi, i)
            d, cb = refbuf[i]
            px = np.clip(p[..., 0].astype(int), 0, W - 1); py = np.clip(p[..., 1].astype(int), 0, H - 1)
            tol = 2.5 / v['scale']
            vis = (cb[py, px] == k) & (np.abs(d[py, px] - p[..., 2]) < tol)
            # keep away from the chart's own outline in the picture (edge pixels mix with neighbours)
            core = vis.copy()
            for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2)):
                core &= cb[np.clip(py + dy, 0, H - 1), np.clip(px + dx, 0, W - 1)] == k
            use = np.where(core.any(), core, vis)
            facing = -(Nn @ v['basis'][2])
            a = al[i]
            qx = p[..., 0] * a['s'] + a['tx']; qy = p[..., 1] * a['s'] + a['ty']
            hh, ww = inner.shape
            use &= inner[np.clip(qy.astype(int), 0, hh - 1), np.clip(qx.astype(int), 0, ww - 1)] & (facing > 0.05)
            if use.any():
                c = bilinear(pimg, qx, qy); sh = shade_of(Nn, v)
                wgt = np.where(use, (facing - 0.05) ** 2, 0)  # the view that faces the surface most counts most; no hard seam
                per.append((k, i, c, wgt, sh)); best = np.maximum(best, np.where(use, facing, -1))
                n = int(use.sum())
                if n > 30: stats.append((ch.group, i, n, float(np.log(np.maximum(c[use] @ [0.299, 0.587, 0.114], 4)).mean()), float(np.log(sh[use]).mean())))
        col = np.zeros(X.shape)
        seen = best > -1
        chart_img[k] = [col, seen]
        report.append((ch.name, float(seen.mean())))
    if unshade == 'auto': unshade = shading_followed(stats)
    opts['_unshade'] = unshade
    per = [(k, i, c * (1 - unshade + unshade * SHADE_REF / sh[..., None]) if unshade else c, w) for k, i, c, w, sh in per]
    # The image model often lights its two views a little differently: match their colours where both saw the
    # same surface, then blend each texel by how squarely each view faced it (no hard seam).
    gain = [np.ones(3) for _ in vs]
    if len(vs) == 2:
        A, B = [], []
        for k in range(len(charts)):
            s0 = [x for x in per if x[0] == k and x[1] == 0]; s1 = [x for x in per if x[0] == k and x[1] == 1]
            if s0 and s1:
                both = (s0[0][3] > 0) & (s1[0][3] > 0)
                if both.any(): A.append(s0[0][2][both]); B.append(s1[0][2][both])
        if A and sum(len(a) for a in A) > 200:
            ma = np.concatenate(A).mean(0) + 1; mb = np.concatenate(B).mean(0) + 1
            gain = [np.sqrt(mb / ma), np.sqrt(ma / mb)]
    for k in range(len(charts)):
        acc = 0; ws = 0
        for kk, i, c, w in per:
            if kk == k: acc = acc + c * gain[i] * w[..., None]; ws = ws + w
        if not isinstance(ws, int): chart_img[k][0] = acc / np.maximum(ws, 1e-9)[..., None]
    model['_view_gain'] = [g.round(3).tolist() for g in gain]
    seen_cols = [chart_img[k][0][chart_img[k][1]] for k in range(len(charts)) if chart_img[k][1].any()]
    model['_mean_colour'] = np.concatenate(seen_cols).mean(0) if seen_cols else np.array([128.0, 128, 128])
    # fill what no view saw
    byname = {ch.name: k for k, ch in enumerate(charts)}
    for k, ch in enumerate(charts):
        col, seen = chart_img[k]
        cov = seen.mean()
        if cov >= 0.35: chart_img[k][0] = pushpull(col, seen); continue
        opp = byname.get(f'{ch.part}.{ch.opposite}') if ch.opposite else None
        if ch.side == 'bottom' or opp is None or chart_img[opp][1].mean() < 0.35:
            # a flat cap: the colour along the bottom of this part's sides, a little darker
            rows = []
            for j, c2 in enumerate(charts):
                if c2.part == ch.part and j != k and chart_img[j][1].mean() > 0.35:
                    cimg, cs = chart_img[j]; n8 = max(1, cimg.shape[0] // 8)
                    rows.append(cimg[-n8:][cs[-n8:]])
            base = np.concatenate(rows).mean(0) * 0.85 if rows else np.array([128.0, 128, 128])
            if cov > 0.1: chart_img[k][0] = pushpull(col, seen)
            else: chart_img[k][0] = np.where(seen[..., None], col, base)
        else:
            src = Image.fromarray(np.clip(pushpull(*chart_img[opp]), 0, 255).astype(np.uint8)).resize((ch.w, ch.h), Image.BILINEAR)
            src = np.asarray(src.transpose(Image.FLIP_LEFT_RIGHT if ch.flip == 'h' else Image.FLIP_TOP_BOTTOM), np.float64)
            chart_img[k][0] = np.where(seen[..., None], col, src)
    for k, ch in enumerate(charts):
        atlas[ch.y0:ch.y0 + ch.h, ch.x0:ch.x0 + ch.w] = chart_img[k][0]; filled[ch.y0:ch.y0 + ch.h, ch.x0:ch.x0 + ch.w] = True
    # bleed into the gaps so mip/filtering never picks up black
    for _ in range(12):
        if filled.all(): break
        acc = np.zeros_like(atlas); cnt = np.zeros(filled.shape)
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            acc += np.roll(np.roll(atlas * filled[..., None], dy, 0), dx, 1); cnt += np.roll(np.roll(filled, dy, 0), dx, 1)
        new = (~filled) & (cnt > 0)
        atlas[new] = acc[new] / cnt[new][:, None]; filled |= new
    return np.clip(atlas, 0, 255), al, report

def logo_chart(model, charts):
    """The face that carries the brand logo: model['logo'] = 'part.side', true (the biggest bottom face) or false."""
    want = model.get('logo', True)
    if not want: return None
    if isinstance(want, str): return next((c for c in charts if c.name == want), None)
    bottoms = [c for c in charts if c.side == 'bottom']
    return max(bottoms, key=lambda c: c.w * c.h) if bottoms else None

def logo_overlay(size, ch, S, colour):
    """RGBA layer: the face's background in the model's average colour with the Grug Digital logo in the middle.
    Laid over the finished texture, after the retro look, so it stays crisp."""
    ov = np.zeros((size, size, 4), np.uint8)
    if ch is None: return ov
    k = size / S
    x0, y0 = int(round(ch.x0 * k)), int(round(ch.y0 * k)); x1, y1 = int(round((ch.x0 + ch.w) * k)), int(round((ch.y0 + ch.h) * k))
    if x1 - x0 < 8 or y1 - y0 < 8: return ov
    colour = np.clip(colour, 0, 255)
    lum = colour @ np.array([0.299, 0.587, 0.114])
    lg = Image.open(HERE / ('logo-light.png' if lum > 140 else 'logo-dark.png')).convert('RGBA')
    bw, bh = (x1 - x0) * 0.72, (y1 - y0) * 0.72; sc = min(bw / lg.width, bh / lg.height)
    lg = lg.resize((max(1, int(lg.width * sc)), max(1, int(lg.height * sc))), Image.LANCZOS)
    tile = Image.new('RGBA', (x1 - x0, y1 - y0), tuple(int(c) for c in colour) + (255,))
    tile.alpha_composite(lg, ((tile.width - lg.width) // 2, (tile.height - lg.height) // 2))
    ov[y0:y1, x0:x1] = np.asarray(tile)
    return ov


# ----------------------------------------------------------------------------------------------
# Baked lighting: ambient occlusion, a soft room light with shadows, and glow from parts that give off light
# (maps at half the texture size, so the bake stays quick; they are smooth anyway)
# ----------------------------------------------------------------------------------------------

LIGHT_DEFAULT = {'ao': 1.0, 'room': 0.6, 'lights': 1.0, 'detail': 0.32, 'bounce': 1.05}
LIGHT_RES, BOUNCE_RES, LIVE_RES = 192, 128, 128   # grids the light is worked out on (smooth, so upsampled to the texture)

def light_of(model):
    return {k: float(model.get('light', {}).get(k, v)) for k, v in LIGHT_DEFAULT.items()}

def ray_hits(O, D, tmax, tri, eps):
    """Any triangle hit along each ray between eps and tmax (Moller-Trumbore, in chunks)."""
    out = np.zeros(len(O), bool)
    if not len(tri): return out
    v0 = tri[:, 0]; e1 = tri[:, 1] - v0; e2 = tri[:, 2] - v0
    for i in range(0, len(O), 1536):
        o = O[i:i + 1536, None, :]; d = D[i:i + 1536, None, :]
        pv = np.cross(d, e2[None]); det = (e1[None] * pv).sum(-1)
        ok = np.abs(det) > 1e-12; inv = np.where(ok, 1 / np.where(ok, det, 1), 0)
        sv = o - v0[None]; u = (sv * pv).sum(-1) * inv
        qv = np.cross(sv, e1[None]); v = (d * qv).sum(-1) * inv; t = (e2[None] * qv).sum(-1) * inv
        h = ok & (u >= 0) & (v >= 0) & (u + v <= 1) & (t > eps) & (t < tmax[i:i + 1536, None])
        out[i:i + 1536] = h.any(1)
    return out

def frame(N):
    a = np.where(np.abs(N[:, 1:2]) < 0.9, np.array([[0, 1.0, 0]]), np.array([[1.0, 0, 0]]))
    T = norm(np.cross(a, N)); B = np.cross(N, T)
    return T, B

def base_part(name):
    return name.split('_m')[0]

def emissive_parts(model):
    return {p['name']: p.get('emissive') for p in model['parts'] if p.get('emissive')}

def light_nodes(model):
    """Light nodes: [{pos, color, strength, range}]. A part with "emissive" and no nodes gets one in its middle."""
    nodes = [dict(n) for n in model.get('lights', [])]
    if not nodes:
        for p in model['parts']:
            e = p.get('emissive')
            if e: nodes.append({'pos': list(p.get('center', [0, 0, 0])), 'color': e.get('color', [255, 220, 140]), 'strength': e.get('strength', 1.0), 'range': e.get('range', 3.0)})
    return nodes

def light_grid(model, charts, S, res):
    """Position, normal and part of every texel on a res x res grid over the atlas."""
    k = res / S; owner = -np.ones((res, res), int); XX = np.zeros((res, res, 3)); NN = np.zeros((res, res, 3))
    for ci, ch in enumerate(charts):
        X, Nn = chart_texels(ch)
        gx = np.arange(int(math.floor(ch.x0 * k)), min(int(math.ceil((ch.x0 + ch.w) * k)), res))
        gy = np.arange(int(math.floor(ch.y0 * k)), min(int(math.ceil((ch.y0 + ch.h) * k)), res))
        ix = ((gx + 0.5) / k - ch.x0); iy = ((gy + 0.5) / k - ch.y0)
        okx = (ix >= 0) & (ix < ch.w); oky = (iy >= 0) & (iy < ch.h)
        if not okx.any(): okx[np.argmin(np.abs(ix - ch.w / 2))] = True
        if not oky.any(): oky[np.argmin(np.abs(iy - ch.h / 2))] = True
        Y, Xg = np.meshgrid(gy[oky], gx[okx], indexing='ij')
        iyy, ixx = np.meshgrid(np.clip(iy[oky].astype(int), 0, ch.h - 1), np.clip(ix[okx].astype(int), 0, ch.w - 1), indexing='ij')
        owner[Y, Xg] = ci; XX[Y, Xg] = X[iyy, ixx]; NN[Y, Xg] = Nn[iyy, ixx]
    return owner, XX, NN

def node_light(P, N, nodes, blockers, eps):
    """Coloured light from the nodes, with hard shadows (emissive parts let light through)."""
    out = np.zeros((len(P), 3)); O = P + N * eps
    for nd in nodes:
        lp = np.asarray(nd['pos'], np.float64); col = np.asarray(nd.get('color', [255, 255, 255]), np.float64) / 255
        st = float(nd.get('strength', 1.0)); rg = max(1e-3, float(nd.get('range', 3.0)))
        d = lp - O; dist = np.linalg.norm(d, axis=1); dh = d / np.maximum(dist, 1e-9)[:, None]
        w = np.clip((N * dh).sum(1), 0, 1) * np.clip(1 - (dist / rg) ** 4, 0, 1) ** 2 / (1 + 4 * (dist / rg) ** 2) * st
        todo = w > 1e-4
        if todo.any():
            blocked = ray_hits(O[todo], dh[todo], dist[todo] - eps, blockers, eps)
            idx = np.where(todo)[0][blocked]; w[idx] = 0
        out += w[:, None] * col
    return out

def spread(maps, filled, steps=4):
    res = filled.shape[0]
    for _ in range(steps):
        cnt = np.zeros((res, res)); accs = {kk: np.zeros_like(v) for kk, v in maps.items()}
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            sh = np.roll(np.roll(filled, dy, 0), dx, 1); cnt += sh
            for kk, v in maps.items():
                accs[kk] += np.roll(np.roll(v * (filled[..., None] if v.ndim == 3 else filled), dy, 0), dx, 1)
        new = ~filled & (cnt > 0)
        for kk, v in maps.items():
            v[new] = (accs[kk][new].T / cnt[new]).T
        filled |= new

def light_maps(model, charts, S, res, seed=7):
    """AO, room light, light-node colour and emission maps on a res x res grid over the atlas."""
    pos, uv, cid, nrm = mesh(charts)
    size = np.ptp(pos.reshape(-1, 3), 0).max(); eps = size * 2e-3
    owner, XX, NN = light_grid(model, charts, S, res)
    m = owner >= 0; P = XX[m]; N = NN[m]; n = len(P); rng = np.random.default_rng(seed); O = P + N * eps
    lt = model.get('light', {})
    # ambient occlusion: cosine-weighted rays over the hemisphere, each texel with its own twist
    K = int(lt.get('ao_rays', 32)); reach = size * float(lt.get('ao_reach', 0.35))
    T, B = frame(N); vis = np.zeros(n)
    for j in range(K):
        u1 = (j + rng.random(n)) / K; u2 = rng.random(n)
        r = np.sqrt(u1); ph = 2 * np.pi * u2
        D = T * (r * np.cos(ph))[:, None] + B * (r * np.sin(ph))[:, None] + N * np.sqrt(1 - u1)[:, None]
        vis += ~ray_hits(O, D, np.full(n, reach), pos, eps)
    ao = vis / K
    # room light: overhead and a little to the front-left, soft shadows
    Ld = norm(np.array(lt.get('room_dir', [-0.35, 1.0, 0.45]))); lit = np.zeros(n); J = 8
    for j in range(J):
        jit = norm(Ld + rng.normal(0, 0.12, (n, 3)))
        lit += ~ray_hits(O, jit, np.full(n, size * 4), pos, eps)
    room = np.clip(N @ Ld, 0, 1) * lit / J
    # light nodes and emissive parts
    em = emissive_parts(model)
    tri_em = np.array([base_part(charts[c].part) in em for c in cid])
    lights = node_light(P, N, light_nodes(model), pos[~tri_em], eps)
    emit = np.zeros((n, 3)); opart = np.array([base_part(charts[c].part) for c in owner[m]])
    for name, e in em.items():
        emit[opart == name] = np.asarray(e.get('color', [255, 220, 140]), np.float64) / 255 * float(e.get('strength', 1.0))
    def full(v):
        a = np.zeros((res, res) + v.shape[1:]); a[m] = v; return a
    maps = {'ao': full(ao), 'room': full(room), 'lights': full(np.clip(lights, 0, 2)), 'emit': full(np.clip(emit, 0, 2))}
    spread(maps, m.copy())
    a = maps['ao']; b = a.copy()  # soften the ray noise
    b[1:-1, 1:-1] = (a[:-2, :-2] + a[:-2, 1:-1] + a[:-2, 2:] + a[1:-1, :-2] + 2 * a[1:-1, 1:-1] + a[1:-1, 2:] + a[2:, :-2] + a[2:, 1:-1] + a[2:, 2:]) / 10
    maps['ao'] = b
    return maps

def grid_data(model, charts, S, res):
    """What a page needs to re-light the model live: texel positions and normals, and the shadow-casting triangles."""
    owner, XX, NN = light_grid(model, charts, S, res)
    pos, uv, cid, nrm = mesh(charts); em = emissive_parts(model)
    keep = np.array([base_part(charts[c].part) not in em for c in cid])
    b64 = lambda a, t: base64.b64encode(np.ascontiguousarray(a, t).tobytes()).decode()
    c = (pos.reshape(-1, 3).max(0) + pos.reshape(-1, 3).min(0)) / 2
    return {'res': res, 'mask': b64(owner >= 0, np.uint8), 'P': b64(XX - c, np.float32), 'N': b64(NN, np.float32),
            'blockers': b64(pos[keep] - c, np.float32), 'eps': float(np.ptp(pos.reshape(-1, 3), 0).max() * 2e-3), 'centre': c.tolist()}


# ----------------------------------------------------------------------------------------------
# Materials: tileable normal-map presets per part (chosen in model.json), plus stitched seams along face edges
# Heights are made in world units on each face (right = +u, down = +v), so the pattern has the same size everywhere.
# ----------------------------------------------------------------------------------------------

def _noise(u, v, scale, seed):
    """Smooth value noise, tileable enough for small faces."""
    rng = np.random.default_rng(seed); g = rng.random((64, 64))
    x = u / scale; y = v / scale; x0 = np.floor(x).astype(int); y0 = np.floor(y).astype(int); fx = x - x0; fy = y - y0
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy)
    a = g[y0 % 64, x0 % 64]; b = g[y0 % 64, (x0 + 1) % 64]; c = g[(y0 + 1) % 64, x0 % 64]; d = g[(y0 + 1) % 64, (x0 + 1) % 64]
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy

def _cells(u, v, scale, seed):
    """Worley-style bumps (pebbled leather)."""
    rng = np.random.default_rng(seed); jit = rng.random((32, 32, 2))
    x = u / scale; y = v / scale; xi = np.floor(x).astype(int); yi = np.floor(y).astype(int); best = np.full(u.shape, 9.0)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            cx = xi + dx; cy = yi + dy; j = jit[cy % 32, cx % 32]
            dd = (x - cx - j[..., 0]) ** 2 + (y - cy - j[..., 1]) ** 2; best = np.minimum(best, dd)
    return 1 - np.clip(np.sqrt(best), 0, 1)

MATERIALS = {
    'none':    (lambda u, v: np.zeros_like(u), False, 0.0),
    'plastic': (lambda u, v: _noise(u, v, 0.6, 1) * 0.15, False, 0.4),
    'leather': (lambda u, v: _cells(u, v, 0.045, 2) ** 2 + 0.3 * _noise(u, v, 0.02, 3), True, 1.0),
    'suede':   (lambda u, v: _noise(u, v, 0.012, 4) * 0.6 + _noise(u, v, 0.05, 5) * 0.4, True, 0.7),
    'canvas':  (lambda u, v: (np.sin(u / 0.012 * np.pi) * np.sin(v / 0.012 * np.pi)) * 0.5 + 0.5, True, 0.8),
    'denim':   (lambda u, v: (np.sin((u + v) / 0.016 * np.pi) * 0.5 + 0.5) * 0.8 + _noise(u, v, 0.03, 6) * 0.2, True, 0.9),
    'wool':    (lambda u, v: np.abs(np.sin(v / 0.05 * np.pi)) ** 0.5 * (0.6 + 0.4 * np.abs(np.sin((u * 2 + np.abs((v % 0.1) - 0.05) * 6) / 0.05 * np.pi))), True, 1.2),
    'knit':    (lambda u, v: np.abs(np.sin(u / 0.045 * np.pi)) * (0.5 + 0.5 * np.abs(np.sin((v + np.abs((u % 0.09) - 0.045)) / 0.045 * np.pi))), True, 1.2),
    'quilted': (lambda u, v: 1 - np.minimum(np.abs(((u + v) % 0.3) - 0.15), np.abs(((u - v) % 0.3) - 0.15)) / 0.15 * 0 - (np.minimum(np.abs(((u + v) % 0.3) - 0.15), np.abs(((u - v) % 0.3) - 0.15)) < 0.012) * 1.0, True, 1.0),
    'metal':   (lambda u, v: _noise(u * 0.05, v * 8, 0.05, 7) * 0.4 + _cells(u, v, 0.3, 8) ** 6 * -0.6, False, 0.6),
    'wood':    (lambda u, v: np.sin((v + _noise(u, v, 0.25, 9) * 0.15) / 0.03 * np.pi) * 0.5 + 0.5, False, 0.7),
    'glass':   (lambda u, v: np.zeros_like(u), False, 0.0),
    'fur':     (lambda u, v: _noise(u * 4, v * 0.6, 0.02, 10), False, 1.0),
}

def part_material(model, name):
    p = next((q for q in model['parts'] if q['name'] == base_part(name)), {})
    m = p.get('material', model.get('material', 'none')); kind = MATERIALS.get(m, MATERIALS['none'])
    seams = p.get('seams', kind[1]); return m, kind, seams

def normal_atlas(model, charts, S, res):
    """Tangent-space normal map (res x res x 3, -1..1) for the atlas: x = face right, y = face down... stored GL style (y up)."""
    dens = model['_density'] * res / S; H = np.zeros((res, res)); edge_w = 0.035; k = res / S
    has = np.zeros((res, res), bool)
    for ch in charts:
        x0, y0 = int(math.floor(ch.x0 * k)), int(math.floor(ch.y0 * k)); x1, y1 = int(math.ceil((ch.x0 + ch.w) * k)), int(math.ceil((ch.y0 + ch.h) * k))
        x1 = min(x1, res); y1 = min(y1, res)
        if x1 <= x0 or y1 <= y0: continue
        yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float64)
        u = (xx + 0.5 - ch.x0 * k) / dens; v = (yy + 0.5 - ch.y0 * k) / dens
        m, (fn, _, amp), seams = part_material(model, ch.part)
        h = fn(u, v) * amp * 0.012
        if seams and ch.kind == 'grid':
            W = ch.w / model['_density']; Hh = ch.h / model['_density']
            d = np.minimum(np.minimum(u, W - u), np.minimum(v, Hh - v))
            groove = np.clip(1 - np.abs(d - edge_w) / 0.012, 0, 1)
            along = np.where(np.minimum(u, W - u) < np.minimum(v, Hh - v), v, u)
            stitch = (np.sin(along / 0.04 * np.pi) > 0.2) * np.clip(1 - np.abs(d - edge_w) / 0.006, 0, 1)
            h = h - groove * 0.01 + stitch * 0.006 + np.clip(1 - d / edge_w, 0, 1) * -0.004
        H[y0:y1, x0:x1] = h; has[y0:y1, x0:x1] = True
    # heights -> normals (world units per texel = 1 / dens)
    gx = (np.roll(H, -1, 1) - np.roll(H, 1, 1)) * dens / 2; gy = (np.roll(H, -1, 0) - np.roll(H, 1, 0)) * dens / 2
    n = np.stack([-gx, -gy, np.ones_like(H)], -1); n = n / np.linalg.norm(n, axis=-1, keepdims=True)
    n[~has] = [0, 0, 1]
    return n  # x = face right, y = face down, z = out

def detail_shade(nmap):
    """How the normal map darkens / lightens each texel under a light from the face's upper left (1 on flat)."""
    Lt = norm(np.array([-0.45, -0.55, 0.7]))
    return np.clip((nmap @ Lt) / Lt[2], 0.4, 1.6)

def normal_png(nmap):
    """Encode for engines: OpenGL convention (green = up), x = right."""
    t = nmap.copy(); t[..., 1] = -t[..., 1]
    return ((t * 0.5 + 0.5) * 255).clip(0, 255).astype(np.uint8)

def closest_hits(O, D, tri, eps):
    """Nearest hit per ray: (t, triangle index or -1, u, v)."""
    n = len(O); T = np.full(n, np.inf); I = -np.ones(n, int); U = np.zeros(n); V = np.zeros(n)
    v0 = tri[:, 0]; e1 = tri[:, 1] - v0; e2 = tri[:, 2] - v0
    for i in range(0, n, 1024):
        o = O[i:i + 1024, None, :]; d = D[i:i + 1024, None, :]
        pv = np.cross(d, e2[None]); det = (e1[None] * pv).sum(-1)
        ok = np.abs(det) > 1e-12; inv = np.where(ok, 1 / np.where(ok, det, 1), 0)
        sv = o - v0[None]; u = (sv * pv).sum(-1) * inv
        qv = np.cross(sv, e1[None]); v = (d * qv).sum(-1) * inv; t = (e2[None] * qv).sum(-1) * inv
        h = ok & (u >= 0) & (v >= 0) & (u + v <= 1) & (t > eps)
        t = np.where(h, t, np.inf); j = t.argmin(1); tm = t[np.arange(len(j)), j]
        hit = np.isfinite(tm); sl = slice(i, i + len(j))
        T[sl] = tm; I[sl] = np.where(hit, j, -1); U[sl] = u[np.arange(len(j)), j]; V[sl] = v[np.arange(len(j)), j]
    return T, I, U, V

def bounce_map(model, charts, S, res, albedo_small, direct_small, rays=48, seed=11):
    """One bounce of path-traced light: what each texel receives from the surfaces around it (colour bleeding), plus sky."""
    pos, uv, cid, nrm = mesh(charts)
    size = np.ptp(pos.reshape(-1, 3), 0).max(); eps = size * 2e-3
    owner, XX, NN = light_grid(model, charts, S, res); m = owner >= 0; P = XX[m]; N = NN[m]; n = len(P)
    O = P + N * eps; T, B = frame(N); rng = np.random.default_rng(seed); acc = np.zeros((n, 3))
    sky = np.array(model.get('light', {}).get('sky', [0.55, 0.58, 0.62]))
    ah, aw = albedo_small.shape[:2]
    for j in range(rays):
        u1 = (j + rng.random(n)) / rays; u2 = rng.random(n); r = np.sqrt(u1); ph = 2 * np.pi * u2
        D = T * (r * np.cos(ph))[:, None] + B * (r * np.sin(ph))[:, None] + N * np.sqrt(1 - u1)[:, None]
        t, ti, bu, bv = closest_hits(O, D, pos, eps)
        hit = ti >= 0; contrib = np.tile(sky * np.clip(D[:, 1] * 0.5 + 0.6, 0.2, 1.1)[:, None], (1, 1))
        if hit.any():
            q = uv[ti[hit]]; w0 = 1 - bu[hit] - bv[hit]
            tuv = q[:, 0] * w0[:, None] + q[:, 1] * bu[hit][:, None] + q[:, 2] * bv[hit][:, None]
            px = np.clip((tuv[:, 0] / S * aw).astype(int), 0, aw - 1); py = np.clip((tuv[:, 1] / S * ah).astype(int), 0, ah - 1)
            contrib[hit] = albedo_small[py, px] / 255 * direct_small[py, px]
        acc += contrib
    out = np.zeros((res, res, 3)); out[m] = acc / rays
    mp = {'b': out}; spread(mp, m.copy()); return mp['b']

def composite(albedo, maps, L):
    """albedo (h, w, 3) 0..255, maps at the same size -> lit colours. Emissive texels ignore AO and room light.
    Same maths as the 3D preview page and the Studio, so a slider there gives the same texture."""
    ao, room, lights, emit = maps['ao'][..., None], maps['room'][..., None], maps['lights'], maps['emit']
    e = (emit.max(-1, keepdims=True) > 0.01)
    shade = (1 - L['ao'] + L['ao'] * ao) * ((1 - 0.45 * L['room']) + 0.9 * L['room'] * room)
    det = 1 + L.get('detail', 0) * (maps['detail'][..., None] - 1) if 'detail' in maps else 1
    bounce = L.get('bounce', 0) * maps['bounce'] if 'bounce' in maps else 0
    light = shade * det + L['lights'] * lights + bounce
    out = albedo * light
    # emissive texels: not shaded, and pulled toward their own light colour so a yellow glow stays yellow
    mx = emit.max(-1, keepdims=True); t = np.clip(0.45 * L['lights'] * mx, 0, 0.7) * (albedo @ np.array([0.299, 0.587, 0.114]))[..., None] / 255
    glowc = albedo * (1 - t) + emit / np.maximum(mx, 1e-6) * 255 * t
    return np.clip(np.where(e, glowc, out), 0, 255)

BAYER = (np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) + 0.5) / 16 - 0.5

FX_PRESETS = {  # the same looks as the Clothing Studio's presets
    'ps1':   {'bits': 4, 'dither': 1.0, 'contrast': 0.06, 'sat': 0.0},
    'n64':   {'bits': 5, 'dither': 0.35, 'contrast': 0.04, 'sat': 0.1, 'smooth': True},
    '16bit': {'palette': 24, 'dither': 0.45, 'contrast': 0.06, 'sat': 0.18},
    'clean': {'bits': 8, 'dither': 0, 'contrast': 0.04, 'sat': 0.05},
}

FX_DEFAULT = {'bits': 4, 'dither': 1.0, 'pixel': 2, 'contrast': 0.5, 'sat': 0.0, 'bright': 0.0}  # the owner's picks

def fx_of(fx):
    """The texture effects: the default look (or a preset by name), with any of the model's own settings on top."""
    f = dict(FX_PRESETS[fx['preset']]) if fx.get('preset') in FX_PRESETS else dict(FX_DEFAULT)
    f.update({k: v for k, v in fx.items() if k != 'preset'})
    return f

def grade(tex, size, fx):
    """Shrink the atlas to the game texture size and adjust contrast / saturation."""
    f = fx_of(fx)
    a = np.asarray(Image.fromarray(tex.astype(np.uint8)).resize((size, size), Image.BOX), np.float64)
    if f.get('contrast'): a = (a - 128) * (1 + f['contrast']) + 128
    if f.get('sat'):
        g = a.mean(-1, keepdims=True); a = g + (a - g) * (1 + f['sat'])
    return np.clip(a, 0, 255)

def quantise(a, fx):
    """Colour quantisation with ordered (Bayer) dithering, like the Clothing Studio's presets."""
    f = fx_of(fx)
    if f.get('bright'): a = np.clip(a + f['bright'] * 255, 0, 255)
    px = int(f.get('pixel', 1))
    if px > 1:  # bigger texture pixels: one colour (and one dither cell) per px x px block
        H0, W0 = a.shape[:2]; a = np.asarray(Image.fromarray(a.astype(np.uint8)).resize((W0 // px, H0 // px), Image.BOX), np.float64)
        out = quantise(a, dict(f, pixel=1, bright=0))
        return np.asarray(Image.fromarray(out).resize((W0, H0), Image.NEAREST))
    h, w = a.shape[:2]; bay = np.tile(BAYER, (h // 4 + 1, w // 4 + 1))[:h, :w, None] * f.get('dither', 0)
    if f.get('palette'):
        pal = Image.fromarray(a.astype(np.uint8)).quantize(colors=int(f['palette']), method=Image.MEDIANCUT, dither=Image.NONE)
        P = np.asarray(pal.getpalette()[:3 * int(f['palette'])], np.float64).reshape(-1, 3)
        b = np.clip(a + bay * 48, 0, 255)
        a = P[((b[:, :, None, :] - P[None, None]) ** 2).sum(-1).argmin(-1)]
    elif f.get('bits', 8) < 8:
        q = 255 / (2 ** f['bits'] - 1)
        a = np.round(np.clip(a + bay * q, 0, 255) / q) * q
    return np.clip(a, 0, 255).astype(np.uint8)

def retro(tex, size, fx):
    return quantise(grade(tex, size, fx), fx)

# ----------------------------------------------------------------------------------------------
# Exports
# ----------------------------------------------------------------------------------------------

def tangents(pos, uv):
    """Per-triangle tangent (direction of +u) with handedness for glTF (bitangent = up in the image)."""
    e1 = pos[:, 1] - pos[:, 0]; e2 = pos[:, 2] - pos[:, 0]
    d1 = uv[:, 1] - uv[:, 0]; d2 = uv[:, 2] - uv[:, 0]
    r = d1[:, 0] * d2[:, 1] - d2[:, 0] * d1[:, 1]; r = np.where(np.abs(r) < 1e-12, 1e-12, r)
    T = (e1 * d2[:, 1:2] - e2 * d1[:, 1:2]) / r[:, None]; Bd = (e2 * d1[:, 0:1] - e1 * d2[:, 0:1]) / r[:, None]  # Bd = down in the image
    N = norm(np.cross(e1, e2)); T = norm(T - N * (N * T).sum(1, keepdims=True))
    w = np.sign((np.cross(N, T) * -Bd).sum(1)); w[w == 0] = 1
    return np.concatenate([T, w[:, None]], 1)

def outline_hull(pos, width):
    """The inverted hull: every corner pushed out along its smoothed normal, faces flipped (Roblox-style outline)."""
    P = pos.reshape(-1, 3); key = np.round(P * 1e4).astype(np.int64)
    _, inv = np.unique(key, axis=0, return_inverse=True); inv = inv.reshape(-1)
    fn = np.cross(pos[:, 1] - pos[:, 0], pos[:, 2] - pos[:, 0])  # area-weighted
    acc = np.zeros((inv.max() + 1, 3)); np.add.at(acc, inv, np.repeat(fn, 3, 0))
    sn = norm(acc)[inv]
    H = (P + sn * width).reshape(-1, 3, 3)[:, [0, 2, 1]]
    return H, norm(np.cross(H[:, 1] - H[:, 0], H[:, 2] - H[:, 0]))

OUTLINE_DEFAULT = {'width': 0.027, 'color': [5, 5, 5]}

def outline_cfg(model):
    """The outline is on unless model.json says "outline": false. width is a share of the model's size (radius x 2)."""
    o = model.get('outline', True)
    if o is False: return None
    return dict(OUTLINE_DEFAULT, **(o if isinstance(o, dict) else {}))

def outline_of(model, pos):
    o = outline_cfg(model)
    if o is None: return None
    P = pos.reshape(-1, 3); r = np.linalg.norm(P - (P.max(0) + P.min(0)) / 2, axis=1).max()
    H, HN = outline_hull(pos, 2 * r * float(o['width']))
    return H, HN, [c / 255 for c in o['color']]

def export_obj(path, name, pos, uv, nrm, S, scale, outline=None):
    L = [f'# {name}, made with Image2LoPol', f'mtllib {path.stem}.mtl', f'o {path.stem}']
    for t in pos:
        for v in t: L.append('v %.5f %.5f %.5f' % tuple(v * scale))
    for t in uv:
        for u in t: L.append('vt %.6f %.6f' % (u[0] / S, 1 - u[1] / S))
    for n in nrm: L.append('vn %.5f %.5f %.5f' % tuple(n))
    L.append('usemtl lopol'); L.append('s off')
    for i in range(len(pos)):
        a = 3 * i + 1; L.append(f'f {a}/{a}/{i+1} {a+1}/{a+1}/{i+1} {a+2}/{a+2}/{i+1}')
    mtl = 'newmtl lopol\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\nd 1\nillum 1\nmap_Kd texture.png\nnorm normal.png\n'
    if outline is not None:
        H, HN, col = outline; nv = 3 * len(pos); nn = len(pos)
        L.append('o outline')
        for t in H:
            for v in t: L.append('v %.5f %.5f %.5f' % tuple(v * scale))
        for n in HN: L.append('vn %.5f %.5f %.5f' % tuple(n))
        L.append('usemtl outline')
        for i in range(len(H)):
            a = nv + 3 * i + 1; L.append(f'f {a}//{nn+i+1} {a+1}//{nn+i+1} {a+2}//{nn+i+1}')
        mtl += 'newmtl outline\nKa 0 0 0\nKd %.3f %.3f %.3f\nKs 0 0 0\nd 1\nillum 0\n' % tuple(col)
    path.write_text('\n'.join(L) + '\n')
    path.with_suffix('.mtl').write_text(mtl)

def export_glb(path, name, pos, uv, nrm, S, png_bytes, scale, normal_bytes=None, outline=None):
    P = (pos.reshape(-1, 3) * scale).astype(np.float32); N = np.repeat(nrm, 3, 0).astype(np.float32)
    T = (uv.reshape(-1, 2) / S).astype(np.float32); TG = np.repeat(tangents(pos, uv), 3, 0).astype(np.float32)
    bufs = [P.tobytes(), N.tobytes(), T.tobytes(), TG.tobytes(), png_bytes]
    if normal_bytes: bufs.append(normal_bytes)
    if outline is not None:
        H, HN, col = outline
        HP = (H.reshape(-1, 3) * scale).astype(np.float32); HNN = np.repeat(HN, 3, 0).astype(np.float32)
        bufs += [HP.tobytes(), HNN.tobytes()]
    views, blob = [], b''
    for b in bufs:
        views.append({'buffer': 0, 'byteOffset': len(blob), 'byteLength': len(b)}); blob += b; blob += b'\0' * ((-len(blob)) % 4)
    for i in (0, 1, 2, 3): views[i]['target'] = 34962
    acc = [{'bufferView': 0, 'componentType': 5126, 'count': len(P), 'type': 'VEC3', 'min': P.min(0).tolist(), 'max': P.max(0).tolist()},
           {'bufferView': 1, 'componentType': 5126, 'count': len(N), 'type': 'VEC3'},
           {'bufferView': 2, 'componentType': 5126, 'count': len(T), 'type': 'VEC2'},
           {'bufferView': 3, 'componentType': 5126, 'count': len(TG), 'type': 'VEC4'}]
    mat = {'name': 'lopol', 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 0, 'roughnessFactor': 1}}
    images = [{'bufferView': 4, 'mimeType': 'image/png'}]; textures = [{'source': 0, 'sampler': 0}]
    if normal_bytes:
        images.append({'bufferView': 5, 'mimeType': 'image/png'}); textures.append({'source': 1, 'sampler': 0}); mat['normalTexture'] = {'index': 1}
    prims = [{'attributes': {'POSITION': 0, 'NORMAL': 1, 'TEXCOORD_0': 2, 'TANGENT': 3}, 'material': 0}]
    mats = [mat]; ext = []
    if outline is not None:
        k = len(views) - 2; views[k]['target'] = 34962; views[k + 1]['target'] = 34962
        acc += [{'bufferView': k, 'componentType': 5126, 'count': len(HP), 'type': 'VEC3', 'min': HP.min(0).tolist(), 'max': HP.max(0).tolist()},
                {'bufferView': k + 1, 'componentType': 5126, 'count': len(HNN), 'type': 'VEC3'}]
        prims.append({'attributes': {'POSITION': len(acc) - 2, 'NORMAL': len(acc) - 1}, 'material': 1})
        mats.append({'name': 'outline', 'pbrMetallicRoughness': {'baseColorFactor': list(col) + [1], 'metallicFactor': 0, 'roughnessFactor': 1}, 'extensions': {'KHR_materials_unlit': {}}})
        ext = ['KHR_materials_unlit']
    gl = {'asset': {'version': '2.0', 'generator': 'Image2LoPol'}, 'scene': 0, 'scenes': [{'nodes': [0]}],
          'nodes': [{'mesh': 0, 'name': name}], 'meshes': [{'name': name, 'primitives': prims}],
          'accessors': acc, 'bufferViews': views, 'buffers': [{'byteLength': len(blob)}],
          'images': images, 'samplers': [{'magFilter': 9728, 'minFilter': 9728}], 'textures': textures, 'materials': mats}
    if ext: gl['extensionsUsed'] = ext
    js = json.dumps(gl, separators=(',', ':')).encode(); js += b' ' * ((-len(js)) % 4)
    out = struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(js) + 8 + len(blob)) + struct.pack('<II', len(js), 0x4E4F534A) + js + struct.pack('<II', len(blob), 0x004E4942) + blob
    path.write_bytes(out)

def preview_data(name, pos, uv, nrm, S, png_bytes, md=None, look=None):
    P = pos.reshape(-1, 3).astype(np.float32); c = (P.max(0) + P.min(0)) / 2; P = P - c
    b64 = lambda a: base64.b64encode(np.ascontiguousarray(a, np.float32).tobytes()).decode()
    data = {'name': name, 'pos': b64(P), 'nrm': b64(np.repeat(nrm, 3, 0)), 'uv': b64(uv.reshape(-1, 2) / S),
            'tan': b64(np.repeat(tangents(pos, uv), 3, 0)),
            'tex': 'data:image/png;base64,' + base64.b64encode(png_bytes).decode(), 'radius': float(np.linalg.norm(P, axis=1).max())}
    if md is not None:
        url = lambda f: 'data:image/png;base64,' + base64.b64encode((md / f).read_bytes()).decode()
        keys = ['albedo', 'ao', 'room', 'emit', 'logo', 'detail', 'normal'] + (['bounce'] if (md / 'bounce.png').exists() else [])
        data['maps'] = {k: url(k + '.png') for k in keys}
        data['look'] = look
    return data

def export_preview(path, name, pos, uv, nrm, S, png_bytes, md=None, look=None):
    tpl = (HERE / 'viewer.html').read_text()
    data = preview_data(name, pos, uv, nrm, S, png_bytes, md, look)
    path.write_text(tpl.replace('__TITLE__', name).replace('__VIEWER_JS__', (HERE / 'lopol-view.js').read_text()).replace('__DATA__', json.dumps(data)))

# ----------------------------------------------------------------------------------------------
# Commands
# ----------------------------------------------------------------------------------------------

def load(item):
    item = pathlib.Path(item); model = json.loads((item / 'model.json').read_text())
    return item, model

def source_of(item):
    for n in ('source.png', 'source.jpg', 'source.jpeg', 'source.webp'):
        if (item / n).exists(): return Image.open(item / n).convert('RGB')

def font(sz):
    for f in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 'C:/Windows/Fonts/arialbd.ttf'):
        try: return ImageFont.truetype(f, sz)
        except Exception: pass
    return ImageFont.load_default()

def sheet(tiles, labels, cols, cell=420, title=None):
    rows = (len(tiles) + cols - 1) // cols; top = 46 if title else 0
    out = Image.new('RGB', (cols * cell, rows * (cell + 30) + top), (245, 245, 245)); d = ImageDraw.Draw(out)
    if title: d.text((12, 10), title, fill=(30, 30, 30), font=font(24))
    for i, (t, l) in enumerate(zip(tiles, labels)):
        t = t.copy(); t.thumbnail((cell - 12, cell - 12))
        x = (i % cols) * cell; y = top + (i // cols) * (cell + 30)
        out.paste(t, (x + (cell - t.width) // 2, y + 6 + (cell - 12 - t.height) // 2))
        d.text((x + 10, y + cell + 2), l, fill=(60, 60, 60), font=font(18))
    return out

def turn_views(model, charts, tex=None, yaws=(35, 125, 215, 305), pitch=22, size=640):
    tiles = []
    for yw in yaws:
        vs = fit_views({'views': [{'yaw': yw, 'pitch': pitch}]}, charts, size, size, 0.82)
        tiles.append(render(charts, vs, size, size, tex=tex, ss=2, edges=tex is None))
    return tiles

def cmd_clay(item):
    item, model = load(item); charts = build_charts(model)
    tiles = turn_views(model, charts); labels = ['front + right side', 'back + right side', 'back + left side', 'front + left side']
    src = source_of(item)
    if src: tiles = [src] + tiles; labels = ['source'] + labels
    sheet(tiles, labels, 5 if src else 4, title=f"{model.get('name', item.name)}: {sum(1 for p in model['parts'])} parts, {len(mesh(charts)[0])} triangles").save(item / 'clay.png')
    print('wrote', item / 'clay.png')

PROMPT = """Image 1 is a reference of a simple low-poly 3D model made of grey blocks, shown twice on a white background: the front on the left and the back on the right (the same {what} turned around). Image 2 is the real {what}: {desc}.

Paint the grey blocks in image 1 so the model looks like the {what} in image 2: its colours, materials, stitching, seams, pockets, details and patterns, painted straight onto each flat face as a realistic, photo-scanned texture: real material grain (canvas weave, leather, suede, metal, plastic, glass), real colours, stitching and light wear, the way a photo of the real thing would look, not cartoon or hand-painted. Keep the lighting soft and even, with no strong highlights or cast shadows.

Rules:
- Keep every block exactly where it is, the same size and shape, with the same two camera angles. Do not move, add, remove, round off or bend anything, and do not add shadows on the background.
- Paint every face you can see on both views, including the thin straps, edges and tops. Make the back view show what the back of this {what} would look like.
- Keep the plain white background and keep both views the same size as in image 1.
- No text, letters or brand logos."""

def cmd_ref(item):
    item, model = load(item); charts = build_charts(model)
    vs = fit_views(model, charts, REF_W, REF_H)
    render(charts, vs, REF_W, REF_H, ss=2).save(item / 'reference.png')
    what = model.get('object') or model.get('name', 'object')
    desc = model.get('description') or what
    (item / 'prompt.txt').write_text(PROMPT.format(what=what, desc=desc) + ('\n\nExtra notes: ' + model['prompt_notes'] if model.get('prompt_notes') else '') + '\n')
    print('wrote', item / 'reference.png', 'and prompt.txt')

def lighting(model, charts, S, size, albedo, L, maps_only=False):
    """Every light map at the texture size: AO, room, light nodes, glow, surface detail (normal map) and the
    path-traced bounce (unless the model asks for "quality": "fast" or bounce is 0)."""
    lt = model.get('light', {})
    small = light_maps(model, charts, S, int(lt.get('res', LIGHT_RES)))
    def up(a):
        if a.ndim == 3: return np.stack([up(a[..., c]) for c in range(a.shape[2])], -1)
        return np.asarray(Image.fromarray(a.astype(np.float32)).resize((size, size), Image.BILINEAR))
    maps = {k: up(v) for k, v in small.items()}
    nmap = normal_atlas(model, charts, S, size); maps['detail'] = detail_shade(nmap); maps['_nmap'] = nmap
    if L.get('bounce', 0) > 0 and lt.get('quality') != 'fast':
        hs = BOUNCE_RES
        direct = np.clip(composite(np.full((size, size, 3), 255.0), dict(maps, bounce=np.zeros_like(maps['lights'])), dict(L, bounce=0)) / 255, 0, 2)
        small_alb = np.asarray(Image.fromarray(albedo.astype(np.uint8)).resize((hs, hs), Image.BOX), np.float64)
        small_dir = np.asarray(Image.fromarray((direct.clip(0, 1) * 255).astype(np.uint8)).resize((hs, hs), Image.BOX), np.float64) / 255
        maps['bounce'] = up(bounce_map(model, charts, S, hs, small_alb, small_dir))
    return maps

def look_of(model, charts, S, fx, L, albedo):
    """What the 3D preview page and the Studio need to re-make the texture live."""
    oc = outline_cfg(model); w = wear_of(model, charts)
    out = {'light': L, 'fx': fx_of(fx), 'outline': dict(oc or OUTLINE_DEFAULT, on=oc is not None),
           'nodes': light_nodes(model), 'grid': grid_data(model, charts, S, LIVE_RES),
           'groups': group_info(model, charts, S, albedo), 'gmap': group_rects(charts, S)}
    if w: out['wear'] = w
    return out

def cmd_bake(item):
    item, model = load(item); charts = build_charts(model)
    painted_p = next((item / n for n in ('painted.png', 'painted.jpg', 'painted.webp') if (item / n).exists()), None)
    if not painted_p: raise SystemExit('Put the image model\'s result in ' + str(item / 'painted.png'))
    painted = np.asarray(Image.open(painted_p).convert('RGB'))
    tx = model.get('texture', {}); S = int(tx.get('atlas', 1024)); size = int(tx.get('size', 1024))
    density = model['_density']
    vs = fit_views(model, charts, REF_W, REF_H)
    atlas, al, report = bake(model, charts, vs, painted, S, tx)
    out = item / 'out'; out.mkdir(exist_ok=True)
    Image.fromarray(atlas.astype(np.uint8)).save(out / 'texture_full.png')
    fx = tx.get('fx', {})
    L = light_of(model)
    plain = np.asarray(Image.fromarray(atlas.astype(np.uint8)).resize((size, size), Image.BOX), np.float64)  # the painted colours
    colour = quantise(grade(atlas, size, fx), fx).astype(np.float64)   # the retro look is on the colour only
    maps = lighting(model, charts, S, size, plain, L)                   # the light stays crisp at the full size
    lit = composite(colour, maps, L)
    overlay = logo_overlay(size, logo_chart(model, charts), S, model['_mean_colour'])
    final = np.where(overlay[..., 3:] > 0, overlay[..., :3], lit).astype(np.uint8)
    albedo = plain; nmap = maps['_nmap']
    md = out / 'maps'; md.mkdir(exist_ok=True)
    Image.fromarray(albedo.astype(np.uint8)).save(md / 'albedo.png')
    Image.fromarray((np.clip(maps['ao'], 0, 1) * 255).astype(np.uint8)).save(md / 'ao.png')
    Image.fromarray((np.clip(maps['room'], 0, 1) * 255).astype(np.uint8)).save(md / 'room.png')
    Image.fromarray((np.clip(maps['lights'] / 2, 0, 1) * 255).astype(np.uint8)).save(md / 'lights.png')
    Image.fromarray((np.clip(maps['emit'] / 2, 0, 1) * 255).astype(np.uint8)).save(md / 'emit.png')
    Image.fromarray(overlay, 'RGBA').save(md / 'logo.png')
    Image.fromarray(normal_png(nmap)).save(out / 'normal.png'); Image.fromarray(normal_png(nmap)).save(md / 'normal.png')
    Image.fromarray((np.clip(maps['detail'] / 2, 0, 1) * 255).astype(np.uint8)).save(md / 'detail.png')
    if 'bounce' in maps: Image.fromarray((np.clip(maps['bounce'] / 2, 0, 1) * 255).astype(np.uint8)).save(md / 'bounce.png')
    oc = outline_cfg(model)
    look = look_of(model, charts, S, fx, L, albedo)
    Image.fromarray(final).save(out / 'texture.png')
    b = io.BytesIO(); Image.fromarray(final).save(b, 'PNG'); png = b.getvalue()
    pos, uv, cid, nrm = mesh(charts)
    scale = float(model.get('export_scale', 1.0)); name = model.get('name', item.name)
    ol = outline_of(model, pos)
    nb = io.BytesIO(); Image.fromarray(normal_png(nmap)).save(nb, 'PNG')
    export_obj(out / 'model.obj', name, pos, uv, nrm, S, scale, ol)
    export_glb(out / 'model.glb', name, pos, uv, nrm, S, png, scale, nb.getvalue(), ol)
    export_preview(out / 'preview.html', name, pos, uv, nrm, S, png, md, look)
    # check pictures
    big = np.asarray(Image.fromarray(final).resize((S, S), Image.NEAREST))
    rend = render(charts, vs, REF_W, REF_H, tex=big, ss=1, edges=False)
    ref = Image.open(item / 'reference.png') if (item / 'reference.png').exists() else render(charts, vs, REF_W, REF_H, ss=2)
    sheet([ref, Image.fromarray(painted), rend], ['reference', 'painted (image model)', 'baked model, same cameras'], 1, cell=900,
          title=f"{name}: match " + ', '.join('%.1f%%' % (a['iou'] * 100) for a in al)).save(out / 'check.png')
    tiles = turn_views(model, charts, tex=big); src = source_of(item)
    sheet(([src] if src else []) + tiles, (['source'] if src else []) + ['front + right side', 'back + right side', 'back + left side', 'front + left side'], 5 if src else 4,
          title=f'{name}: {len(pos)} triangles, {size}x{size} texture').save(out / 'turntable.png')
    low = [n for n, c in report if c < 0.35]
    rep = {'name': name, 'triangles': int(len(pos)), 'texture': size, 'unshade': round(float(tx.get('_unshade', 0)), 3), 'atlas_density_px_per_unit': round(density, 2),
           'silhouette_match': [round(a['iou'], 4) for a in al], 'filled_from_elsewhere': low,
           'coverage': {n: round(c, 3) for n, c in report}}
    (out / 'report.json').write_text(json.dumps(rep, indent=1))
    print(json.dumps({k: rep[k] for k in ('triangles', 'silhouette_match', 'filled_from_elsewhere')}))
    print('wrote', out)

AVATAR_COLOURS = {'torso': (52, 142, 64), 'larm': (245, 205, 48), 'rarm': (245, 205, 48), 'lleg': (13, 105, 172), 'rleg': (13, 105, 172),
                  'head': (245, 205, 48), 'face': (30, 30, 30)}

def cmd_worn(items, dest=None):
    """The blocky avatar wearing one or more accessories, from the front, the side and the back (out/worn.png)."""
    man = mannequin(); layout(man, 512, 2); mp, muv, mcid, mn = mesh(man)
    P, UV, CID, N, COL = [mp], [muv * 0], [mcid], [mn], [np.array([AVATAR_COLOURS[man[c].part] for c in mcid], np.float64)]
    texs = []; k0 = len(man); names = []
    for i, it in enumerate(items):
        it, model = load(it); charts = build_charts(model); w = worn_mesh(model, charts)
        if w is None: raise SystemExit(f'{it.name}: add "wear" to model.json first (see MODEL_FORMAT.md)')
        pos, uv, cid, nrm = w; S = int(model.get('texture', {}).get('atlas', 1024))
        tp = it / 'out' / 'texture.png'
        tex = np.asarray(Image.open(tp).convert('RGB').resize((1024, 1024), Image.NEAREST)) if tp.exists() else np.full((1024, 1024, 3), 200, np.uint8)
        texs.append(tex); u = uv / S * 1024; u[..., 1] += 1024 * i
        P.append(pos); UV.append(u); CID.append(cid + k0); N.append(nrm); COL.append(-np.ones((len(pos), 3))); k0 += len(charts); names.append(model.get('name', it.name))
    pos, uv, cid, nrm, col = (np.concatenate(a) for a in (P, UV, CID, N, COL))
    tex = np.concatenate(texs); tiles = []
    for yaw in (25, 115, 205, 295):
        vs = [dict(yaw=yaw, pitch=12, basis=view_basis(yaw, 12))]; r, u, f = vs[0]['basis']; Q = pos.reshape(-1, 3)
        X = np.stack([Q @ r, -(Q @ u)], 1); sc = 0.86 * 700 / max(np.ptp(X[:, 0]), np.ptp(X[:, 1])); mid = (X.max(0) + X.min(0)) / 2
        vs[0].update(scale=sc, ox=350 - mid[0] * sc, oy=350 - mid[1] * sc)
        tiles.append(render_mesh(pos, uv, cid, nrm, None, vs, 700, 700, tex=tex, ss=2, edges=False, colour=col, bg=np.array([236.0, 236, 240])))
    dest = pathlib.Path(dest) if dest else pathlib.Path(items[0]) / 'out' / 'worn.png'; dest.parent.mkdir(parents=True, exist_ok=True)
    sheet(tiles, ['front', 'left side', 'back', 'right side'], 4, cell=520, title='Worn: ' + ', '.join(names)).save(dest)
    print('wrote', dest)

def cmd_template(item, dest):
    """Everything the Clothing Studio's Accessories section needs to paint variants of this model in the browser.
    The model is laid out at 1024 like the bake; the painting map (texmap.bin) is at half that (512), which lines up
    exactly because every chart has an even size and position. Light and normal maps are at the full 1024."""
    import zlib
    item, model = load(item); dest = pathlib.Path(dest); slug = item.name; od = dest / slug; od.mkdir(parents=True, exist_ok=True)
    tx = model.setdefault('texture', {}); S = int(tx.get('atlas', 1024)); size = int(tx.get('size', 1024)); h2 = S // 2
    charts = build_charts(model)
    vs = fit_views(model, charts, REF_W, REF_H); W, H = REF_W, REF_H
    refbuf = buffers(charts, vs, W, H)
    cid = -np.ones((h2, h2), np.int16); XY = np.zeros((len(vs), h2, h2, 2), np.uint16); WT = np.zeros((len(vs), h2, h2), np.uint8); SH = np.zeros((len(vs), h2, h2), np.uint8)
    for k, ch in enumerate(charts):
        X, Nn = chart_texels(ch); X = (X[0::2, 0::2] + X[1::2, 1::2]) / 2; Nn = Nn[0::2, 0::2]
        ys, xs = slice(ch.y0 // 2, (ch.y0 + ch.h) // 2), slice(ch.x0 // 2, (ch.x0 + ch.w) // 2)
        cid[ys, xs] = k
        for i, v in enumerate(vs):
            p = project(v, X + (ch.explode if i == 1 else 0), i); d, cb = refbuf[i]
            px = np.clip(p[..., 0].astype(int), 0, W - 1); py = np.clip(p[..., 1].astype(int), 0, H - 1)
            vis = (cb[py, px] == k) & (np.abs(d[py, px] - p[..., 2]) < 2.5 / v['scale'])
            core = vis.copy()
            for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2)):
                core &= cb[np.clip(py + dy, 0, H - 1), np.clip(px + dx, 0, W - 1)] == k
            use = np.where(core.any(), core, vis); facing = -(Nn @ v['basis'][2]); use &= facing > 0.05
            XY[i, ys, xs, 0] = np.clip(p[..., 0] * 16, 0, 65535).astype(np.uint16); XY[i, ys, xs, 1] = np.clip(p[..., 1] * 16, 0, 65535).astype(np.uint16)
            WT[i, ys, xs] = np.where(use, np.clip(facing, 0, 1) * 255, 0).astype(np.uint8)
            SH[i, ys, xs] = (np.clip(shade_of(Nn, v), 0, 1) * 255).astype(np.uint8)
    blob = cid.astype('<i2').tobytes() + b''.join(XY[i, ..., c].astype('<u2').tobytes() for i in range(len(vs)) for c in (0, 1)) + WT.tobytes() + SH.tobytes()
    (od / 'texmap.bin').write_bytes(zlib.compress(blob, 9))
    # the example: the finished item's own painted colours and bounce light, so it can be worn without baking
    md = item / 'out' / 'maps'
    albedo = np.asarray(Image.open(md / 'albedo.png').convert('RGB'), np.float64) if (md / 'albedo.png').exists() else np.full((size, size, 3), 160.0)
    L = light_of(model); fx = tx.get('fx', {})
    maps = lighting(dict(model, light=dict(model.get('light', {}), quality='fast')), charts, S, size, albedo, dict(L, bounce=0))
    nmap = maps['_nmap']
    sv = lambda a, f: Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8)).save(od / f)
    sv(maps['ao'], 'ao.png'); sv(maps['room'], 'room.png'); sv(maps['emit'] / 2, 'emit.png'); sv(maps['detail'] / 2, 'detail.png')
    Image.fromarray(normal_png(nmap)).save(od / 'normal.png')
    for f in ('albedo', 'bounce'):   # smooth colour maps: JPEG keeps the download small
        if (md / (f + '.png')).exists(): Image.open(md / (f + '.png')).convert('RGB').save(od / f'example-{f}.jpg', quality=90)
    if (md / 'logo.png').exists(): (od / 'example-logo.png').write_bytes((md / 'logo.png').read_bytes())
    render(charts, vs, REF_W, REF_H, ss=2).save(od / 'reference.png')
    painted = next((item / n for n in ('painted.png', 'painted.jpg', 'painted.webp') if (item / n).exists()), None)
    if painted:
        im = Image.open(painted).convert('RGB'); im.thumbnail((1600, 1600)); im.save(od / 'example.jpg', quality=88)
    if (item / 'out' / 'texture.png').exists():  # a picture for the template card: the finished example from the front
        tex = np.asarray(Image.open(item / 'out' / 'texture.png').convert('RGB').resize((S, S), Image.NEAREST))
        v2 = fit_views({'views': [{'yaw': 30, 'pitch': 20}]}, charts, 360, 360, 0.86)
        render(charts, v2, 360, 360, tex=tex, ss=2, edges=False, bg=np.array([35.0, 35, 39])).save(od / 'thumb.png')
    pos, uv, cidm, nrm = mesh(charts)
    pd = preview_data(model.get('name', slug), pos, uv, nrm, S, b'')
    names = {c.name: i for i, c in enumerate(charts)}
    opp = [names.get(f'{c.part}.{c.opposite}', -1) if c.opposite else -1 for c in charts]
    lc = logo_chart(model, charts)
    look = look_of(model, charts, S, fx, L, albedo)
    tpl = {'slug': slug, 'name': model.get('name', slug), 'object': model.get('object', slug), 'description': model.get('description', ''),
           'ref': [W, H], 'views': len(vs), 'atlas': h2, 'layout': S, 'size': size, 'shadeRef': SHADE_REF,
           'charts': [{'x': c.x0 // 2, 'y': c.y0 // 2, 'w': c.w // 2, 'h': c.h // 2, 'part': c.part, 'side': c.side, 'group': c.gi, 'opp': opp[i], 'flip': c.flip} for i, c in enumerate(charts)],
           'groups': model['_groups'], 'logo': charts.index(lc) if lc is not None else -1,
           'mesh': dict({k: pd[k] for k in ('pos', 'nrm', 'uv', 'tan', 'radius')}, centre=((pos.reshape(-1, 3).max(0) + pos.reshape(-1, 3).min(0)) / 2).tolist()),
           'look': look, 'example': (od / 'example.jpg').exists(), 'exampleMaps': (od / 'example-albedo.jpg').exists()}
    (od / 'template.json').write_text(json.dumps(tpl, separators=(',', ':')))
    (od / 'model.json').write_text((item / 'model.json').read_text())   # for AccessoryStudio.example(): a finished model to learn from
    idx_p = dest / 'index.json'; idx = json.loads(idx_p.read_text()) if idx_p.exists() else []
    ent = {'slug': slug, 'name': tpl['name'], 'object': tpl['object'], 'description': tpl['description']}
    if 'wear' in look: ent['wear'] = look['wear']['on']
    idx = [t for t in idx if t['slug'] != slug] + [ent]
    idx_p.write_text(json.dumps(sorted(idx, key=lambda t: t['name']), indent=1))
    print('wrote', od, sum(f.stat().st_size for f in od.iterdir()) // 1024, 'KB')

if __name__ == '__main__':
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    c, it = sys.argv[1], sys.argv[2]
    if c == 'clay': cmd_clay(it)
    elif c == 'ref': cmd_ref(it)
    elif c == 'bake': cmd_bake(it)
    elif c == 'template': cmd_template(it, sys.argv[3] if len(sys.argv) > 3 else 'templates')
    elif c == 'worn':  # lopol.py worn items/a [items/b ...] [--out file.png]
        a = sys.argv[2:]; o = None
        if '--out' in a: i = a.index('--out'); o = a[i + 1]; a = a[:i] + a[i + 2:]
        cmd_worn(a, o)
    elif c == 'all':
        cmd_clay(it); cmd_ref(it)
        if any((pathlib.Path(it) / n).exists() for n in ('painted.png', 'painted.jpg', 'painted.webp')): cmd_bake(it)
    else: print(__doc__); sys.exit(1)
