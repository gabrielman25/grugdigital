/* Image2LoPol 3D viewer + live re-lighting. Used by the per-model preview page and by the Clothing Studio's
   Accessories section. LoPolView(root, D) builds everything inside `root` (a positioned element).
   D: { name, pos, nrm, uv, tan (base64 Float32), radius, tex (data URL of the finished texture),
        maps: { albedo, ao, room, lights, emit, logo, detail, normal, bounce? } (data URLs),
        look: { light:{ao,room,lights,detail,bounce}, fx:{bits,dither,palette}, nodes:[{pos,color,strength,range}],
                grid:{res,mask,P,N,blockers,eps,centre}, outline:{on,width,color} } }
   Everything a slider changes is re-baked into the texture on the CPU with the same maths as tool/lopol.py. */
(function () {
'use strict';
const f32 = s => { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return new Float32Array(u.buffer); };
const u8 = s => { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
const hex = c => '#' + c.map(v => Math.round(v).toString(16).padStart(2, '0')).join('');
const unhex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
const loadImg = src => new Promise((r, j) => { const i = new Image(); i.onload = () => r(i); i.onerror = j; i.src = src; });
const pixels = (im, n) => { const c = document.createElement('canvas'); c.width = c.height = n; const x = c.getContext('2d'); x.drawImage(im, 0, 0, n, n); return x.getImageData(0, 0, n, n).data; };
const BAY = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

/* ---------- ray tests against the model's own triangles (flat Float32 array of 9 per triangle) ---------- */
function anyHit(ox, oy, oz, dx, dy, dz, tmax, T, eps){
  for (let i = 0; i < T.length; i += 9) {
    const ax = T[i], ay = T[i+1], az = T[i+2], e1x = T[i+3]-ax, e1y = T[i+4]-ay, e1z = T[i+5]-az, e2x = T[i+6]-ax, e2y = T[i+7]-ay, e2z = T[i+8]-az;
    const px = dy*e2z - dz*e2y, py = dz*e2x - dx*e2z, pz = dx*e2y - dy*e2x, det = e1x*px + e1y*py + e1z*pz;
    if (det > -1e-12 && det < 1e-12) continue;
    const inv = 1 / det, sx = ox-ax, sy = oy-ay, sz = oz-az, u = (sx*px + sy*py + sz*pz) * inv; if (u < 0 || u > 1) continue;
    const qx = sy*e1z - sz*e1y, qy = sz*e1x - sx*e1z, qz = sx*e1y - sy*e1x, v = (dx*qx + dy*qy + dz*qz) * inv; if (v < 0 || u + v > 1) continue;
    const t = (e2x*qx + e2y*qy + e2z*qz) * inv; if (t > eps && t < tmax) return true;
  }
  return false;
}
function nearest(ox, oy, oz, dx, dy, dz, T, eps, out){
  let best = Infinity, bi = -1, bu = 0, bv = 0;
  for (let i = 0, k = 0; i < T.length; i += 9, k++) {
    const ax = T[i], ay = T[i+1], az = T[i+2], e1x = T[i+3]-ax, e1y = T[i+4]-ay, e1z = T[i+5]-az, e2x = T[i+6]-ax, e2y = T[i+7]-ay, e2z = T[i+8]-az;
    const px = dy*e2z - dz*e2y, py = dz*e2x - dx*e2z, pz = dx*e2y - dy*e2x, det = e1x*px + e1y*py + e1z*pz;
    if (det > -1e-12 && det < 1e-12) continue;
    const inv = 1 / det, sx = ox-ax, sy = oy-ay, sz = oz-az, u = (sx*px + sy*py + sz*pz) * inv; if (u < 0 || u > 1) continue;
    const qx = sy*e1z - sz*e1y, qy = sz*e1x - sx*e1z, qz = sx*e1y - sy*e1x, v = (dx*qx + dy*qy + dz*qz) * inv; if (v < 0 || u + v > 1) continue;
    const t = (e2x*qx + e2y*qy + e2z*qz) * inv; if (t > eps && t < best) { best = t; bi = k; bu = u; bv = v; }
  }
  out[0] = bi; out[1] = bu; out[2] = bv; return bi;
}
/* fill the empty grid cells next to used ones (4 passes), like the Python bake */
function spread(m, maps, r){
  const f = m.slice();
  for (let it = 0; it < 4; it++) {
    const nf = f.slice();
    for (let y = 0; y < r; y++) for (let x = 0; x < r; x++) {
      const i = y*r + x; if (f[i]) continue; let c = 0; const nb = [];
      for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) { const xx = (x - dx + r) % r, yy = (y - dy + r) % r, j = yy*r + xx; if (f[j]) { c++; nb.push(j); } }
      if (!c) continue; nf[i] = 1;
      for (const mp of maps) for (let k = 0; k < 3; k++) { let s = 0; for (const j of nb) s += mp[j*3+k]; mp[i*3+k] = s / c; }
    }
    f.set(nf);
  }
}
/* bilinear upsample r -> n (pixel centres, edges clamped: same as Pillow) of a 3-channel float map */
function upsample(src, r, n){
  const out = new Float32Array(n*n*3), k = r / n;
  for (let y = 0; y < n; y++) { let sy = (y + .5) * k - .5; sy = Math.max(0, Math.min(r - 1, sy)); const y0 = Math.floor(sy), y1 = Math.min(r - 1, y0 + 1), fy = sy - y0;
    for (let x = 0; x < n; x++) { let sx = (x + .5) * k - .5; sx = Math.max(0, Math.min(r - 1, sx)); const x0 = Math.floor(sx), x1 = Math.min(r - 1, x0 + 1), fx = sx - x0;
      for (let c = 0; c < 3; c++) { const a = src[(y0*r+x0)*3+c], b = src[(y0*r+x1)*3+c], d = src[(y1*r+x0)*3+c], e = src[(y1*r+x1)*3+c];
        out[(y*n+x)*3+c] = (a*(1-fx) + b*fx)*(1-fy) + (d*(1-fx) + e*fx)*fy; } } }
  return out;
}

/* ---------- tiny store-only zip ---------- */
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function zip(files){
  const parts = [], dir = []; let off = 0;
  for (const f of files) {
    const name = new TextEncoder().encode(f.name), data = f.data; let c = 0xFFFFFFFF; for (let i = 0; i < data.length; i++) c = CRC[(c ^ data[i]) & 255] ^ (c >>> 8); c = (c ^ 0xFFFFFFFF) >>> 0;
    const h = new DataView(new ArrayBuffer(30)); h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint32(14, c, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, name.length, true);
    parts.push(new Uint8Array(h.buffer), name, data);
    const d = new DataView(new ArrayBuffer(46)); d.setUint32(0, 0x02014b50, true); d.setUint16(4, 20, true); d.setUint16(6, 20, true); d.setUint32(16, c, true); d.setUint32(20, data.length, true); d.setUint32(24, data.length, true); d.setUint16(28, name.length, true); d.setUint32(42, off, true);
    dir.push(new Uint8Array(d.buffer), name); off += 30 + name.length + data.length;
  }
  const dsz = dir.reduce((s, a) => s + a.length, 0), e = new DataView(new ArrayBuffer(22)); e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, dsz, true); e.setUint32(16, off, true);
  return new Blob([...parts, ...dir, new Uint8Array(e.buffer)], { type: 'application/zip' });
}

const CSS = `
.lpv{position:absolute;inset:0;overflow:hidden;color:#ECECEF;font:600 13px/1.3 var(--g-font, system-ui,-apple-system,'Segoe UI',sans-serif)}
.lpv canvas.v{position:absolute;inset:0;width:100%;height:100%;cursor:grab;touch-action:none}
.lpv canvas.v.lo{image-rendering:pixelated}
.lpv .bar{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);display:flex;gap:3px;background:#232327;padding:4px;border-radius:12px;flex-wrap:wrap;justify-content:center;max-width:calc(100% - 20px)}
.lpv button{all:unset;cursor:pointer;padding:6px 10px;border-radius:9px;color:#C9C9CF;font-size:12px}
.lpv button.on{background:#9BE338;color:#1F1A17}
.lpv button[hidden],.lpv [hidden]{display:none!important}
.lpv button:focus-visible{outline:2px solid #9BE338}
.lpv .side{position:absolute;right:10px;top:10px;bottom:62px;width:228px;background:#232327;border-radius:12px;padding:10px 12px;display:flex;flex-direction:column;gap:7px;overflow:auto}
.lpv .side h4{margin:4px 0 0;font-size:12px;color:#C9C9CF;display:flex;justify-content:space-between;align-items:center}
.lpv .side label{display:flex;flex-direction:column;gap:2px;font-size:11px;color:#9A9AA3;font-weight:500}
.lpv .lb{display:flex;justify-content:space-between;gap:6px}
.lpv .val{color:#ECECEF;font-weight:600;font-variant-numeric:tabular-nums}
.lpv .side input[type=range]{width:100%;accent-color:#9BE338;margin:0}
.lpv .row{display:flex;gap:5px;align-items:center}
.lpv .act{background:#9BE338;color:#1F1A17;text-align:center;flex:1;padding:6px 4px}
.lpv .ghost{background:#2C2C32;text-align:center;flex:1;padding:6px 4px}
.lpv .node{background:#1A1A1E;border-radius:9px;padding:6px 7px;display:flex;flex-direction:column;gap:3px}
.lpv .node .row input[type=color]{width:26px;height:22px;border:0;padding:0;background:none;cursor:pointer}
.lpv .node .x{padding:2px 7px;color:#9A9AA3}
.lpv .msg{font-size:11px;color:#9A9AA3;font-weight:500;min-height:14px}
@media (max-width:700px){ .lpv .side{top:auto;bottom:62px;height:44%;left:10px;right:10px;width:auto} }`;


/* ---------- the texture, shared by the viewer, the Studio's Outfits and the page API ----------
   T = { n, A, AO, RM, EM, LG, DT: RGBA Uint8 maps (n x n), BO: bounce Float32 (n*n*3) or null, LI: light nodes Float32 or null,
         GM: group index per texel (255 = none) or null, means: average colour per group }
   s = { fx:{bits,dither,pixel,contrast,sat,bright}, light:{ao,room,lights,detail,bounce}, colours:[null | {rgb:[r,g,b], amount}] }
   Order: recolour -> contrast / saturation / brightness -> bigger pixels + colour depth + dither (the colour only)
          -> x crisp full-size lighting (AO, room, surface detail, light nodes, bounce) -> glow -> logo. Same as tool/lopol.py. */
const FX_DEFAULT = { bits: 4, dither: 1, pixel: 2, contrast: .5, sat: 0, bright: 0 };
const LIGHT_DEFAULT = { ao: 1, room: .6, lights: 1, detail: .32, bounce: 1.05 };
function groupMap(gmap, n){
  if (!gmap || !gmap.length) return null; const G = new Uint8Array(n*n).fill(255);
  for (const [x, y, w, h, g] of gmap) { const x0 = Math.max(0, Math.floor(x*n)), y0 = Math.max(0, Math.floor(y*n)), x1 = Math.min(n, Math.ceil((x + w)*n)), y1 = Math.min(n, Math.ceil((y + h)*n));
    for (let yy = y0; yy < y1; yy++) G.fill(g, yy*n + x0, yy*n + x1); }
  return G;
}
function groupMeans(T, count){
  const acc = Array.from({ length: count }, () => [0, 0, 0, 0]), { A, GM, n } = T;
  if (GM) for (let i = 0; i < n*n; i++) { const g = GM[i]; if (g === 255 || g >= count) continue; const a = acc[g]; a[0] += A[i*4]; a[1] += A[i*4+1]; a[2] += A[i*4+2]; a[3]++; }
  return acc.map(a => a[3] ? [a[0]/a[3], a[1]/a[3], a[2]/a[3]] : [128, 128, 128]);
}
function compose(T, s, img){
  const { n, A, AO, RM, EM, LG, DT, BO, LI, GM } = T, fx = Object.assign({}, FX_DEFAULT, s.fx), L = Object.assign({}, LIGHT_DEFAULT, s.light), cols = s.colours || [];
  const od = img.data, bits = Math.round(fx.bits), q = 255 / (Math.pow(2, bits) - 1), dz = fx.dither, px = Math.max(1, Math.round(fx.pixel));
  if (!T.COL || T.COL.length !== n*n*3) T.COL = new Float32Array(n*n*3);
  const C = T.COL, lum = (r, g, b) => r*.299 + g*.587 + b*.114;
  const rec = cols.map((c, g) => c && c.rgb ? { t: c.rgb, a: c.amount ?? 1, m: Math.max(8, lum(...T.means[g])) } : null);
  for (let i = 0; i < n*n; i++) { const p4 = i*4; let r = A[p4], g = A[p4+1], b = A[p4+2];
    const rc = GM && GM[i] !== 255 ? rec[GM[i]] : null;
    if (rc) { const k = lum(r, g, b) / rc.m; r += (rc.t[0]*k - r) * rc.a; g += (rc.t[1]*k - g) * rc.a; b += (rc.t[2]*k - b) * rc.a; }
    if (fx.contrast) { r = (r - 128) * (1 + fx.contrast) + 128; g = (g - 128) * (1 + fx.contrast) + 128; b = (b - 128) * (1 + fx.contrast) + 128; }
    if (fx.sat) { const m = (r + g + b) / 3; r = m + (r - m) * (1 + fx.sat); g = m + (g - m) * (1 + fx.sat); b = m + (b - m) * (1 + fx.sat); }
    if (fx.bright) { r += fx.bright * 255; g += fx.bright * 255; b += fx.bright * 255; }
    C[i*3] = Math.min(255, Math.max(0, r)); C[i*3+1] = Math.min(255, Math.max(0, g)); C[i*3+2] = Math.min(255, Math.max(0, b)); }
  // bigger texture pixels (one colour and one dither cell per block), colour depth with ordered dithering
  for (let by = 0; by < n; by += px) for (let bx = 0; bx < n; bx += px) {
    let r = 0, g = 0, b = 0, cnt = 0; const ye = Math.min(n, by + px), xe = Math.min(n, bx + px);
    for (let y = by; y < ye; y++) for (let x = bx; x < xe; x++) { const i = (y*n + x)*3; r += C[i]; g += C[i+1]; b += C[i+2]; cnt++; }
    const d = ((BAY[((by / px) & 3)*4 + ((bx / px) & 3)] + .5) / 16 - .5) * dz * q;
    const qz = v => { v /= cnt; if (bits < 8) v = Math.round(Math.min(255, Math.max(0, v + d)) / q) * q; return Math.min(255, Math.max(0, v)); };
    r = qz(r); g = qz(g); b = qz(b);
    for (let y = by; y < ye; y++) for (let x = bx; x < xe; x++) { const p4 = (y*n + x)*4; od[p4] = r; od[p4+1] = g; od[p4+2] = b; od[p4+3] = 255; } }
  // the light, crisp at the full size, multiplied in after the retro look
  for (let i = 0; i < n*n; i++) { const p4 = i*4, e0 = EM[p4]/255*2, e1 = EM[p4+1]/255*2, e2 = EM[p4+2]/255*2, mx = Math.max(e0, e1, e2);
    if (mx > .01) { const tg = Math.min(.7, Math.max(0, .45 * L.lights * mx)) * lum(od[p4], od[p4+1], od[p4+2]) / 255;
      od[p4] = od[p4] * (1 - tg) + e0 / mx * 255 * tg; od[p4+1] = od[p4+1] * (1 - tg) + e1 / mx * 255 * tg; od[p4+2] = od[p4+2] * (1 - tg) + e2 / mx * 255 * tg; continue; }
    const sh = (1 - L.ao + L.ao * AO[p4]/255) * ((1 - .45*L.room) + .9*L.room * RM[p4]/255) * (1 + L.detail * (DT[p4]/255*2 - 1));
    for (let k = 0; k < 3; k++) od[p4+k] = Math.min(255, od[p4+k] * (sh + L.lights * (LI ? LI[i*3+k] : 0) + L.bounce * (BO ? BO[i*3+k] : 0))); }
  if (LG) for (let i = 0; i < n*n; i++) { const p4 = i*4; if (LG[p4+3] > 0) { od[p4] = LG[p4]; od[p4+1] = LG[p4+1]; od[p4+2] = LG[p4+2]; } }
  return img;
}
/* one bounce of path-traced light off the model's own surfaces plus a soft sky, on the live grid; calls back with the map */
function trace(T, grid, pos, uv, L, onStep, done){
  const r = grid.r, { m, P, N, eps } = grid, n = T.n, S = new Float32Array(r*r*3), hit = [0, 0, 0], RAYS = 40; let i = 0;
  const src = T.COL || null, A = T.A, AO = T.AO, RM = T.RM, EM = T.EM, LI = T.LI;
  const white = (u, v) => { const x = Math.min(n - 1, Math.max(0, Math.floor(u*n))), y = Math.min(n - 1, Math.max(0, Math.floor(v*n))), j = y*n + x, p4 = j*4;
    const e = EM[p4] + EM[p4+1] + EM[p4+2] > 3, sh = (1 - L.ao + L.ao*AO[p4]/255) * ((1 - .45*L.room) + .9*L.room*RM[p4]/255);
    return [0, 1, 2].map(c => { const al = (src ? src[j*3+c] : A[p4+c]) / 255; return e ? Math.min(1.5, EM[p4+c]/255*2 + al*.3) : al * Math.min(1, sh + L.lights * (LI ? LI[j*3+c] : 0)); }); };
  let seedr = 7; const rnd = () => (seedr = Math.imul(seedr ^ (seedr >>> 15), 2246822507) + 0x9e3779b9 >>> 0) / 4294967296;
  let stopped = false;
  const step = () => {
    if (stopped) return; const t0 = performance.now();
    for (; i < r*r && performance.now() - t0 < 30; i++) { if (!m[i]) continue;
      const nx = N[i*3], ny = N[i*3+1], nz = N[i*3+2], ox = P[i*3] + nx*eps, oy = P[i*3+1] + ny*eps, oz = P[i*3+2] + nz*eps;
      const ax = Math.abs(ny) < .9 ? [0, 1, 0] : [1, 0, 0]; let tx = ax[1]*nz - ax[2]*ny, ty = ax[2]*nx - ax[0]*nz, tz = ax[0]*ny - ax[1]*nx; const tl = Math.hypot(tx, ty, tz); tx /= tl; ty /= tl; tz /= tl;
      const bx = ny*tz - nz*ty, by = nz*tx - nx*tz, bz = nx*ty - ny*tx; let sr = 0, sg = 0, sb = 0;
      for (let k = 0; k < RAYS; k++) { const u1 = (k + rnd()) / RAYS, rr = Math.sqrt(u1), ph = 2*Math.PI*rnd(), cz = Math.sqrt(1 - u1);
        const dx = tx*rr*Math.cos(ph) + bx*rr*Math.sin(ph) + nx*cz, dy = ty*rr*Math.cos(ph) + by*rr*Math.sin(ph) + ny*cz, dz = tz*rr*Math.cos(ph) + bz*rr*Math.sin(ph) + nz*cz;
        if (nearest(ox, oy, oz, dx, dy, dz, pos, eps, hit) >= 0) { const t = hit[0], w0 = 1 - hit[1] - hit[2]; const u = uv[t*6]*w0 + uv[t*6+2]*hit[1] + uv[t*6+4]*hit[2], v = uv[t*6+1]*w0 + uv[t*6+3]*hit[1] + uv[t*6+5]*hit[2];
          const c = white(u, v); sr += c[0]; sg += c[1]; sb += c[2]; }
        else { const s = Math.min(1.1, Math.max(.2, dy * .5 + .6)); sr += .55*s; sg += .58*s; sb += .62*s; } }
      S[i*3] = sr / RAYS; S[i*3+1] = sg / RAYS; S[i*3+2] = sb / RAYS; }
    if (onStep) onStep(i / (r*r));
    if (i < r*r) setTimeout(step, 0); else { spread(m, [S], r); done(upsample(S, r, n)); }
  };
  step(); return { stop(){ stopped = true; } };
}
/* light from the nodes on the live grid (hard shadows; glowing parts let light through) */
function nodeLight(grid, nodes, ctr, n){
  if (!grid) return null;
  const r = grid.r, M = new Float32Array(r*r*3), { m, P, N, B, eps } = grid;
  for (let i = 0; i < r*r; i++) { if (!m[i]) continue;
    const nx = N[i*3], ny = N[i*3+1], nz = N[i*3+2], ox = P[i*3] + nx*eps, oy = P[i*3+1] + ny*eps, oz = P[i*3+2] + nz*eps;
    for (const nd of nodes) { const lx = nd.pos[0] - ctr[0] - ox, ly = nd.pos[1] - ctr[1] - oy, lz = nd.pos[2] - ctr[2] - oz, d = Math.hypot(lx, ly, lz) || 1e-9;
      const cr = Math.max(0, (nx*lx + ny*ly + nz*lz) / d), qq = d / Math.max(1e-3, nd.range); const w = cr * Math.pow(Math.max(0, 1 - qq*qq*qq*qq), 2) / (1 + 4*qq*qq) * (nd.strength ?? 1);
      if (w <= 1e-4) continue; if (anyHit(ox, oy, oz, lx/d, ly/d, lz/d, d - eps, B, eps)) continue;
      for (let c = 0; c < 3; c++) M[i*3+c] += w * (nd.color || [255, 255, 255])[c] / 255; } }
  for (let i = 0; i < M.length; i++) M[i] = Math.min(2, M[i]);
  spread(m, [M], r); return upsample(M, r, n);
}
/* a GLB with the texture, the normal map, tangents and (optionally) the inverted-hull outline */
function makeGLB({ name, P, N, uv, tan, png, npng, hull, color }){
  const nv = P.length / 3, bufs = [P, N, uv, tan].map(a => new Uint8Array(a.buffer.slice(a.byteOffset, a.byteOffset + a.byteLength))).concat([png]);
  if (npng) bufs.push(npng); if (hull) bufs.push(new Uint8Array(hull.buffer.slice(0)), new Uint8Array(flatNormals(hull).buffer));
  const views = [], chunks = []; let off = 0;
  bufs.forEach(b => { views.push({ buffer: 0, byteOffset: off, byteLength: b.length }); chunks.push(b); const pad = (4 - b.length % 4) % 4; if (pad) chunks.push(new Uint8Array(pad)); off += b.length + pad; });
  [0, 1, 2, 3].forEach(i => views[i].target = 34962);
  const mm = a => { const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9]; for (let i = 0; i < a.length; i++) { mn[i % 3] = Math.min(mn[i % 3], a[i]); mx[i % 3] = Math.max(mx[i % 3], a[i]); } return [mn, mx]; };
  const [mn, mx] = mm(P);
  const acc = [{ bufferView: 0, componentType: 5126, count: nv, type: 'VEC3', min: mn, max: mx }, { bufferView: 1, componentType: 5126, count: nv, type: 'VEC3' }, { bufferView: 2, componentType: 5126, count: nv, type: 'VEC2' }, { bufferView: 3, componentType: 5126, count: nv, type: 'VEC4' }];
  const mat = { name: 'lopol', pbrMetallicRoughness: { baseColorTexture: { index: 0 }, metallicFactor: 0, roughnessFactor: 1 } };
  const images = [{ bufferView: 4, mimeType: 'image/png' }], textures = [{ source: 0, sampler: 0 }];
  if (npng) { images.push({ bufferView: 5, mimeType: 'image/png' }); textures.push({ source: 1, sampler: 0 }); mat.normalTexture = { index: 1 }; }
  const prims = [{ attributes: { POSITION: 0, NORMAL: 1, TEXCOORD_0: 2, TANGENT: 3 }, material: 0 }], mats = [mat], J = {};
  if (hull) { const k = views.length - 2; views[k].target = views[k + 1].target = 34962; const [hn, hx] = mm(hull);
    acc.push({ bufferView: k, componentType: 5126, count: nv, type: 'VEC3', min: hn, max: hx }, { bufferView: k + 1, componentType: 5126, count: nv, type: 'VEC3' });
    prims.push({ attributes: { POSITION: acc.length - 2, NORMAL: acc.length - 1 }, material: 1 });
    mats.push({ name: 'outline', pbrMetallicRoughness: { baseColorFactor: color.map(c => c / 255).concat([1]), metallicFactor: 0, roughnessFactor: 1 }, extensions: { KHR_materials_unlit: {} } }); J.extensionsUsed = ['KHR_materials_unlit']; }
  Object.assign(J, { asset: { version: '2.0', generator: 'Image2LoPol' }, scene: 0, scenes: [{ nodes: [0] }], nodes: [{ mesh: 0, name }], meshes: [{ name, primitives: prims }],
    accessors: acc, bufferViews: views, buffers: [{ byteLength: off }], images, samplers: [{ magFilter: 9728, minFilter: 9728 }], textures, materials: mats });
  let js = new TextEncoder().encode(JSON.stringify(J)); const jp = (4 - js.length % 4) % 4; if (jp) { const t = new Uint8Array(js.length + jp).fill(32); t.set(js); js = t; }
  const head = new DataView(new ArrayBuffer(20)); head.setUint32(0, 0x46546C67, true); head.setUint32(4, 2, true); head.setUint32(8, 12 + 8 + js.length + 8 + off, true); head.setUint32(12, js.length, true); head.setUint32(16, 0x4E4F534A, true);
  const bh = new DataView(new ArrayBuffer(8)); bh.setUint32(0, off, true); bh.setUint32(4, 0x004E4942, true);
  return new Blob([head.buffer, js, bh.buffer, ...chunks], { type: 'model/gltf-binary' });
}
function flatNormals(P){ const N = new Float32Array(P.length);
  for (let i = 0; i < P.length; i += 9) { const ux = P[i+3]-P[i], uy = P[i+4]-P[i+1], uz = P[i+5]-P[i+2], vx = P[i+6]-P[i], vy = P[i+7]-P[i+1], vz = P[i+8]-P[i+2];
    let nx = uy*vz - uz*vy, ny = uz*vx - ux*vz, nz = ux*vy - uy*vx; const l = Math.hypot(nx, ny, nz) || 1; for (let k = 0; k < 9; k += 3) { N[i+k] = nx/l; N[i+k+1] = ny/l; N[i+k+2] = nz/l; } } return N; }
/* the inverted hull: every corner pushed out along its smoothed normal, faces flipped. width in model units. */
function hullOf(P, width){
  const NV = P.length / 3, q = 1e4, key = new Map(), acc = [], idx = new Int32Array(NV);
  for (let v = 0; v < NV; v++) { const k = Math.round(P[v*3]*q) + ',' + Math.round(P[v*3+1]*q) + ',' + Math.round(P[v*3+2]*q); let j = key.get(k); if (j === undefined) { j = acc.length; key.set(k, j); acc.push([0, 0, 0]); } idx[v] = j; }
  for (let i = 0; i < P.length; i += 9) { const ux = P[i+3]-P[i], uy = P[i+4]-P[i+1], uz = P[i+5]-P[i+2], vx = P[i+6]-P[i], vy = P[i+7]-P[i+1], vz = P[i+8]-P[i+2];
    const nx = uy*vz - uz*vy, ny = uz*vx - ux*vz, nz = ux*vy - uy*vx; for (let k = 0; k < 3; k++) { const a = acc[idx[i/3+k]]; a[0] += nx; a[1] += ny; a[2] += nz; } }
  const H = new Float32Array(P.length);
  for (let t = 0; t < NV; t += 3) for (const [k, s] of [[0, 0], [1, 2], [2, 1]]) { const a = acc[idx[t+s]], l = Math.hypot(a[0], a[1], a[2]) || 1; for (let c = 0; c < 3; c++) H[(t+k)*3+c] = P[(t+s)*3+c] + a[c]/l*width; }
  return H;
}
const decodeGrid = g => g ? { r: g.res, m: u8(g.mask), P: f32(g.P), N: f32(g.N), B: f32(g.blockers), eps: g.eps } : null;
/* load the maps of a model (D.maps data URLs or URLs) into a T for compose() */
async function prepare(D){
  const keys = ['albedo', 'ao', 'room', 'emit', 'logo', 'detail'];
  const ims = await Promise.all(keys.map(k => D.maps[k] ? loadImg(D.maps[k]) : null)); const n = ims[0].naturalWidth;
  const px = ims.map(im => im ? pixels(im, n) : null);
  const T = { n, A: px[0], AO: px[1], RM: px[2], EM: px[3], LG: px[4], DT: px[5], BO: null, LI: null };
  if (!T.LG) T.LG = new Uint8ClampedArray(n*n*4);
  if (D.maps.bounce) { const b = pixels(await loadImg(D.maps.bounce), n); T.BO = new Float32Array(n*n*3); for (let i = 0; i < n*n; i++) for (let c = 0; c < 3; c++) T.BO[i*3+c] = b[i*4+c] / 255 * 2; }
  const look = D.look || {}; T.GM = groupMap(look.gmap, n); T.groups = (look.groups || []).map(g => g.name); T.means = groupMeans(T, T.groups.length);
  return T;
}
window.LoPolTex = { compose, prepare, trace, nodeLight, decodeGrid, groupMap, groupMeans, makeGLB, hullOf, flatNormals, FX_DEFAULT, LIGHT_DEFAULT, f32, u8, loadImg };

window.LoPolView = function LoPolView(root, D, opts = {}){
  if (!document.getElementById('lpv-css')) { const st = document.createElement('style'); st.id = 'lpv-css'; st.textContent = CSS; document.head.appendChild(st); }
  root.classList.add('lpv'); root.innerHTML = '';
  const cv = document.createElement('canvas'); cv.className = 'v'; root.appendChild(cv);
  const gl = cv.getContext('webgl', { antialias: false, preserveDrawingBuffer: false });
  const pos = f32(D.pos), nrm = f32(D.nrm), uv = f32(D.uv), tan = D.tan ? f32(D.tan) : null, NV = pos.length / 3;
  const look = D.look || {}, set0 = opts.settings || {}, L = Object.assign({}, LIGHT_DEFAULT, look.light || {}, set0.light || {});
  const O = { nearest: true, light: true, spin: true, outline: !(look.outline && look.outline.on === false) };
  const OL = Object.assign({ width: .027, color: [5, 5, 5] }, look.outline || {});
  const lf = look.fx || {};
  const FX = Object.assign({}, FX_DEFAULT, { bits: lf.palette ? 5 : (lf.bits ?? FX_DEFAULT.bits) }, ...['dither', 'pixel', 'contrast', 'sat', 'bright'].filter(k => lf[k] !== undefined).map(k => ({ [k]: lf[k] })), set0.fx || {});
  const groups = (look.groups || []).map(g => g.name), colours = (set0.colours || []).slice(); colours.length = groups.length;
  const nodes = (set0.nodes || look.nodes || []).map(n => ({ pos: n.pos.slice(), color: (n.color || [255, 255, 255]).slice(), strength: n.strength ?? 1, range: n.range ?? 3 }));
  const ctr = (look.grid && look.grid.centre) || [0, 0, 0];

  /* ---------- GL ---------- */
  const VS = `attribute vec3 p; attribute vec3 n; attribute vec2 t; attribute vec4 g; uniform mat4 M, P;
  varying vec2 vt; varying vec3 vN; varying vec3 vT; varying vec3 vB;
  void main(){ gl_Position = P * M * vec4(p,1.); vt = t;
    vN = normalize((M * vec4(n,0.)).xyz); vT = normalize((M * vec4(g.xyz,0.)).xyz); vB = cross(vN, vT) * g.w; }`;
  const FS = `precision mediump float; uniform sampler2D tx, nm; uniform float lit, useNM; uniform vec3 L;
  varying vec2 vt; varying vec3 vN; varying vec3 vT; varying vec3 vB;
  void main(){ vec2 u = vt; vec3 c = texture2D(tx, u).rgb;
    if (lit > 0.) { vec3 n = vN; if (useNM > 0.) { vec3 m = texture2D(nm, u).xyz * 2. - 1.; n = normalize(vT * m.x + vB * m.y + vN * m.z); }
      c *= .55 + .6 * max(dot(n, L), 0.); }
    gl_FragColor = vec4(c, 1.); }`;
  const SVS = `attribute vec3 p; uniform mat4 M, P; uniform float ps; void main(){ gl_Position = P * M * vec4(p,1.); gl_PointSize = ps; }`;
  const SFS = `precision mediump float; uniform vec3 col; uniform float pt; void main(){ if (pt > 0.) { vec2 d = gl_PointCoord - .5; if (dot(d,d) > .25) discard; } gl_FragColor = vec4(col, 1.); }`;
  function prog(vs, fs){ const p = gl.createProgram(); for (const [t, s] of [[gl.VERTEX_SHADER, vs], [gl.FRAGMENT_SHADER, fs]]) { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw gl.getShaderInfoLog(sh); gl.attachShader(p, sh); } gl.linkProgram(p); return p; }
  const pr = prog(VS, FS), ps = prog(SVS, SFS);
  const mk = () => gl.createBuffer(); const bP = mk(), bN = mk(), bT = mk(), bG = mk(), bH = mk(), bL = mk();
  const put = (b, a) => { gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, a, gl.DYNAMIC_DRAW); };
  const tanF = tan || new Float32Array(NV * 4).map((_, i) => i % 4 === 3 ? 1 : i % 4 === 0 ? 1 : 0);
  put(bT, uv); put(bG, tanF);
  const att = (p, b, name, k) => { const l = gl.getAttribLocation(p, name); if (l < 0) return; gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, k, gl.FLOAT, false, 0, 0); };
  const U = (p, n) => gl.getUniformLocation(p, n);
  const texC = gl.createTexture(), texN = gl.createTexture();
  function upload(t, src, near){ gl.bindTexture(gl.TEXTURE_2D, t); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, src);
    for (const k of [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T]) gl.texParameteri(gl.TEXTURE_2D, k, gl.CLAMP_TO_EDGE);
    const f = near ? gl.NEAREST : gl.LINEAR; gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, f); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, f); }
  let texSrc = null, nrmSrc = null, hasNM = false;

  /* ---------- geometry and the outline hull ---------- */
  let curPos = pos, curNrm = nrm, hull = null;
  function flatNormals(P){ const N = new Float32Array(P.length);
    for (let i = 0; i < P.length; i += 9) { const ux = P[i+3]-P[i], uy = P[i+4]-P[i+1], uz = P[i+5]-P[i+2], vx = P[i+6]-P[i], vy = P[i+7]-P[i+1], vz = P[i+8]-P[i+2];
      let nx = uy*vz - uz*vy, ny = uz*vx - ux*vz, nz = ux*vy - uy*vx; const l = Math.hypot(nx, ny, nz) || 1; for (let k = 0; k < 9; k += 3) { N[i+k] = nx/l; N[i+k+1] = ny/l; N[i+k+2] = nz/l; } } return N; }
  function geometry(){ put(bP, curPos); put(bN, curNrm); buildHull(); }
  function buildHull(){
    const P = curPos, q = 1e4, key = new Map(), acc = [], idx = new Int32Array(NV);
    for (let v = 0; v < NV; v++) { const k = Math.round(P[v*3]*q) + ',' + Math.round(P[v*3+1]*q) + ',' + Math.round(P[v*3+2]*q); let j = key.get(k); if (j === undefined) { j = acc.length; key.set(k, j); acc.push([0, 0, 0]); } idx[v] = j; }
    for (let i = 0; i < P.length; i += 9) { const ux = P[i+3]-P[i], uy = P[i+4]-P[i+1], uz = P[i+5]-P[i+2], vx = P[i+6]-P[i], vy = P[i+7]-P[i+1], vz = P[i+8]-P[i+2];
      const nx = uy*vz - uz*vy, ny = uz*vx - ux*vz, nz = ux*vy - uy*vx; for (let k = 0; k < 3; k++) { const a = acc[idx[i/3+k]]; a[0] += nx; a[1] += ny; a[2] += nz; } }
    const w = OL.width * D.radius * 2, H = new Float32Array(P.length);
    for (let t = 0; t < NV; t += 3) for (const [k, s] of [[0, 0], [1, 2], [2, 1]]) { const a = acc[idx[t+s]], l = Math.hypot(a[0], a[1], a[2]) || 1; for (let c = 0; c < 3; c++) H[(t+k)*3+c] = P[(t+s)*3+c] + a[c]/l*w; }
    hull = H; put(bH, H);
  }

  /* ---------- UI ---------- */
  const bar = document.createElement('div'); bar.className = 'bar';
  bar.innerHTML = `<button data-k="nearest" class="on">Pixel texture</button><button data-k="light" class="on">Lighting</button>
    <button data-k="spin" class="on">Turn</button><button data-k="outline" title="An inverted-hull outline, like Roblox items">Outline</button>`;
  root.appendChild(bar);
  const side = document.createElement('div'); side.className = 'side'; root.appendChild(side);
  const sl = (key, label, min, max, step, attr = 'data-l') => `<label><span class="lb">${label}<b class="val"></b></span><input type="range" ${attr}="${key}" min="${min}" max="${max}" step="${step}"></label>`;
  side.innerHTML = `<h4>Texture effects</h4>${sl('bits', 'Colour depth', 2, 8, 1, 'data-f')}${sl('dither', 'Dither', 0, 1, .01, 'data-f')}${sl('pixel', 'Pixel size', 1, 8, 1, 'data-f')}
    ${sl('contrast', 'Contrast', -.5, .5, .01, 'data-f')}${sl('sat', 'Saturation', -1, 1, .01, 'data-f')}${sl('bright', 'Brightness', -.4, .4, .01, 'data-f')}
    <div class="colRow" hidden><h4>Colours</h4><div class="cols"></div></div>
    <h4>Baked lighting</h4>${sl('ao', 'Ambient occlusion', 0, 1, .01)}${sl('room', 'Room light', 0, 1, .01)}${sl('detail', 'Surface detail (normal map)', 0, 1.5, .01)}${sl('lights', 'Light nodes', 0, 2, .01)}
    <div class="bounceRow">${sl('bounce', 'Bounce light (path traced)', 0, 1.5, .01)}</div>
    <div class="row"><button class="ghost pt">Path-trace bounce light</button></div><div class="msg"></div>
    <h4>Light nodes <button class="ghost add" style="flex:none;padding:3px 8px">+ Add</button></h4><div class="nodes"></div>
    <div class="olRow"><h4>Outline</h4>${sl('w', 'Width', .004, .06, .001, 'data-o')}<div class="row">Colour <input type="color" class="olc"><b class="val olv"></b></div></div>
    <h4>Download</h4><div class="row"><button class="act glb">Model .glb</button><button class="act objz">.obj zip</button></div>
    <div class="row"><button class="ghost dtex">Texture</button><button class="ghost dnrm">Normal map</button></div>`;
  const $ = s => root.querySelector(s), msg = t => ($('.msg').textContent = t);
  const fmt = (k, v) => k === 'bits' ? (v >= 8 ? '8-bit (off)' : v + '-bit') : k === 'pixel' ? v + '×' : k === 'w' ? v.toFixed(3) : (v > 0 && /contrast|sat|bright/.test(k) ? '+' : '') + (+v).toFixed(2);
  const show = el => { const v = el.closest('label').querySelector('.val'); if (v) v.textContent = fmt(el.dataset.l || el.dataset.f || el.dataset.o || el.dataset.v || '', +el.value); };
  side.querySelectorAll('input[data-l]').forEach(el => { el.value = L[el.dataset.l]; show(el); el.oninput = () => { L[el.dataset.l] = +el.value; show(el); schedule(); }; });
  side.querySelectorAll('input[data-f]').forEach(el => { el.value = FX[el.dataset.f]; show(el); el.oninput = () => { FX[el.dataset.f] = +el.value; show(el); schedule(); }; });
  const olw = side.querySelector('input[data-o]'); olw.value = OL.width; show(olw); $('.olc').value = hex(OL.color); $('.olv').textContent = 'RGB ' + OL.color.join(' ');
  olw.oninput = () => { OL.width = +olw.value; show(olw); buildHull(); };
  $('.olc').oninput = e => { OL.color = unhex(e.target.value); $('.olv').textContent = 'RGB ' + OL.color.join(' '); };
  bar.querySelectorAll('button[data-k]').forEach(b => { b.classList.toggle('on', !!O[b.dataset.k]); b.onclick = () => { const k = b.dataset.k; O[k] = !O[k]; b.classList.toggle('on', O[k]);
    if (k === 'nearest' && texSrc) upload(texC, texSrc, O.nearest);
    if (k === 'outline') $('.olRow').hidden = !O.outline; }; });
  $('.olRow').hidden = !O.outline;
  if (!D.maps) side.querySelectorAll('h4,label,.row,.nodes,.msg,.bounceRow,.colRow').forEach(e => { if (!e.closest('.olRow') && !e.querySelector('.glb,.objz,.dtex')) e.hidden = true; });
  const range = D.radius * 1.4;
  function drawNodes(){
    const box = $('.nodes'); box.innerHTML = '';
    nodes.forEach((n, i) => { const el = document.createElement('div'); el.className = 'node';
      el.innerHTML = `<div class="row"><input type="color" value="${hex(n.color)}"><span style="flex:1">Light ${i + 1} <b class="val nc">RGB ${n.color.join(' ')}</b></span><button class="x" title="Remove">✕</button></div>
        ${['x', 'y', 'z'].map((a, k) => `<label><span class="lb">${a.toUpperCase()}<b class="val"></b></span><input type="range" data-a="${k}" data-v="n" min="${(ctr[k] - range).toFixed(2)}" max="${(ctr[k] + range).toFixed(2)}" step="0.01" value="${n.pos[k]}"></label>`).join('')}
        <label><span class="lb">Strength<b class="val"></b></span><input type="range" data-s data-v="n" min="0" max="4" step="0.01" value="${n.strength}"></label><label><span class="lb">Range<b class="val"></b></span><input type="range" data-r data-v="n" min="0.2" max="${(D.radius * 4).toFixed(2)}" step="0.01" value="${n.range}"></label>`;
      el.querySelectorAll('input[type=range]').forEach(r => { show(r); r.addEventListener('input', () => show(r)); });
      el.querySelector('input[type=color]').oninput = e => { n.color = unhex(e.target.value); el.querySelector('.nc').textContent = 'RGB ' + n.color.join(' '); relight(); };
      el.querySelectorAll('input[data-a]').forEach(r => r.oninput = () => { n.pos[+r.dataset.a] = +r.value; relight(); });
      el.querySelector('[data-s]').oninput = e => { n.strength = +e.target.value; relight(); };
      el.querySelector('[data-r]').oninput = e => { n.range = +e.target.value; relight(); };
      el.querySelector('.x').onclick = () => { nodes.splice(i, 1); drawNodes(); relight(); };
      box.appendChild(el); });
  }
  $('.add').onclick = () => { nodes.push({ pos: [ctr[0], ctr[1] + D.radius * .6, ctr[2] + D.radius * .6], color: [255, 200, 120], strength: 1.2, range: D.radius * 2 }); drawNodes(); relight(); };

  /* ---------- the texture (LoPolTex.compose): recolour, retro look on the colour, crisp light on top ---------- */
  let n = 0, T = null, cur = null, octx, oimg, outCanvas, nrmSrc0 = null, tracer = null;
  const grid = decodeGrid(look.grid);
  function relight(){ if (T) T.LI = nodeLight(grid, nodes, ctr, n); schedule(); }
  let pend = 0; function schedule(){ if (!pend) pend = requestAnimationFrame(() => { pend = 0; bake(); }); }
  function bake(){
    if (!T) return; compose(T, { fx: FX, light: L, colours }, oimg);
    octx.putImageData(oimg, 0, 0); cur = outCanvas; texSrc = outCanvas; upload(texC, outCanvas, O.nearest);
    if (opts.onTexture) opts.onTexture(outCanvas, settings());
  }
  /* path-traced bounce: automatic when the bounce slider is above 0 and the model has no bounce map yet */
  function pathTrace(){
    if (!grid || !T || tracer) return; $('.pt').hidden = true;
    tracer = trace(T, grid, pos, uv, L, f => msg(`Path tracing… ${Math.round(f * 100)}%`), BO => {
      tracer = null; T.BO = BO; $('.bounceRow').hidden = false; msg('Bounce light baked in.'); $('.pt').hidden = false; $('.pt').textContent = 'Path-trace again'; schedule(); });
  }
  $('.pt').onclick = pathTrace;
  function drawColours(){
    const box = $('.cols'); if (!box) return; box.innerHTML = ''; $('.colRow').hidden = !groups.length;
    groups.forEach((g, i) => { const c = colours[i], base = T ? T.means[i].map(Math.round) : [128, 128, 128], el = document.createElement('div'); el.className = 'node';
      el.innerHTML = `<div class="row"><input type="color" value="${hex(c ? c.rgb : base)}"><span style="flex:1">${g} <b class="val cv">${c ? 'RGB ' + c.rgb.join(' ') : 'original'}</b></span><button class="x" title="Back to the painted colour" ${c ? '' : 'hidden'}>↺</button></div>
        <label ${c ? '' : 'hidden'}><span class="lb">Strength<b class="val"></b></span><input type="range" data-v="c" min="0" max="1" step="0.01" value="${c ? c.amount ?? 1 : 1}"></label>`;
      const rg = el.querySelector('input[type=range]'); show(rg);
      el.querySelector('input[type=color]').oninput = e => { colours[i] = { rgb: unhex(e.target.value), amount: colours[i] ? colours[i].amount ?? 1 : 1 };
        el.querySelector('.cv').textContent = 'RGB ' + colours[i].rgb.join(' '); el.querySelector('.x').hidden = false; rg.closest('label').hidden = false; schedule(); };
      rg.oninput = () => { show(rg); if (colours[i]) { colours[i].amount = +rg.value; schedule(); } };
      el.querySelector('.x').onclick = () => { colours[i] = null; drawColours(); schedule(); };
      box.appendChild(el); });
  }
  function settings(){ return { fx: Object.assign({}, FX), light: Object.assign({}, L), nodes: nodes.map(n => JSON.parse(JSON.stringify(n))), colours: colours.map(c => c ? { rgb: c.rgb.slice(), amount: c.amount ?? 1 } : null), outline: { on: O.outline, width: OL.width, color: OL.color.slice() } }; }

  const ready = (async () => {
    if (D.maps) {
      T = await prepare(D); n = T.n;
      outCanvas = document.createElement('canvas'); outCanvas.width = outCanvas.height = n; octx = outCanvas.getContext('2d'); oimg = octx.createImageData(n, n);
      nrmSrc = await loadImg(D.maps.normal); upload(texN, nrmSrc, false); hasNM = true; drawNodes(); drawColours();
      if (T.BO) $('.bounceRow').hidden = false;
      T.LI = nodeLight(grid, nodes, ctr, n); bake();
      if (!T.BO && L.bounce > 0 && opts.autoTrace !== false) pathTrace();
    } else { const im = await loadImg(D.tex); texSrc = im; upload(texC, im, O.nearest); }
  })();

  /* ---------- downloads ---------- */
  const save = (blob, name) => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 60000); };
  const slug = (D.name || 'model').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const pngOf = async src => { const c = document.createElement('canvas'); c.width = src.naturalWidth || src.width; c.height = src.naturalHeight || src.height; c.getContext('2d').drawImage(src, 0, 0); return new Uint8Array(await (await new Promise(r => c.toBlob(r, 'image/png'))).arrayBuffer()); };
  function glb(png, npng){ return makeGLB({ name: D.name, P: curPos, N: curNrm, uv, tan: tanF, png, npng, hull: O.outline ? hull : null, color: OL.color }); }
  function obj(){
    const P = curPos, N = curNrm, nv = P.length / 3, f = v => v.toFixed(5), Ls = ['# ' + D.name + ', made with Image2LoPol', 'mtllib model.mtl', 'o model'];
    for (let i = 0; i < nv; i++) Ls.push(`v ${f(P[i*3])} ${f(P[i*3+1])} ${f(P[i*3+2])}`);
    for (let i = 0; i < nv; i++) Ls.push(`vt ${uv[i*2].toFixed(6)} ${(1 - uv[i*2+1]).toFixed(6)}`);
    for (let i = 0; i < nv; i += 3) Ls.push(`vn ${f(N[i*3])} ${f(N[i*3+1])} ${f(N[i*3+2])}`);
    Ls.push('usemtl lopol', 's off'); for (let t = 0; t < nv / 3; t++) { const a = t*3 + 1; Ls.push(`f ${a}/${a}/${t+1} ${a+1}/${a+1}/${t+1} ${a+2}/${a+2}/${t+1}`); }
    let mtl = 'newmtl lopol\nKa 1 1 1\nKd 1 1 1\nKs 0 0 0\nd 1\nillum 1\nmap_Kd texture.png\nnorm normal.png\n';
    if (O.outline && hull) { const HN = flatNormals(hull); Ls.push('o outline'); for (let i = 0; i < nv; i++) Ls.push(`v ${f(hull[i*3])} ${f(hull[i*3+1])} ${f(hull[i*3+2])}`);
      for (let i = 0; i < nv; i += 3) Ls.push(`vn ${f(HN[i*3])} ${f(HN[i*3+1])} ${f(HN[i*3+2])}`); Ls.push('usemtl outline');
      for (let t = 0; t < nv / 3; t++) { const a = nv + t*3 + 1, nn = nv / 3 + t + 1; Ls.push(`f ${a}//${nn} ${a+1}//${nn} ${a+2}//${nn}`); }
      mtl += `newmtl outline\nKa 0 0 0\nKd ${OL.color.map(c => (c / 255).toFixed(3)).join(' ')}\nKs 0 0 0\nd 1\nillum 0\n`; }
    return [new TextEncoder().encode(Ls.join('\n') + '\n'), new TextEncoder().encode(mtl)];
  }
  const texNow = () => cur || texSrc;
  $('.dtex').onclick = async () => save(new Blob([await pngOf(texNow())], { type: 'image/png' }), slug + '-texture.png');
  $('.dnrm').onclick = async () => nrmSrc && save(new Blob([await pngOf(nrmSrc)], { type: 'image/png' }), slug + '-normal.png');
  $('.glb').onclick = async () => save(glb(await pngOf(texNow()), nrmSrc ? await pngOf(nrmSrc) : null), slug + (O.outline ? '-outline' : '') + '.glb');
  $('.objz').onclick = async () => { const [o, m] = obj(); const files = [{ name: 'model.obj', data: o }, { name: 'model.mtl', data: m }, { name: 'texture.png', data: await pngOf(texNow()) }];
    if (nrmSrc) files.push({ name: 'normal.png', data: await pngOf(nrmSrc) }); save(zip(files.map(f => ({ name: slug + '/' + f.name, data: f.data }))), slug + '-obj.zip'); };

  /* ---------- camera + draw ---------- */
  const S = { yaw: -0.6, pitch: 0.3, dist: D.radius * 4.8, drag: null, idle: 0 };
  cv.onpointerdown = e => { S.drag = { x: e.clientX, y: e.clientY, yaw: S.yaw, pitch: S.pitch }; cv.setPointerCapture(e.pointerId); };
  cv.onpointermove = e => { if (!S.drag) return; S.yaw = S.drag.yaw + (e.clientX - S.drag.x) * .01; S.pitch = Math.max(-1.4, Math.min(1.4, S.drag.pitch + (e.clientY - S.drag.y) * .01)); };
  cv.onpointerup = () => { S.drag = null; S.idle = performance.now(); };
  cv.addEventListener('wheel', e => { e.preventDefault(); S.dist = Math.max(D.radius * 1.3, Math.min(D.radius * 9, S.dist * Math.exp(e.deltaY * .001))); }, { passive: false });
  const mul = (a, b) => { const o = new Float32Array(16); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k*4+j] * b[i*4+k]; o[i*4+j] = s; } return o; };
  const rx = a => new Float32Array([1,0,0,0, 0,Math.cos(a),Math.sin(a),0, 0,-Math.sin(a),Math.cos(a),0, 0,0,0,1]);
  const ry = a => new Float32Array([Math.cos(a),0,-Math.sin(a),0, 0,1,0,0, Math.sin(a),0,Math.cos(a),0, 0,0,0,1]);
  const tr = (x, y, z) => new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, x,y,z,1]);
  const persp = (f, a, nn, far) => { const t = 1 / Math.tan(f / 2); return new Float32Array([t/a,0,0,0, 0,t,0,0, 0,0,(far+nn)/(nn-far),-1, 0,0,2*far*nn/(nn-far),0]); };
  geometry();
  let last = performance.now(), alive = true;
  function frame(t){
    if (!alive) return; const dt = Math.min(.05, (t - last) / 1000); last = t;
    if (O.spin && !S.drag && t - S.idle > 1200) S.yaw += dt * .5;
    const k = Math.min(2, devicePixelRatio || 1);
    const w = Math.max(1, Math.round(cv.clientWidth * k)), h = Math.max(1, Math.round(cv.clientHeight * k)); if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    gl.viewport(0, 0, w, h); gl.clearColor(.09, .09, .1, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST);
    const M = mul(tr(0, 0, -S.dist), mul(rx(S.pitch), ry(S.yaw))), P = persp(.6, w / h, D.radius * .05, D.radius * 30);
    if (texSrc) {
      gl.useProgram(pr); att(pr, bP, 'p', 3); att(pr, bN, 'n', 3); att(pr, bT, 't', 2); att(pr, bG, 'g', 4);
      gl.uniformMatrix4fv(U(pr, 'M'), false, M); gl.uniformMatrix4fv(U(pr, 'P'), false, P);
      gl.uniform1f(U(pr, 'lit'), O.light ? 1 : 0); gl.uniform1f(U(pr, 'useNM'), hasNM && O.light ? 1 : 0);
      const Lv = [-.45, .8, .6], l = Math.hypot(...Lv); gl.uniform3f(U(pr, 'L'), Lv[0]/l, Lv[1]/l, Lv[2]/l);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texC); gl.uniform1i(U(pr, 'tx'), 0);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, texN); gl.uniform1i(U(pr, 'nm'), 1); gl.activeTexture(gl.TEXTURE0);
      gl.disable(gl.CULL_FACE); gl.drawArrays(gl.TRIANGLES, 0, NV);
      gl.useProgram(ps); gl.uniformMatrix4fv(U(ps, 'M'), false, M); gl.uniformMatrix4fv(U(ps, 'P'), false, P);
      if (O.outline && hull) { att(ps, bH, 'p', 3); gl.uniform3f(U(ps, 'col'), OL.color[0]/255, OL.color[1]/255, OL.color[2]/255); gl.uniform1f(U(ps, 'pt'), 0); gl.uniform1f(U(ps, 'ps'), 1);
        gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK); gl.frontFace(gl.CCW); gl.drawArrays(gl.TRIANGLES, 0, NV); gl.disable(gl.CULL_FACE); }
      if (nodes.length && D.maps) { const pts = new Float32Array(nodes.flatMap(nd => [nd.pos[0] - ctr[0], nd.pos[1] - ctr[1], nd.pos[2] - ctr[2]])); put(bL, pts); att(ps, bL, 'p', 3);
        gl.uniform1f(U(ps, 'pt'), 1); gl.uniform1f(U(ps, 'ps'), 12 * k); gl.disable(gl.DEPTH_TEST);
        nodes.forEach((nd, i) => { gl.uniform3f(U(ps, 'col'), nd.color[0]/255, nd.color[1]/255, nd.color[2]/255); gl.drawArrays(gl.POINTS, i, 1); }); gl.enable(gl.DEPTH_TEST); }
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  return { ready, light: L, fx: FX, nodes, colours, groups, options: O, outline: OL, settings, pathTrace, update: schedule, relight,
    setColour(i, rgb, amount = 1){ colours[i] = rgb ? { rgb, amount } : null; drawColours(); schedule(); },
    destroy(){ alive = false; if (tracer) tracer.stop(); root.innerHTML = ''; }, texture: () => texNow(), mesh: { pos, uv, nrm, tan: tanF }, hull: () => hull, bounce: () => T && T.BO, D };
};
})();
