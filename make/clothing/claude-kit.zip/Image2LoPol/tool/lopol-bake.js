/* Image2LoPol in the browser: paint a template from an image model's picture.
   LoPolBake.load(baseUrl)           -> template (template.json + texmap.bin + maps)
   LoPolBake.bake(tpl, imageOrCanvas, {preset}) -> { D (for LoPolView), match:[iou...], albedo canvas, unshade }
   LoPolBake.example(tpl)            -> D of the template's finished example (no baking)
   Same steps as tool/lopol.py bake: align, sample, match the two views, blend, fill hidden faces, grade, logo. */
(function () {
'use strict';
const PRESETS = {  // the same looks as the Clothing Studio's presets (tool/lopol.py FX_PRESETS)
  grug: { bits: 4, dither: 1, pixel: 2, contrast: .5, sat: 0, bright: 0 },   // the default look
  ps1: { bits: 4, dither: 1, pixel: 1, contrast: .06, sat: 0 }, n64: { bits: 5, dither: .35, pixel: 1, contrast: .04, sat: .1 },
  '16bit': { bits: 5, dither: .45, pixel: 2, contrast: .06, sat: .18 }, clean: { bits: 8, dither: 0, pixel: 1, contrast: .04, sat: .05 } };
const loadImg = src => new Promise((r, j) => { const i = new Image(); i.crossOrigin = 'anonymous'; i.onload = () => r(i); i.onerror = () => j(new Error('Could not load ' + src)); i.src = src; });
const canvasOf = (src, w, h) => { const c = document.createElement('canvas'); c.width = w || src.naturalWidth || src.width; c.height = h || src.naturalHeight || src.height; c.getContext('2d').drawImage(src, 0, 0, c.width, c.height); return c; };
const toURL = c => c.toDataURL('image/png');

async function load(base){
  base = base.replace(/\/?$/, '/');
  const tpl = await (await fetch(base + 'template.json')).json();
  const res = await fetch(base + 'texmap.bin');
  const raw = new Uint8Array(await new Response(res.body.pipeThrough(new DecompressionStream('deflate'))).arrayBuffer());
  const S = tpl.atlas, n = S * S, V = tpl.views; let o = 0;
  const take = (T, len) => { const a = new T(raw.buffer.slice(o, o + len * T.BYTES_PER_ELEMENT)); o += len * T.BYTES_PER_ELEMENT; return a; };
  tpl.cid = take(Int16Array, n); tpl.xy = []; for (let v = 0; v < V; v++) tpl.xy.push([take(Uint16Array, n), take(Uint16Array, n)]);
  tpl.wt = []; for (let v = 0; v < V; v++) tpl.wt.push(take(Uint8Array, n)); tpl.sh = []; for (let v = 0; v < V; v++) tpl.sh.push(take(Uint8Array, n));
  tpl.base = base;
  const ref = await loadImg(base + 'reference.png');
  tpl.reference = ref; tpl.mapUrls = { ao: base + 'ao.png', room: base + 'room.png', emit: base + 'emit.png', detail: base + 'detail.png', normal: base + 'normal.png' };
  tpl.refUrl = base + 'reference.png'; tpl.exampleUrl = tpl.example ? base + 'example.jpg' : null;
  // the reference's silhouette, for lining up the painted picture
  const rc = canvasOf(ref, tpl.ref[0], tpl.ref[1]).getContext('2d').getImageData(0, 0, tpl.ref[0], tpl.ref[1]).data;
  const rm = new Uint8Array(tpl.ref[0] * tpl.ref[1]); for (let i = 0; i < rm.length; i++) rm[i] = (Math.max(Math.abs(rc[i*4]-255), Math.abs(rc[i*4+1]-255), Math.abs(rc[i*4+2]-255)) > 28) ? 1 : 0;
  tpl.refMask = rm;
  return tpl;
}

function fgMask(d, w, h){
  const bd = []; for (let x = 0; x < w; x++) { bd.push(x, (h - 1) * w + x); } for (let y = 0; y < h; y++) { bd.push(y * w, y * w + w - 1); }
  const med = c => { const a = bd.map(i => d[i*4+c]).sort((p, q) => p - q); return a[a.length >> 1]; }, bg = [med(0), med(1), med(2)];
  const m = new Uint8Array(w * h); for (let i = 0; i < w * h; i++) m[i] = Math.max(Math.abs(d[i*4]-bg[0]), Math.abs(d[i*4+1]-bg[1]), Math.abs(d[i*4+2]-bg[2])) > 28 ? 1 : 0;
  return m;
}
function erode(m, w, h, k){ let a = m; for (let it = 0; it < k; it++) { const b = new Uint8Array(w * h); for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { const i = y*w + x; b[i] = a[i] & a[i-1] & a[i+1] & a[i-w] & a[i+w]; } a = b; } return a; }

/* scale + shift per view so the painted silhouette sits on the reference's (best overlap, like the Python hill climb) */
function align(refm, RW, RH, resm, w, h, nv){
  const out = [];
  for (let i = 0; i < nv; i++) {
    const ax0 = Math.floor(RW * i / nv), ax1 = Math.floor(RW * (i + 1) / nv), bx0 = Math.floor(w * i / nv), bx1 = Math.floor(w * (i + 1) / nv);
    const bb = (m, W, x0, x1, H) => { let a = [1e9, -1e9, 1e9, -1e9], c = 0; for (let y = 0; y < H; y++) for (let x = x0; x < x1; x++) if (m[y*W + x]) { c++; if (x < a[0]) a[0] = x; if (x > a[1]) a[1] = x; if (y < a[2]) a[2] = y; if (y > a[3]) a[3] = y; } return c ? a : null; };
    const A = bb(refm, RW, ax0, ax1, RH), B = bb(resm, w, bx0, bx1, h);
    if (!A || !B) throw new Error('No object found in view ' + (i + 1) + ' of the picture.');
    let s = ((B[3]-B[2]) / Math.max(1, A[3]-A[2]) + (B[1]-B[0]) / Math.max(1, A[1]-A[0])) / 2;
    let tx = (B[1]+B[0]) / 2 - s * (A[1]+A[0]) / 2, ty = (B[3]+B[2]) / 2 - s * (A[3]+A[2]) / 2;
    const mx = (A[1]+A[0]) / 2, my = (A[3]+A[2]) / 2;
    const iou = (s, tx, ty, step) => { let I = 0, Un = 0;
      for (let qy = 0; qy < h; qy += step) for (let qx = bx0; qx < bx1; qx += step) { const px = Math.floor((qx - tx) / s), py = Math.floor((qy - ty) / s);
        const a = px >= ax0 && px < ax1 && py >= 0 && py < RH ? refm[py*RW + px] : 0, b = resm[qy*w + qx]; if (a & b) I++; if (a | b) Un++; }
      return I / Math.max(1, Un); };
    let best = iou(s, tx, ty, 3);
    for (const [ds, dt] of [[.02, 6], [.01, 3], [.004, 1.5], [.002, .75]]) { let moved = true, guard = 0;
      while (moved && guard++ < 60) { moved = false;
        for (const [sc, cx0, cy0] of [[s*(1+ds), tx, ty], [s*(1-ds), tx, ty], [s, tx+dt, ty], [s, tx-dt, ty], [s, tx, ty+dt], [s, tx, ty-dt]]) {
          let cx = cx0, cy = cy0; if (sc !== s) { cx = tx + (s - sc) * mx; cy = ty + (s - sc) * my; }
          const v = iou(sc, cx, cy, ds < .01 ? 2 : 3); if (v > best + 1e-5) { best = v; s = sc; tx = cx; ty = cy; moved = true; } } } }
    out.push({ s, tx, ty, iou: best });
  }
  return out;
}

function pushpull(img, m, w, h){  // fill holes from coarser levels (img: Float32 w*h*3, m: Uint8 w*h)
  let all = true, any = false; for (let i = 0; i < w*h; i++) { if (m[i]) any = true; else all = false; }
  if (all) return img; const out = new Float32Array(img);
  if (!any) { out.fill(128); return out; } if (w <= 1 && h <= 1) return out;
  const w2 = (w + 1) >> 1, h2 = (h + 1) >> 1, si = new Float32Array(w2*h2*3), sm = new Float32Array(w2*h2);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = y*w + x; if (!m[i]) continue; const j = (y >> 1)*w2 + (x >> 1); sm[j]++; for (let c = 0; c < 3; c++) si[j*3+c] += img[i*3+c]; }
  const small = new Float32Array(w2*h2*3), smm = new Uint8Array(w2*h2);
  for (let j = 0; j < w2*h2; j++) if (sm[j]) { smm[j] = 1; for (let c = 0; c < 3; c++) small[j*3+c] = si[j*3+c] / sm[j]; }
  const up = pushpull(small, smm, w2, h2);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = y*w + x; if (m[i]) continue; const j = (y >> 1)*w2 + (x >> 1); for (let c = 0; c < 3; c++) out[i*3+c] = up[j*3+c]; }
  return out;
}
function resize(src, sw, sh, dw, dh, flip){  // bilinear, optional 'h' / 'v' mirror
  const out = new Float32Array(dw*dh*3);
  for (let y = 0; y < dh; y++) for (let x = 0; x < dw; x++) {
    let fx = (x + .5) * sw / dw - .5, fy = (y + .5) * sh / dh - .5; if (flip === 'h') fx = sw - 1 - fx; if (flip === 'v') fy = sh - 1 - fy;
    fx = Math.max(0, Math.min(sw - 1, fx)); fy = Math.max(0, Math.min(sh - 1, fy)); const x0 = Math.floor(fx), y0 = Math.floor(fy), x1 = Math.min(sw - 1, x0 + 1), y1 = Math.min(sh - 1, y0 + 1), ax = fx - x0, ay = fy - y0;
    for (let c = 0; c < 3; c++) out[(y*dw+x)*3+c] = (src[(y0*sw+x0)*3+c]*(1-ax) + src[(y0*sw+x1)*3+c]*ax)*(1-ay) + (src[(y1*sw+x0)*3+c]*(1-ax) + src[(y1*sw+x1)*3+c]*ax)*ay;
  }
  return out;
}

function followed(stats, charts, nv){  // same as tool/lopol.py shading_followed
  const by = new Map();
  for (let v = 0; v < nv; v++) charts.forEach((c, k) => { const st = stats[v*charts.length + k]; if (st[0] <= 30) return; const g = c.group ?? k; if (!by.has(g)) by.set(g, []); by.get(g).push([st[0], st[1] / st[0], st[2] / st[0]]); });
  let num = 0, den = 0;
  for (const rows of by.values()) { if (rows.length < 2) continue; const N = rows.reduce((a, r) => a + r[0], 0), ym = rows.reduce((a, r) => a + r[0]*r[1], 0) / N, xm = rows.reduce((a, r) => a + r[0]*r[2], 0) / N;
    for (const [w, y, x] of rows) { num += w * (x - xm) * (y - ym); den += w * (x - xm) ** 2; } }
  return den < 1e-6 ? .5 : Math.max(0, Math.min(.9, num / den));
}
/* the template's own finished example, ready to wear without baking */
function example(tpl){
  const b = tpl.base;
  return { name: tpl.name, ...tpl.mesh, tex: b + 'example-albedo.jpg', look: JSON.parse(JSON.stringify(tpl.look)),
    maps: Object.assign({ albedo: b + 'example-albedo.jpg', bounce: b + 'example-bounce.jpg', logo: b + 'example-logo.png' }, tpl.mapUrls) };
}

async function bake(tpl, painted, opts = {}){
  const pc = canvasOf(painted), w = pc.width, h = pc.height, P = pc.getContext('2d').getImageData(0, 0, w, h).data;
  const res = fgMask(P, w, h), inner = erode(res, w, h, 2), [RW, RH] = tpl.ref, nv = tpl.views;
  const al = align(tpl.refMask, RW, RH, res, w, h, nv);
  const S = tpl.atlas, sref = tpl.shadeRef, NC = tpl.charts.length;
  const samp = (x, y, out) => { x = Math.max(0, Math.min(w - 1.001, x - .5)); y = Math.max(0, Math.min(h - 1.001, y - .5)); const x0 = x | 0, y0 = y | 0, fx = x - x0, fy = y - y0;
    for (let c = 0; c < 3; c++) { const a = P[(y0*w+x0)*4+c], b = P[(y0*w+x0+1)*4+c], d = P[((y0+1)*w+x0)*4+c], e = P[((y0+1)*w+x0+1)*4+c]; out[c] = (a*(1-fx) + b*fx)*(1-fy) + (d*(1-fx) + e*fx)*fy; } };
  // 1. sample every texel from every view that saw it
  const col = Array.from({ length: nv }, () => new Float32Array(S*S*3)), wgt = Array.from({ length: nv }, () => new Float32Array(S*S)), tmp = [0, 0, 0];
  const stats = Array.from({ length: nv * NC }, () => [0, 0, 0]);
  for (let v = 0; v < nv; v++) { const a = al[v], [X, Y] = tpl.xy[v], W8 = tpl.wt[v], SH = tpl.sh[v];
    for (let i = 0; i < S*S; i++) { if (tpl.cid[i] < 0 || !W8[i]) continue;
      const px = X[i] / 16, py = Y[i] / 16, qx = px * a.s + a.tx, qy = py * a.s + a.ty, ix = qx | 0, iy = qy | 0;
      if (ix < 0 || iy < 0 || ix >= w || iy >= h || !inner[iy*w + ix]) continue;
      samp(qx, qy, tmp); const fa = W8[i] / 255 - .05;
      for (let c = 0; c < 3; c++) col[v][i*3+c] = tmp[c]; wgt[v][i] = fa * fa;
      const st = stats[v*NC + tpl.cid[i]]; st[0]++; st[1] += Math.log(Math.max(4, tmp[0]*.299 + tmp[1]*.587 + tmp[2]*.114)); st[2] += Math.log(Math.max(.05, SH[i] / 255)); } }
  // 1b. how much did the image model keep the reference's shading? (0 = it lit its painting evenly) Undo only that much.
  const unshade = opts.unshade ?? followed(stats, tpl.charts, nv);
  if (unshade) for (let v = 0; v < nv; v++) { const SH = tpl.sh[v];
    for (let i = 0; i < S*S; i++) if (wgt[v][i]) { const f = 1 - unshade + unshade * sref / Math.max(.05, SH[i] / 255); for (let c = 0; c < 3; c++) col[v][i*3+c] *= f; } }
  // 2. the two views are often lit a little differently: match their colours where both saw the surface
  const gain = Array.from({ length: nv }, () => [1, 1, 1]);
  if (nv === 2) { const ma = [0, 0, 0], mb = [0, 0, 0]; let c = 0;
    for (let i = 0; i < S*S; i++) if (wgt[0][i] > 0 && wgt[1][i] > 0) { c++; for (let k = 0; k < 3; k++) { ma[k] += col[0][i*3+k]; mb[k] += col[1][i*3+k]; } }
    if (c > 200) for (let k = 0; k < 3; k++) { const A = ma[k] / c + 1, B = mb[k] / c + 1; gain[0][k] = Math.sqrt(B / A); gain[1][k] = Math.sqrt(A / B); } }
  const atlas = new Float32Array(S*S*3), seen = new Uint8Array(S*S);
  for (let i = 0; i < S*S; i++) { let ws = 0; const acc = [0, 0, 0];
    for (let v = 0; v < nv; v++) { const q = wgt[v][i]; if (!q) continue; ws += q; for (let k = 0; k < 3; k++) acc[k] += col[v][i*3+k] * gain[v][k] * q; }
    if (ws > 0) { seen[i] = 1; for (let k = 0; k < 3; k++) atlas[i*3+k] = acc[k] / ws; } }
  // 3. per face: fill what no view saw (push-pull, the opposite face, or a plain cap colour)
  const ch = tpl.charts, img = [], msk = [], cov = [];
  let mean = [0, 0, 0], mc = 0;
  ch.forEach((c, k) => { const a = new Float32Array(c.w*c.h*3), m = new Uint8Array(c.w*c.h); let n = 0;
    for (let y = 0; y < c.h; y++) for (let x = 0; x < c.w; x++) { const i = (c.y + y)*S + c.x + x, j = y*c.w + x; if (!seen[i] || tpl.cid[i] !== k) continue; m[j] = 1; n++; for (let q = 0; q < 3; q++) { a[j*3+q] = atlas[i*3+q]; mean[q] += atlas[i*3+q]; } mc++; }
    img.push(a); msk.push(m); cov.push(n / (c.w*c.h)); });
  mean = mean.map(v => v / Math.max(1, mc));
  const filled = ch.map((c, k) => cov[k] >= .35 ? pushpull(img[k], msk[k], c.w, c.h) : null);
  ch.forEach((c, k) => { if (filled[k]) return; const o = c.opp;
    if (c.side === 'bottom' || o < 0 || cov[o] < .35) {
      const acc = [0, 0, 0]; let n = 0;
      ch.forEach((c2, j) => { if (c2.part !== c.part || j === k || cov[j] <= .35) return; const r0 = c2.h - Math.max(1, c2.h >> 3);
        for (let y = r0; y < c2.h; y++) for (let x = 0; x < c2.w; x++) { const t = y*c2.w + x; if (!msk[j][t]) continue; n++; for (let q = 0; q < 3; q++) acc[q] += img[j][t*3+q]; } });
      const base = n ? acc.map(v => v / n * .85) : [128, 128, 128];
      if (cov[k] > .1) filled[k] = pushpull(img[k], msk[k], c.w, c.h);
      else { const a = new Float32Array(img[k]); for (let t = 0; t < c.w*c.h; t++) if (!msk[k][t]) for (let q = 0; q < 3; q++) a[t*3+q] = base[q]; filled[k] = a; }
    } else {
      const so = filled[o] || pushpull(img[o], msk[o], ch[o].w, ch[o].h), src = resize(so, ch[o].w, ch[o].h, c.w, c.h, c.flip), a = new Float32Array(img[k]);
      for (let t = 0; t < c.w*c.h; t++) if (!msk[k][t]) for (let q = 0; q < 3; q++) a[t*3+q] = src[t*3+q]; filled[k] = a; } });
  const out = new Float32Array(S*S*3), has = new Uint8Array(S*S);
  ch.forEach((c, k) => { for (let y = 0; y < c.h; y++) for (let x = 0; x < c.w; x++) { const i = (c.y + y)*S + c.x + x, j = y*c.w + x; has[i] = 1; for (let q = 0; q < 3; q++) out[i*3+q] = filled[k][j*3+q]; } });
  for (let it = 0; it < 12; it++) { const nh = has.slice(); let changed = false;  // bleed into the gaps
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const i = y*S + x; if (has[i]) continue; let n = 0; const acc = [0, 0, 0];
      for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= S || yy >= S) continue; const j = yy*S + xx; if (!has[j]) continue; n++; for (let q = 0; q < 3; q++) acc[q] += out[j*3+q]; }
      if (n) { nh[i] = 1; changed = true; for (let q = 0; q < 3; q++) out[i*3+q] = acc[q] / n; } }
    has.set(nh); if (!changed) break; }
  // 4. the painted colours at the texture size (the retro look and the light are added live, in LoPolTex.compose)
  const n = tpl.size, alb = document.createElement('canvas'); alb.width = alb.height = n; const ax = alb.getContext('2d'), ad = ax.createImageData(n, n), up = resize(out, S, S, n, n);
  for (let i = 0; i < n*n; i++) { for (let q = 0; q < 3; q++) ad.data[i*4+q] = Math.max(0, Math.min(255, up[i*3+q])); ad.data[i*4+3] = 255; }
  ax.putImageData(ad, 0, 0);
  // 5. the logo face: the model's average colour with the Grug Digital logo (stamped after the retro look)
  const lg = document.createElement('canvas'); lg.width = lg.height = n;
  if (tpl.logo >= 0 && opts.logo !== false && window.GRUG && GRUG.logo) {
    const c = ch[tpl.logo], f = n / S, x0 = Math.round(c.x * f), y0 = Math.round(c.y * f), x1 = Math.round((c.x + c.w) * f), y1 = Math.round((c.y + c.h) * f);
    if (x1 - x0 >= 8 && y1 - y0 >= 8) { const g = lg.getContext('2d'), lum = mean[0]*.299 + mean[1]*.587 + mean[2]*.114;
      g.fillStyle = `rgb(${mean.map(v => Math.round(v)).join(',')})`; g.fillRect(x0, y0, x1 - x0, y1 - y0);
      const im = await loadImg('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(GRUG.logo('stacked', lum > 140 ? 'light' : 'dark', { cls: false, height: 512 })));
      const sc = Math.min((x1 - x0) * .72 / im.naturalWidth, (y1 - y0) * .72 / im.naturalHeight), lw = im.naturalWidth * sc, lh = im.naturalHeight * sc;
      g.drawImage(im, x0 + (x1 - x0 - lw) / 2, y0 + (y1 - y0 - lh) / 2, lw, lh); } }
  const look = JSON.parse(JSON.stringify(tpl.look));
  if (opts.preset && PRESETS[opts.preset]) look.fx = Object.assign({}, look.fx, PRESETS[opts.preset]);
  const D = { name: tpl.name, ...tpl.mesh, tex: toURL(alb), look, maps: Object.assign({ albedo: toURL(alb), logo: toURL(lg) }, tpl.mapUrls) };
  return { D, match: al.map(a => a.iou), albedo: alb, unshade };
}

window.LoPolBake = { load, bake, example, PRESETS };
})();
