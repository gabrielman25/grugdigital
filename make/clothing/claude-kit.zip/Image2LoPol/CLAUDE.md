# Image2LoPol: instructions for Claude

The person drops this folder into a chat with a picture of an object (a bag, a hat, a lamp, a house, a car…) and asks for
a model. You build a rough low-poly **block model** of it, render a grey **reference** (front left, back right), get an
image model (Nano Banana / Gemini) to **paint** that reference, and **bake** the painting back onto the model as a
PS1-style texture. Work through the steps below; the finished example items in `items/` show what good looks like.

## 0. Set up
- Work on a copy in your workspace. `python3 -c "import numpy, PIL"`; if missing: `pip install numpy pillow` (add
  `--break-system-packages` if pip asks). Nothing else is needed. Headless Chrome is only for checking the preview page.
- Read `MODEL_FORMAT.md` once. Look at one finished item (`items/handbag/`: `model.json`, `clay.png`, `reference.png`,
  `painted.jpg`, `out/check.png`, `out/turntable.png`) so you know the target.

## 1. The item folder
- Pick a short slug (`items/red-lunchbox/`). Save the person's picture as `items/<slug>/source.png` (or .jpg).
- Pictures from other angles help modelling: put them in `items/<slug>/angles/`.

## 2. Model it (model.json → clay.png)
- Look at the source and write `model.json` with boxes, tapered boxes, cylinders, lathes and straps (`MODEL_FORMAT.md`).
- `python3 tool/lopol.py clay items/<slug>` → `clay.png`: the source next to the grey model from four sides. **Look at it**
  and fix proportions, missing parts, parts floating or poking through. Usually 2–4 rounds.
- Choose `material` per part from what it's made of, mark glowing parts `emissive` (and add `lights` nodes for lamps,
  screens, candles), and set `object` + `description` (they go into the prompt).

## 3. The reference and the prompt
- `python3 tool/lopol.py ref items/<slug>` → `reference.png` + `prompt.txt`. Look at `reference.png`: every face that
  should get paint must be visible in one of the two views. If something important hides (the inside of a strap, a face
  behind another part), move it with `explode`, or change `views` (pitch 10–30, yaw 15–45 / +180).

## 4. Paint it with the image model
Send **reference.png first, then source.png** with the text of `prompt.txt` (one paragraph is fine). The prompt asks for
a **realistic, photo-scanned texture** (real material grain, colours, stitching, light wear, soft even light): keep that
style unless the person asks for another.
- **In the person's Chrome (Claude in Chrome + Gemini), when they're signed in:** open `https://gemini.google.com/app`
  (a new chat each time). Inject a hidden `<input type=file multiple id=ccs-stage>` with the javascript tool, put both
  files into it with the file-upload tool, then dispatch a `ClipboardEvent('paste')` carrying those files (via a
  `DataTransfer`) on `.ql-editor`. Click the prompt box, type the prompt, press Return, wait ~30 s.
  Take the result with Gemini's **Download full size** button (top right of the image), which saves to the person's
  Chrome download folder. Read it through the device tools (ask once for access to that folder), then save it as
  `items/<slug>/painted.jpg`.
- **Otherwise:** give the person `reference.png`, their picture and the prompt, and ask them to paste the result back
  into the chat.
- Avoid brand and platform names in prompts (one prompt mentioning a game platform was refused); "low-poly 3D model made
  of grey blocks" works.
- For **variants** (same model, new style), write the description of the new style into `description`, rerun `ref`
  and paint again; the source photo is optional then.

## 5. Bake and check (painted → out/)
- `python3 tool/lopol.py bake items/<slug>` (30–60 s: 1024 texture, path-traced bounce included; `"light": {"quality": "fast"}` skips it).
  The bake measures how much the painting kept the reference's grey shading and undoes only that much (`unshade` in
  `report.json`: about 0.1 for an evenly lit realistic painting, up to 0.9 for one that copied the shading).
- **Always look at** `out/check.png` (reference / painting / baked model from the same cameras) and `out/turntable.png`.
  The printed `silhouette_match` should be ≥ 0.95 per view. Below that the image model moved or reshaped blocks:
  paint again (say "keep every block exactly where it is"), or adjust the model to match what it painted.
- Things to look for: background colour smeared onto edges, a face that came out blank or striped, a seam where the
  two views meet, a part painted as something else. Rebake after fixing; regenerate when the painting itself is wrong.
- `filled_from_elsewhere` lists faces no view saw (bottoms, insides): normal for bottoms; for a big visible face it means
  the model needs `explode` or other `views`.

## 5b. Wear it (anything that goes on the avatar)
Add `wear` (MODEL_FORMAT.md, "Wearing it on the blocky avatar"): hats use `"fit": "hat"`, backpacks are modelled around
the torso with straps over the shoulders. Give parts `group`s for recolouring. Check with
`python3 tool/lopol.py worn items/<slug> [more items]` → `out/worn.png` (the avatar from four sides) before painting.

## 6. Deliver
`out/` has: `model.glb` (texture, normal map, tangents, outline if set), `model.obj` + `model.mtl`, `texture.png`
(1024, retro look on the colour, crisp light on top), `normal.png`, `preview.html` (open in a browser: turn it; sliders, each showing its value, for the texture effects (colour depth,
dither, pixel size, contrast, saturation, brightness) and the baked lighting (AO / room light / surface detail / light
nodes / path-traced bounce); add and move coloured light nodes; outline on or off; downloads), `check.png`, `turntable.png`, `report.json`, `maps/`.
Copy the item folder back to the person's folder and send them `out/preview.html` and `out/turntable.png`.

## 7. Optional: make it a template in the Clothing Studio (Grug Digital site)
`python3 tool/lopol.py template items/<slug> <site>/make/clothing/accessories` writes the template and updates
`index.json`. The Studio page's source is `studio/classic-clothing-studio.html`; after changing `tool/lopol-view.js`,
`tool/lopol-bake.js` or `tool/acc-ui.js`, run `python3 tool/inline_studio.py studio/classic-clothing-studio.html` and
copy it to the site's `make/clothing/index.html` (the site's copy adds a Back to Make button and its own title).
On the site, follow the repo's own CLAUDE.md: branch, run `python3 tools/pwa/build.py`, push, send the preview link.

## 8. On the website, without Python (Claude in Chrome)
The Studio page (`make/clothing/#accessories` on the Grug site) has the whole pipeline in the browser: `window.AccessoryStudio`
(`help()`, `modelFormat()`, `templates()`, `open()`, `example()`, `clay(model)`, `newModel(model)`, `describe()`,
`status()`, `look()`, `wear()`, `download()`), with `tool/lopol-core.js` building a model.json the same way as lopol.py.
Its "Use Claude" card picks the image generator (Gemini by default) and copies a hand-off message for Claude in Chrome.
The picture goes between the tabs through the clipboard: "Copy reference picture" → Ctrl+V in the generator, the
generator's copy-image → Ctrl+V on the Studio's drop box.

## 9. The Figure body, and the offline Studio
- The Studio's Character tab (and the Clothing tab's 3D preview) has a second body, **Figure**: slimmer waist, longer arms
  with a slight bend at the elbow, sphere hands, and real feet (skin toned, with a toenail colour). Blocky stays the default.
  The feet come from `body/feet.obj` (+ its diffuse, whose alpha is the toenail mask, and normal map):
  `python3 tool/make_feet.py [scale] [leg x]` writes `body/out/` (feet.json, nails.png, feet-normal.png); copy those to the
  site's `make/clothing/body/`. Things held in a hand, worn on the back or a shoulder move with the Figure's hands and
  slimmer back by themselves (`slotShift` in `tool/outfits-ui.js`).
- Its **Proportions** panel (Character tab → Body → Proportions) has a slider for every number (torso, arms, elbow, hands,
  leg height, ankle, knee position and bend, feet) plus X / Y / Z offsets per part, and **Copy as JSON**. To make a
  person's tuned proportions the default, paste their JSON into `FIG_DEFAULT` in the Studio page (search for it in
  `studio/classic-clothing-studio.html`), rebuild (`tool/inline_studio.py`) and copy it to the site.
- Pants are just pants: the clothing prompt asks for no shoes, socks or feet on the legs (shoes will be accessories).
- **Offline:** `python3 tool/build_offline.py studio/classic-clothing-studio.html <site>/make/clothing <out.html>` packs the
  whole Studio, every template, look, piece of clothing and the feet into ONE html file that opens from disk. It starts with
  notes for Claude: how to drive it, and how to add new accessories, clothing and looks to the file itself (the
  `studio-items` JSON block: a model.json + the image model's painting per accessory, template PNGs per clothing).
  The current build is `studio/clothing-studio-offline.html`.

## Files
- `tool/lopol.py`: everything (geometry, reference renders, alignment, baking, lighting, materials, exports).
- `tool/viewer.html` + `tool/lopol-view.js`: the 3D preview page (the same viewer runs in the Studio).
- `tool/lopol-bake.js` + `tool/acc-ui.js` + `tool/inline_studio.py`: the in-browser bake and the Studio's Accessories section.
- `tool/lopol-core.js`: the model builder in the browser (model.json → reference, painting map, light and normal maps).
- `tool/outfits-ui.js`: the Studio's Character tab (body type, the avatar wearing shirt, pants and accessories; recolouring;
  looks; Edit / New / With Claude).
- `tool/make_feet.py` + `body/`: the Figure body's feet. `tool/build_offline.py`: the one-file offline Studio.
- `tool/logo-light.png`, `tool/logo-dark.png`: the Grug Digital logo stamped on the biggest bottom face.
- `test/roundtrip.py items/<slug>`: paints a model with a known texture, distorts it like an image model would, bakes it
  and reports the error (run after changing the bake).
- `templates/`: the Studio templates made from the example items.
