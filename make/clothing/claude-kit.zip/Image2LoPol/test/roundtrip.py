"""Paint a model with a known texture, distort the picture like an image model would, bake, compare."""
import sys, json, pathlib, numpy as np
from PIL import Image
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'tool'))
import lopol as L

item = pathlib.Path(sys.argv[1]); model = json.loads((item / 'model.json').read_text())
model.setdefault('texture', {})['unshade'] = 1.0
charts = L.build_charts(model); S = int(model['texture'].get('atlas', 1024))
truth = np.zeros((S, S, 3))
rng = np.random.default_rng(1)
for k, ch in enumerate(charts):
    base = rng.uniform(60, 220, 3)
    yy, xx = np.mgrid[0:ch.h, 0:ch.w]
    chk = ((xx // 10 + yy // 10) % 2)[..., None] * 40 - 20
    grad = (xx / max(ch.w, 1) * 50)[..., None] * np.array([1, -0.5, 0.3])
    truth[ch.y0:ch.y0 + ch.h, ch.x0:ch.x0 + ch.w] = np.clip(base + chk + grad, 0, 255)
vs = L.fit_views(model, charts, L.REF_W, L.REF_H)
img = L.render(charts, vs, L.REF_W, L.REF_H, tex=truth.astype(np.uint8), ss=2, edges=False)
# image-model-like distortion: different size, slight shift and scale per half
w2, h2 = 1024, 683
out = Image.new('RGB', (w2, h2), (250, 250, 248))
for i, (sc, dx, dy) in enumerate(((0.965, 9, -6), (1.02, -12, 7))):
    half = img.crop((i * 768, 0, (i + 1) * 768, 1024))
    hw, hh = int(512 * sc), int(683 * sc)
    out.paste(half.resize((hw, hh), Image.LANCZOS), (i * 512 + (512 - hw) // 2 + dx, (683 - hh) // 2 + dy))
out.save(item / 'painted.png')
atlas, al, report = L.bake(model, charts, vs, np.asarray(out), S, model['texture'])
errs = []
for (name, cov), ch in zip(report, charts):
    if cov < 0.35: continue
    a = atlas[ch.y0:ch.y0 + ch.h, ch.x0:ch.x0 + ch.w]; t = truth[ch.y0:ch.y0 + ch.h, ch.x0:ch.x0 + ch.w]
    e = np.abs(a - t).mean(); errs.append((e, name, cov))
errs.sort(reverse=True)
print('align', [(round(a['s'], 4), round(a['tx'], 1), round(a['ty'], 1), round(a['iou'], 4)) for a in al])
print('mean abs error per chart (worst 8):', [(round(e, 1), n, round(c, 2)) for e, n, c in errs[:8]])
print('median error', round(float(np.median([e for e, _, _ in errs])), 2), 'charts', len(errs), 'of', len(charts))
Image.fromarray(np.concatenate([truth, atlas], 1).astype(np.uint8)).resize((1024, 512)).save('/tmp/rt.png')
