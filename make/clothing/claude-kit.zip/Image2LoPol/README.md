# Image2LoPol

Turn a picture of an object into a PS1-style low-poly 3D model.

1. Claude builds a rough block model of the object and renders it in grey, front and back.
2. Nano Banana (Gemini) paints the grey model to look like your picture, or like any variant you describe.
3. The painting is projected back onto the blocks as a retro texture, with baked lighting, material detail, an optional
   outline, and downloads for GLB, OBJ and PNG.

## Making a new model
Open a new Claude chat, add this whole folder, attach a picture of the thing, and ask:
**"Make me a model of this."** Claude reads `CLAUDE.md` and follows the steps. With Claude in Chrome connected and
Gemini signed in, it does the painting step for you too.

## What's here
- `items/`: five finished examples from the Roblox catalog (backpack, handbag, cowboy hat, boombox, lantern). Open
  `items/<name>/out/preview.html` in a browser to turn each one around and play with the lighting.
- `tool/`: the tool (Python, needs only numpy and Pillow).
- `templates/`: the same five as templates for the Clothing Studio's Accessories section.
- `CLAUDE.md`: the step-by-step for Claude. `MODEL_FORMAT.md`: the model file format.

The example items recreate items from the Roblox catalog as a test of the workflow. Keep them for testing; don't sell
copies of other creators' designs.
