# model.json reference

One file per item, in `items/<slug>/model.json`. Units are free (think "studs"). Y is up and the **front faces +Z**, so
+X is on your right when you look at the front. The reference's first view looks at the front and the +X side.
The block below is annotated: the real file is plain JSON (no comments); see `items/*/model.json`.

```jsonc
{
 "name": "Leather handbag",                 // shown in previews and file names
 "object": "handbag",                       // short noun used in the prompt
 "description": "dark green pebbled leather handbag with two rolled handles and small gold rings",
 "parts": [ ... ],                          // see below
 "views": [{"yaw": 35, "pitch": 22}, {"yaw": 215, "pitch": 22}],   // optional; default shown. Use ~20/200 for wide, symmetric things
 "texture": {"size": 1024, "atlas": 1024, "fx": {}},  // fx: bits, dither, pixel, contrast, sat, bright (default below),
                                            // or {"preset": "ps1" | "n64" | "16bit" | "clean"}
 "light": {"ao": 1.0, "room": 0.6, "lights": 1.0, "detail": 0.32, "bounce": 1.05,   // the defaults
           "quality": "fast",                                        // skips the path-traced bounce (on by default)
           "room_dir": [-0.35, 1.0, 0.45], "ao_reach": 0.35, "sky": [0.55, 0.58, 0.62], "res": 192},
 "wear": {"on": "back", "rot": [0, 180, 0], "offset": [0, 0, 0], "scale": 1},  // where it sits on the blocky avatar (below)
 "lights": [{"pos": [0, 1.0, 0], "color": [255, 196, 60], "strength": 1.6, "range": 2.6}],   // light nodes (optional)
 "outline": {"width": 0.027, "color": [5, 5, 5]},   // inverted-hull outline: on by default with these values; false turns it off
 "logo": true,                              // Grug Digital logo on the biggest bottom face (default). "part.side" or false
 "material": "none",                        // default material for parts without one
 "export_scale": 1.0
}
```

## The texture

1024 x 1024. The retro look goes on the **colour only**: contrast, saturation and brightness, then bigger pixels
(`pixel` 2 = 2 x 2 blocks), colour depth (`bits` 4) and ordered dithering (`dither` 1). The light is multiplied in
afterwards at the full 1024, so ambient occlusion, room light, surface detail (the normal map), light nodes and the
path-traced bounce stay crisp. Defaults (the owner's picks): bits 4, dither 1.00, pixel 2, contrast +0.50, saturation 0,
brightness 0; AO 1.00, room light 0.60, surface detail 0.32, light nodes 1.00, bounce 1.05; outline width 0.027, RGB 5 5 5.

## Colour groups

Parts with the same `group` are recoloured together in the Studio (the 3D preview's Colours list, and Outfits).
Without one, a part is its own group named after it. Split a model the way a person would recolour it: the bag apart from
its straps, the bottle apart from the bag, the cap apart from the bottle. Mirrored copies share their part's group.

## Wearing it on the blocky avatar

The avatar, in studs: torso x -1..1, y 2..4, z -0.5..0.5 (front +Z); arms x 1..2 (left) and -2..-1 (right), y 2..4;
legs y 0..2; head a rounded cylinder r 0.625 from y 4 to 5.25, eyes at y ~4.8.
`"wear": {"on", "scale", "rot", "offset"}` moves the model into avatar space: scale, then rotate (X, Y, Z), then move.
`on` is the spot (one accessory per spot in Outfits) and names the Roblox attachment: head (HatAttachment), back
(BodyBackAttachment), lhand / rhand (Left/RightGripAttachment), lshoulder / rshoulder, face, neck, waist, front, hair.
- **Hats:** `{"on": "head", "scale": 0.84, "fit": "hat"}`: centred on the head with the brim's lowest edge just above
  the eyes (y 4.88), so no forehead shows. Use this for every hat; pick the scale so the crown is wider than the head.
- **Backpacks:** model them around the torso in avatar units (it's easiest to model with the pocket at +Z and wear it
  with `"rot": [0, 180, 0]`): the bag's back face at z ~0.52 behind the torso, straps (`strap` with one `normals` entry
  per point) going over the shoulders at x ±0.8 (clear of the head), y ~4.05, and down the chest at z -0.54.
- **Held things** hang from the hand: the top of the handle at y ~2.0, x ±1.5. **On a shoulder:** sitting on y 4.
- **Hair:** `{"on": "hair"}`, modelled straight on the head above (a `lathe` cap over the crown a little wider than the
  head, r ~0.76, so the head's top rim never pokes through; a part-turn `lathe` with `sweep` round the back and sides, open
  at the face). It follows the head on both bodies and when the avatar moves.
- **Shoes:** `{"on": "feet"}`, modelled as a pair in the Figure body's foot space (`body/out/feet.json`: the left foot at
  x 0.18..0.81, sole y 0, ankle y 0.42, heel z -0.32, toes z 0.91; model the left shoe and add `"mirror": "x"`). Keep them
  simple: a few boxes about the size of the foot (a sole slab, the shoe, a collar at the back, a lace panel) work best.
  The Studio splits the pair at x = 0 so each shoe follows its own foot; on the blocky body each sits on the bottom of its
  leg, stretched to fit. `python3 tool/lopol.py fit items/<shoes>` renders them on the bare feet and reports any foot
  points that stick out: check it before painting.
- `python3 tool/lopol.py worn items/a items/b ...` renders the avatar wearing them from four sides (`out/worn.png`).

## Parts

Every part has `name`, `type`, and optionally `center` [x,y,z], `rot` [x,y,z] degrees (applied X, then Y, then Z),
`mirror` ("x", "y", "z" or a list like ["x","z"]: adds mirrored copies), `explode` [x,y,z] (moves it in the back view only,
to show faces that are hidden when assembled), `material`, `seams`, `emissive`, `group`, `hidden`.

| type | fields | good for |
|---|---|---|
| `box` | `size` [w,h,d]; `taper` [x,z] scales the top face (0.8 = narrower top; [1,0.2] = a wedge / triangular sides); `taperBottom` [x,z]; `shift` [x,z] slides the top face; `omit` ["bottom", …] drops faces | bodies, pockets, panels, tabs, roofs |
| `cylinder` | `radius`, `radiusTop`, `height`, `sides` (6–12), `caps` "both" / "top" / "bottom" / "none", `scale` [x,z] for ovals | bottles, knobs, speakers (rot [90,0,0] faces it forward), wheels |
| `lathe` | `profile` [[radius, y], …] **top to bottom**, `sides`, `scale` [x,z], `caps`, `curl` {"amount", "from"} lifts the outer ring at the sides (cowboy brims); `sweep` (degrees, below 360 = an open part-turn with no caps) and `startAngle` | hats, bowls, vases, domes, lamp shades, rounded crowns. A profile can go out and come back in (a brim with thickness) |
| `prism` | `outline` [[x, z], …] seen from above (any order), `y` [bottom, top] | soles, footbeds, flat badges and panels with an odd outline |
| `loft` | `rings` [{"y", "outline": [[x, z], …]}, …] **top to bottom**, every outline with the same number of points in the same order; `caps` | odd solids made of cross-sections (a boot's shell, a vase with a square foot) |
| `strap` | `points` [[x,y,z], …] along the middle, `width`, `thickness`, `normal` (which way the wide face looks, e.g. [0,0,-1] for backpack straps) or `normals` (one per point, for a strap that bends over a shoulder and keeps facing out), `caps` | straps, handles, belts, cords, rims, frames |

Faces: box faces are `front back left right top bottom`; lathe/cylinder `side top bottom`; strap `front back edge1 edge2 end1 end2`.
Faces no view can see (bottoms, the back of a strap) are filled from the opposite face, or with a plain colour for bottoms.

## Materials (normal-map presets, chosen per part)

`none plastic leather suede canvas denim wool knit quilted metal wood glass fur`. Fabric and leather add stitched
**seams** along every face edge by default (`"seams": false` turns them off; use false on lathes and small round parts).
The material's relief is baked into the PS1 texture (the "Surface detail" slider) and exported as `normal.png` for engines.
Pick from the source: bags → leather / canvas, sweaters → knit / wool, jeans → denim, tools → metal / wood,
toys → plastic, lamps' glass → glass, hats → suede / wool / leather.

## Light

- `emissive` on a part, e.g. `{"color": [255,206,64], "strength": 1.0}`: the part glows in that colour (not shaded) and lets
  light through. A part with `emissive` and no `lights` list gets a light node in its middle automatically.
- `lights`: light nodes anywhere (inside a lantern, over a screen…) with colour, strength and range; they cast shadows.
- The 3D preview page can add, move and recolour light nodes live and download the result.
- Effects are texture-only: nothing moves the model's vertices.

## Modelling tips

- Aim for 50–400 triangles. Big readable blocks; let the painting carry the detail.
- Keep parts slightly overlapping (no gaps) and avoid faces that sit exactly on top of each other.
- Thin things (straps, handles, tabs) are fine: the bake samples them even when they are a few pixels wide.
- Check `clay.png` against the source after every change; 2–4 rounds is normal.
